import React, { useEffect, useState } from 'react';
import { Login } from './pages/Login';
import { StoryWizard } from './pages/StoryWizard';
import { Library } from './pages/Library';
import { StoryEditor } from './pages/StoryEditor';
import { StoryReader } from './pages/StoryReader';
import { User, Story, WizardState, UserRole } from './types';
import { Button } from './components/Button';
import { Plus, BookOpen, LogOut, Settings } from 'lucide-react';
import { useLanguage } from './contexts/LanguageContext';
import { LanguageSwitcher } from './components/LanguageSwitcher';
import {
  clearSession,
  createStory,
  fetchCurrentUser,
  fetchScopedStories,
  getAdminAppUrl,
  saveStory,
  toErrorMessage,
} from './services/backendService';

export default function App() {
  const { t, tr } = useLanguage();
  const [user, setUser] = useState<User | null>(null);
  const [view, setView] = useState<'dashboard' | 'create' | 'library' | 'editor' | 'read'>('dashboard');
  const [isBootstrapping, setIsBootstrapping] = useState(true);
  const [isLoadingStories, setIsLoadingStories] = useState(false);
  const [stories, setStories] = useState<Story[]>([]);
  const [currentStory, setCurrentStory] = useState<Story | null>(null);

  const loadStories = async (activeUser: User) => {
    setIsLoadingStories(true);
    try {
      const records = await fetchScopedStories();
      setStories(records);
    } catch (error) {
      alert(toErrorMessage(error));
    } finally {
      setIsLoadingStories(false);
    }
  };

  useEffect(() => {
    let active = true;

    const bootstrap = async () => {
      try {
        const currentUser = await fetchCurrentUser();
        if (!active || !currentUser) {
          return;
        }

        setUser(currentUser);
        setView(currentUser.role === UserRole.TEACHER ? 'library' : 'dashboard');
        await loadStories(currentUser);
      } catch {
        clearSession();
      } finally {
        if (active) {
          setIsBootstrapping(false);
        }
      }
    };

    bootstrap();

    return () => {
      active = false;
    };
  }, []);

  const handleLogin = async (loggedInUser: User) => {
    setUser(loggedInUser);
    setCurrentStory(null);
    setView(loggedInUser.role === UserRole.TEACHER ? 'library' : 'dashboard');
    await loadStories(loggedInUser);
  };

  const handleLogout = () => {
    clearSession();
    setUser(null);
    setStories([]);
    setCurrentStory(null);
    setView('dashboard');
  };

  const handleWizardFinish = async (data: WizardState, action: 'save' | 'edit') => {
    if (!user) {
      return;
    }

    const newStory: Story = {
      id: Date.now().toString(),
      title: `${data.character?.description}'s Adventure`,
      coverImage: data.generatedPages[0]?.imageUrl || data.character?.imageUrl || '',
      authorId: user.studentId || user.id,
      authorName: user.name,
      ageGroup: data.ageGroup!,
      character: {
          name: data.character?.description || '',
          description: data.character?.description || '',
          imageUrl: data.character?.imageUrl || ''
      },
      place: {
          name: data.place?.description || '',
          description: data.place?.description || '',
          imageUrl: data.place?.imageUrl || ''
      },
      time: data.time?.description || t.wizard.onceUponATime,
      pages: data.generatedPages,
      styling: {
          titleColor: '#7209B7',
          fontFamily: 'font-comic'
      },
      createdAt: Date.now()
    };

    try {
      const savedStory = await createStory(newStory);
      setStories(prev => [savedStory, ...prev.filter((story) => story.id !== savedStory.id)]);

      if (action === 'edit') {
          setCurrentStory(savedStory);
          setView('editor');
      } else {
          setView('library');
      }
    } catch (error) {
      alert(toErrorMessage(error));
    }
  };

  const handleEditStory = (story: Story) => {
      setCurrentStory(story);
      setView('editor');
  }

  const handleReadStory = (story: Story) => {
      setCurrentStory(story);
      setView('read');
  }

  const handleSaveEditor = async (updatedStory: Story) => {
      try {
        const saved = await saveStory(updatedStory);
        setStories(prev => prev.map(s => s.id === saved.id ? saved : s));
        setCurrentStory(saved);
        setView('library');
      } catch (error) {
        alert(toErrorMessage(error));
      }
  }

  const openAdminApp = () => {
    window.open(getAdminAppUrl(), '_blank', 'noopener,noreferrer');
  };

  if (isBootstrapping) {
    return (
      <div className="min-h-screen flex items-center justify-center text-2xl font-bold text-kid-purple">
        {t.loading}
      </div>
    );
  }

  if (!user) {
    return <Login onLogin={handleLogin} />;
  }

  if (view === 'create') {
    return (
      <StoryWizard 
        user={user} 
        onFinish={handleWizardFinish} 
        onCancel={() => setView('dashboard')} 
      />
    );
  }

  if (view === 'library') {
      return (
          <Library 
            stories={stories} 
            onEdit={handleEditStory} 
            onRead={handleReadStory} 
            onBack={() => setView('dashboard')}
          />
      )
  }

  if (view === 'editor' && currentStory) {
      return (
          <StoryEditor 
            story={currentStory} 
            onSave={handleSaveEditor} 
            onDiscard={() => setView('library')} 
          />
      )
  }

  if (view === 'read' && currentStory) {
      return (
          <StoryReader
            story={currentStory}
            onExit={() => setView('library')}
          />
      )
  }

  return (
    <div className="min-h-screen p-8 max-w-6xl mx-auto font-sans">
      <header className="flex flex-col md:flex-row justify-between items-center mb-12 gap-4 animate-fade-in">
        <div className="text-center md:text-left">
          <h1 className="text-4xl font-extrabold text-kid-purple mb-2">
            {tr('dashboard.welcomeUser', { name: user.name })}
          </h1>
          <p className="text-xl text-gray-600">{t.dashboard.readyMagic}</p>
        </div>
        <div className="flex items-center gap-3">
          <LanguageSwitcher compact />
          {(user.role === UserRole.TEACHER || user.role === UserRole.TESTER) && (
            <Button
              variant="secondary"
              size="sm"
              onClick={openAdminApp}
              icon={<Settings size={20}/>}
            >
              {t.dashboard.adminPanel}
            </Button>
          )}
          <Button
            variant="outline"
            size="sm"
            onClick={handleLogout}
            icon={<LogOut size={20}/>}
            className="bg-white"
          >
            {t.switchAccount}
          </Button>
        </div>
      </header>

      {isLoadingStories && (
        <div className="mb-6 rounded-2xl border-4 border-kid-blue bg-white px-6 py-4 text-center font-bold text-kid-blue">
          {t.loading}
        </div>
      )}

      <main className="grid grid-cols-1 md:grid-cols-2 gap-8 px-4 animate-slide-up">
        {user.role === UserRole.STUDENT ? (
          <button
            onClick={() => setView('create')}
            className="group relative bg-white p-8 rounded-[3rem] border-8 border-kid-blue shadow-xl hover:shadow-2xl hover:scale-105 transition-all duration-300 flex flex-col items-center text-center overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-b from-transparent to-kid-blue/5 opacity-0 group-hover:opacity-100 transition-opacity" />
            <div className="bg-kid-blue/10 p-8 rounded-full mb-6 group-hover:bg-kid-blue/20 transition-colors">
              <Plus size={64} className="text-kid-blue" />
            </div>
            <h2 className="text-3xl font-bold text-gray-800 mb-3 group-hover:text-kid-blue transition-colors">
              {t.dashboard.createNew}
            </h2>
            <p className="text-gray-500 text-lg">
              {t.dashboard.createNewDesc}
            </p>
          </button>
        ) : (
          <button
            onClick={() => setView('library')}
            className="group relative bg-white p-8 rounded-[3rem] border-8 border-kid-green shadow-xl hover:shadow-2xl hover:scale-105 transition-all duration-300 flex flex-col items-center text-center overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-b from-transparent to-kid-green/5 opacity-0 group-hover:opacity-100 transition-opacity" />
            <div className="bg-kid-green/10 p-8 rounded-full mb-6 group-hover:bg-kid-green/20 transition-colors">
              <BookOpen size={64} className="text-kid-green" />
            </div>
            <h2 className="text-3xl font-bold text-gray-800 mb-3 group-hover:text-kid-green transition-colors">
              {t.admin.viewRecords}
            </h2>
            <p className="text-gray-500 text-lg">
              {t.dashboard.seeBooksDesc}
            </p>
          </button>
        )}

        <button
          onClick={user.role === UserRole.STUDENT ? () => setView('library') : openAdminApp}
          className="group relative bg-white p-8 rounded-[3rem] border-8 border-kid-yellow shadow-xl hover:shadow-2xl hover:scale-105 transition-all duration-300 flex flex-col items-center text-center overflow-hidden"
        >
           <div className="absolute inset-0 bg-gradient-to-b from-transparent to-kid-yellow/5 opacity-0 group-hover:opacity-100 transition-opacity" />
          <div className="bg-kid-yellow/10 p-8 rounded-full mb-6 group-hover:bg-kid-yellow/20 transition-colors">
            {user.role === UserRole.STUDENT ? (
              <BookOpen size={64} className="text-kid-yellow" />
            ) : (
              <Settings size={64} className="text-kid-yellow" />
            )}
          </div>
          <h2 className="text-3xl font-bold text-gray-800 mb-3 group-hover:text-yellow-600 transition-colors">
            {user.role === UserRole.STUDENT ? t.dashboard.seeBooks : t.dashboard.adminPanel}
          </h2>
          <p className="text-gray-500 text-lg">
            {user.role === UserRole.STUDENT ? t.dashboard.seeBooksDesc : t.admin.generateQR}
          </p>
        </button>
      </main>
    </div>
  );
}
