// Multi-language support for StoryBuddy
export type Language = 'en' | 'zh-HK' | 'zh-CN';

export interface Translations {
  // Common
  welcome: string;
  logout: string;
  switchAccount: string;
  save: string;
  cancel: string;
  confirm: string;
  delete: string;
  edit: string;
  back: string;
  next: string;
  previous: string;
  exit: string;
  close: string;
  loading: string;

  // Login page
  login: {
    title: string;
    subtitle: string;
    password: string;
    qrCode: string;
    username: string;
    yourName: string;
    signUp: string;
    logIn: string;
    noAccount: string;
    hasAccount: string;
    simulateScan: string;
    showBadge: string;
    student: string;
    teacher: string;
    tester: string;
  };

  // Dashboard
  dashboard: {
    welcomeUser: string;
    readyMagic: string;
    createNew: string;
    createNewDesc: string;
    seeBooks: string;
    seeBooksDesc: string;
    adminPanel: string;
  };

  // Story Wizard
  wizard: {
    greeting: string;
    howOld: string;
    yearsOld: string;
    whoInStory: string;
    whereAreThey: string;
    whenIsIt: string;
    whatHappens: string;
    characterPlaceholder: string;
    placePlaceholder: string;
    timePlaceholder: string;
    typeOrSay: string;
    typeOrTapNext: string;
    needHint: string;
    howAboutThis: string;
    yesOkay: string;
    noLetMePick: string;
    change: string;
    makeMagic: string;
    creatingMagic: string;
    storyReady: string;
    whatToDo: string;
    editing: string;
    print: string;
    dontBeShy: string;
    ideaAppears: string;
    onceUponATime: string;
    points: string;
  };

  // Story Reader
  reader: {
    readToMe: string;
    listening: string;
    page: string;
    storyteller: string;
    buddy: string;
    grandpa: string;
    voiceControl: string;
    voiceControlOn: string;
    voiceControlOff: string;
    voiceControlHint: string;
    textStyle: string;
    prev: string;
    next: string;
  };

  // Story Editor
  editor: {
    editStory: string;
    regenerateCover: string;
    regenerateImage: string;
    titleSize: string;
    titleColor: string;
    fontFamily: string;
    saveChanges: string;
    discardChanges: string;
    unsavedChanges: string;
    saveAndExit: string;
    discardAll: string;
  };

  // Library
  library: {
    title: string;
    noStories: string;
    noStoriesDesc: string;
    by: string;
    read: string;
  };

  // Progress
  progress: {
    start: string;
    finish: string;
  };

  // Admin
  admin: {
    dashboard: string;
    schools: string;
    classes: string;
    teachers: string;
    students: string;
    books: string;
    addSchool: string;
    addClass: string;
    addTeacher: string;
    addStudent: string;
    importCSV: string;
    generateQR: string;
    viewRecords: string;
    totalTeachers: string;
    totalStudents: string;
    totalStories: string;
    grade: string;
    schoolName: string;
    className: string;
    teacherName: string;
    studentName: string;
    address: string;
    email: string;
    noSchools: string;
    noClasses: string;
    noTeachers: string;
    noStudents: string;
    noStories: string;
    selectSchool: string;
    selectClass: string;
    selectTeacher: string;
    allSchools: string;
    allClasses: string;
    all: string;
    searchStories: string;
    teacherId: string;
    studentId: string;
    noEmail: string;
    ageGroups: {
      toddler: string;
      earlyReader: string;
      preTeen: string;
    };
  };

  // Editor extended
  editorExt: {
    sections: string;
    bookCover: string;
    storyPages: string;
    pages: string;
    pageNum: string;
    regenerateArt: string;
    storyText: string;
    redrawPicture: string;
    rewriteText: string;
  };

  // QR Code
  qrCode: {
    scan: string;
    tryAgain: string;
    download: string;
  };

  // Style Picker
  stylePicker: {
    comicSans: string;
    sansSerif: string;
    serif: string;
    purple: string;
    blue: string;
    pink: string;
    green: string;
    yellow: string;
    dark: string;
  };

  // Voice commands
  voice: {
    listening: string;
    processing: string;
    tapToSpeak: string;
    nextPage: string;
    prevPage: string;
    exitCommand: string;
  };

  // Alerts and error messages
  alerts: {
    enterUsernamePassword: string;
    enterYourName: string;
    accountCreated: string;
    invalidQRCode: string;
    couldNotRegenerateCover: string;
    couldNotRegenerateImage: string;
    couldNotRewriteText: string;
    couldNotPlayAudio: string;
    cameraAccessError: string;
  };

  // Badges
  badges: {
    newBadge: string;
    awesome: string;
    characterCreator: string;
    characterCreatorDesc: string;
    worldBuilder: string;
    worldBuilderDesc: string;
    masterStoryteller: string;
    masterStorytellerDesc: string;
  };

  // User names (for QR login)
  users: {
    studentQR: string;
    studentUser: string;
    teacherUser: string;
  };
}

const en: Translations = {
  welcome: 'Welcome',
  logout: 'Log out',
  switchAccount: 'Switch Account',
  save: 'Save',
  cancel: 'Cancel',
  confirm: 'Confirm',
  delete: 'Delete',
  edit: 'Edit',
  back: 'Back',
  next: 'Next',
  previous: 'Prev',
  exit: 'Exit',
  close: 'Close',
  loading: 'Loading...',

  login: {
    title: 'StoryBuddy',
    subtitle: 'Join the adventure!',
    password: 'Password',
    qrCode: 'QR Code',
    username: 'Username',
    yourName: 'Your Name (e.g. Alex)',
    signUp: 'Sign Up',
    logIn: 'Log In',
    noAccount: "Don't have an account?",
    hasAccount: 'Already have an account?',
    simulateScan: 'Simulate Scan',
    showBadge: 'Show your class badge to the camera!',
    student: 'Student',
    teacher: 'Teacher',
    tester: 'Tester',
  },

  dashboard: {
    welcomeUser: 'Welcome, {name}!',
    readyMagic: 'Ready to make some magic today?',
    createNew: 'Create a New Story',
    createNewDesc: 'Start a brand new adventure with your AI friend!',
    seeBooks: 'See Previous e-Books',
    seeBooksDesc: "Read and edit stories you've already made.",
    adminPanel: 'Admin Panel',
  },

  wizard: {
    greeting: 'Hello! What story do you want to create today?',
    howOld: 'How old are you?',
    yearsOld: 'I am {age} years old',
    whoInStory: 'Who is in your story?',
    whereAreThey: 'Where are they?',
    whenIsIt: 'When is it?',
    whatHappens: 'What happens next?',
    characterPlaceholder: 'e.g., A brave robot',
    placePlaceholder: 'e.g., On Mars',
    timePlaceholder: 'e.g., In the future',
    typeOrSay: 'Type or say it, then press Enter!',
    typeOrTapNext: 'Type or say it, then tap Next!',
    needHint: 'Need a hint? Pick one!',
    howAboutThis: 'How about this?',
    yesOkay: "Yes, it's okay!",
    noLetMePick: 'No, let me pick',
    change: 'Change',
    makeMagic: 'Make My Story!',
    creatingMagic: 'Creating Magic...',
    storyReady: 'Your Story is Ready!',
    whatToDo: 'What do you want to do?',
    editing: 'Editing',
    print: 'Print',
    dontBeShy: "Don't be shy! Type something...",
    ideaAppears: 'Your idea appears here...',
    onceUponATime: 'Once upon a time...',
    points: 'pts',
  },

  reader: {
    readToMe: 'Read to Me',
    listening: 'Listening',
    page: 'Page',
    storyteller: 'Storyteller',
    buddy: 'Buddy',
    grandpa: 'Grandpa',
    voiceControl: 'Voice Control',
    voiceControlOn: 'Voice control is ON',
    voiceControlOff: 'Voice control is OFF',
    voiceControlHint: 'Say "next page" or "previous page"',
    textStyle: 'Text Style',
    prev: 'Prev',
    next: 'Next',
  },

  editor: {
    editStory: 'Edit Story',
    regenerateCover: 'Regenerate Cover',
    regenerateImage: 'Regenerate Image',
    titleSize: 'Title Size',
    titleColor: 'Title Color',
    fontFamily: 'Font',
    saveChanges: 'Save Changes',
    discardChanges: 'Discard Changes',
    unsavedChanges: 'You have unsaved changes',
    saveAndExit: 'Save and Exit',
    discardAll: 'Discard All Changes',
  },

  library: {
    title: 'My Story Library',
    noStories: 'No stories yet!',
    noStoriesDesc: 'Go create your first magical adventure.',
    by: 'by',
    read: 'Read',
  },

  progress: {
    start: 'Start',
    finish: 'Finish!',
  },

  admin: {
    dashboard: 'Admin Dashboard',
    schools: 'Schools',
    classes: 'Classes',
    teachers: 'Teachers',
    students: 'Students',
    books: 'e-Books',
    addSchool: 'Add School',
    addClass: 'Add Class',
    addTeacher: 'Add Teacher',
    addStudent: 'Add Student',
    importCSV: 'Import CSV/XLSX',
    generateQR: 'Generate QR Code',
    viewRecords: 'View Records',
    totalTeachers: 'Total Teachers',
    totalStudents: 'Total Students',
    totalStories: 'Total Stories',
    grade: 'Grade',
    schoolName: 'School Name',
    className: 'Class Name',
    teacherName: 'Teacher Name',
    studentName: 'Student Name',
    address: 'Address',
    email: 'Email',
    noSchools: 'No schools yet. Add your first school!',
    noClasses: 'No classes yet. Add your first class!',
    noTeachers: 'No teachers yet. Add your first teacher!',
    noStudents: 'No students yet. Add your first student!',
    noStories: 'No stories found.',
    selectSchool: 'Select a school to view',
    selectClass: 'Select a class to view',
    selectTeacher: 'Select Teacher',
    allSchools: 'All Schools',
    allClasses: 'All Classes',
    all: 'All',
    searchStories: 'Search stories...',
    teacherId: 'Teacher ID',
    studentId: 'Student ID',
    noEmail: 'No email',
    ageGroups: {
      toddler: '3~4 years',
      earlyReader: '4~5 years',
      preTeen: '5~6 years',
    },
  },

  editorExt: {
    sections: 'Sections',
    bookCover: 'Book Cover',
    storyPages: 'Story Pages',
    pages: 'Pages',
    pageNum: 'Page',
    regenerateArt: 'Regenerate Art',
    storyText: 'Story Text',
    redrawPicture: 'Redraw Picture',
    rewriteText: 'Rewrite Text',
  },

  qrCode: {
    scan: 'Scan QR Code',
    tryAgain: 'Try Again',
    download: 'Download QR Code',
  },

  stylePicker: {
    comicSans: 'Comic Sans',
    sansSerif: 'Sans Serif',
    serif: 'Serif',
    purple: 'Purple',
    blue: 'Blue',
    pink: 'Pink',
    green: 'Green',
    yellow: 'Yellow',
    dark: 'Dark',
  },

  voice: {
    listening: 'Listening...',
    processing: 'Processing...',
    tapToSpeak: 'Tap to speak',
    nextPage: 'next page',
    prevPage: 'previous page',
    exitCommand: 'exit',
  },

  alerts: {
    enterUsernamePassword: 'Please enter username and password!',
    enterYourName: 'Please enter your name!',
    accountCreated: 'Account created for {name}! Please log in.',
    invalidQRCode: 'Invalid QR code format',
    couldNotRegenerateCover: 'Could not regenerate cover.',
    couldNotRegenerateImage: 'Could not regenerate image.',
    couldNotRewriteText: 'Could not rewrite text.',
    couldNotPlayAudio: 'Could not play audio. Please try again.',
    cameraAccessError: 'Unable to access camera. Please check permissions.',
  },

  badges: {
    newBadge: 'New Badge!',
    awesome: 'Awesome!',
    characterCreator: 'Character Creator',
    characterCreatorDesc: 'You made a new friend!',
    worldBuilder: 'World Builder',
    worldBuilderDesc: 'You discovered a new place!',
    masterStoryteller: 'Master Storyteller',
    masterStorytellerDesc: 'You created a whole story!',
  },

  users: {
    studentQR: 'Student (QR)',
    studentUser: 'Student User',
    teacherUser: 'Teacher User',
  },
};

const zhHK: Translations = {
  welcome: '歡迎',
  logout: '登出',
  switchAccount: '切換帳戶',
  save: '儲存',
  cancel: '取消',
  confirm: '確認',
  delete: '刪除',
  edit: '編輯',
  back: '返回',
  next: '下一步',
  previous: '上一步',
  exit: '退出',
  close: '關閉',
  loading: '載入中...',

  login: {
    title: '故事小夥伴',
    subtitle: '一起來創作故事啦！',
    password: '密碼登入',
    qrCode: '二維碼登入',
    username: '用戶名',
    yourName: '你的名字（例如：小明）',
    signUp: '註冊',
    logIn: '登入',
    noAccount: '還沒有帳戶？',
    hasAccount: '已有帳戶？',
    simulateScan: '模擬掃描',
    showBadge: '將你的班級徽章對準鏡頭！',
    student: '學生',
    teacher: '老師',
    tester: '測試員',
  },

  dashboard: {
    welcomeUser: '你好，{name}！',
    readyMagic: '準備好創造魔法了嗎？',
    createNew: '創作新故事',
    createNewDesc: '同你的AI朋友一齊開始新冒險！',
    seeBooks: '睇返之前嘅電子書',
    seeBooksDesc: '閱讀同編輯你已經創作嘅故事。',
    adminPanel: '管理後台',
  },

  wizard: {
    greeting: '你好，今日想創作咩故事啊？',
    howOld: '你幾多歲啊？',
    yearsOld: '我 {age} 歲',
    whoInStory: '你個故事入面有邊個啊？',
    whereAreThey: '佢哋喺邊度啊？',
    whenIsIt: '係咩時候發生嘅？',
    whatHappens: '跟住發生咩事？',
    characterPlaceholder: '例如：一個勇敢嘅機械人',
    placePlaceholder: '例如：喺火星上面',
    timePlaceholder: '例如：喺未來',
    typeOrSay: '打字或者講出嚟，然後撳 Enter！',
    typeOrTapNext: '打字或者講出嚟，然後撳「下一步」！',
    needHint: '需要提示？揀一個啦！',
    howAboutThis: '呢個點啊？',
    yesOkay: '好啊，就係佢！',
    noLetMePick: '唔係，我自己揀',
    change: '換過',
    makeMagic: '創造我嘅故事！',
    creatingMagic: '正在創造魔法...',
    storyReady: '你嘅故事準備好喇！',
    whatToDo: '你想點做？',
    editing: '編輯',
    print: '列印',
    dontBeShy: '唔好怕醜！打啲字試下...',
    ideaAppears: '你嘅創意會喺呢度出現...',
    onceUponATime: '好耐好耐之前...',
    points: '分',
  },

  reader: {
    readToMe: '讀俾我聽',
    listening: '聽緊',
    page: '第',
    storyteller: '講故事姐姐',
    buddy: '小夥伴',
    grandpa: '爺爺',
    voiceControl: '語音控制',
    voiceControlOn: '語音控制已開啟',
    voiceControlOff: '語音控制已關閉',
    voiceControlHint: '講 "下一頁" 或 "上一頁"',
    textStyle: '文字樣式',
    prev: '上一頁',
    next: '下一頁',
  },

  editor: {
    editStory: '編輯故事',
    regenerateCover: '重新生成封面',
    regenerateImage: '重新生成圖片',
    titleSize: '標題大小',
    titleColor: '標題顏色',
    fontFamily: '字體',
    saveChanges: '儲存修改',
    discardChanges: '放棄修改',
    unsavedChanges: '你有未儲存嘅修改',
    saveAndExit: '儲存並退出',
    discardAll: '放棄所有修改',
  },

  library: {
    title: '我的故事庫',
    noStories: '仲未有故事！',
    noStoriesDesc: '快啲去創作你嘅第一個魔法冒險啦。',
    by: '作者：',
    read: '閱讀',
  },

  progress: {
    start: '開始',
    finish: '完成！',
  },

  admin: {
    dashboard: '管理後台',
    schools: '學校',
    classes: '班級',
    teachers: '老師',
    students: '學生',
    books: '電子書',
    addSchool: '新增學校',
    addClass: '新增班級',
    addTeacher: '新增老師',
    addStudent: '新增學生',
    importCSV: '匯入 CSV/XLSX',
    generateQR: '生成二維碼',
    viewRecords: '查看記錄',
    totalTeachers: '老師總數',
    totalStudents: '學生總數',
    totalStories: '故事總數',
    grade: '年級',
    schoolName: '學校名稱',
    className: '班級名稱',
    teacherName: '老師姓名',
    studentName: '學生姓名',
    address: '地址',
    email: '電郵',
    noSchools: '仲未有學校，新增你嘅第一間學校啦！',
    noClasses: '仲未有班級，新增你嘅第一個班級啦！',
    noTeachers: '仲未有老師，新增你嘅第一位老師啦！',
    noStudents: '仲未有學生，新增你嘅第一位學生啦！',
    noStories: '搵唔到故事。',
    selectSchool: '揀選一間學校嚟睇',
    selectClass: '揀選一個班級嚟睇',
    selectTeacher: '揀選老師',
    allSchools: '所有學校',
    allClasses: '所有班級',
    all: '全部',
    searchStories: '搜尋故事...',
    teacherId: '老師 ID',
    studentId: '學生 ID',
    noEmail: '無電郵',
    ageGroups: {
      toddler: '3~4 歲',
      earlyReader: '4~5 歲',
      preTeen: '5~6 歲',
    },
  },

  editorExt: {
    sections: '章節',
    bookCover: '書本封面',
    storyPages: '故事頁面',
    pages: '頁面',
    pageNum: '第',
    regenerateArt: '重新生成插圖',
    storyText: '故事文字',
    redrawPicture: '重畫圖片',
    rewriteText: '重寫文字',
  },

  qrCode: {
    scan: '掃描二維碼',
    tryAgain: '再試一次',
    download: '下載二維碼',
  },

  stylePicker: {
    comicSans: '漫畫字體',
    sansSerif: '無襯線體',
    serif: '襯線體',
    purple: '紫色',
    blue: '藍色',
    pink: '粉紅色',
    green: '綠色',
    yellow: '黃色',
    dark: '深色',
  },

  voice: {
    listening: '聽緊...',
    processing: '處理中...',
    tapToSpeak: '撳一下講嘢',
    nextPage: '下一頁',
    prevPage: '上一頁',
    exitCommand: '退出',
  },

  alerts: {
    enterUsernamePassword: '請輸入用戶名同密碼！',
    enterYourName: '請輸入你嘅名字！',
    accountCreated: '已為 {name} 創建帳戶！請登入。',
    invalidQRCode: '二維碼格式無效',
    couldNotRegenerateCover: '未能重新生成封面。',
    couldNotRegenerateImage: '未能重新生成圖片。',
    couldNotRewriteText: '未能重寫文字。',
    couldNotPlayAudio: '未能播放音頻，請再試一次。',
    cameraAccessError: '無法訪問相機，請檢查權限設置。',
  },

  badges: {
    newBadge: '新徽章！',
    awesome: '太棒喇！',
    characterCreator: '角色創作者',
    characterCreatorDesc: '你創造咗一個新朋友！',
    worldBuilder: '世界建造者',
    worldBuilderDesc: '你發現咗一個新地方！',
    masterStoryteller: '故事大師',
    masterStorytellerDesc: '你創作咗一個完整嘅故事！',
  },

  users: {
    studentQR: '學生（二維碼）',
    studentUser: '學生用戶',
    teacherUser: '老師用戶',
  },
};

const zhCN: Translations = {
  welcome: '欢迎',
  logout: '退出登录',
  switchAccount: '切换账户',
  save: '保存',
  cancel: '取消',
  confirm: '确认',
  delete: '删除',
  edit: '编辑',
  back: '返回',
  next: '下一步',
  previous: '上一步',
  exit: '退出',
  close: '关闭',
  loading: '加载中...',

  login: {
    title: '故事小伙伴',
    subtitle: '一起来创作故事吧！',
    password: '密码登录',
    qrCode: '二维码登录',
    username: '用户名',
    yourName: '你的名字（例如：小明）',
    signUp: '注册',
    logIn: '登录',
    noAccount: '还没有账户？',
    hasAccount: '已有账户？',
    simulateScan: '模拟扫描',
    showBadge: '将你的班级徽章对准镜头！',
    student: '学生',
    teacher: '老师',
    tester: '测试员',
  },

  dashboard: {
    welcomeUser: '你好，{name}！',
    readyMagic: '准备好创造魔法了吗？',
    createNew: '创作新故事',
    createNewDesc: '和你的AI朋友一起开始新冒险！',
    seeBooks: '查看之前的电子书',
    seeBooksDesc: '阅读和编辑你已经创作的故事。',
    adminPanel: '管理后台',
  },

  wizard: {
    greeting: '你好，今天想创作什么故事呢？',
    howOld: '你几岁了？',
    yearsOld: '我 {age} 岁',
    whoInStory: '你的故事里有谁？',
    whereAreThey: '他们在哪里？',
    whenIsIt: '是什么时候发生的？',
    whatHappens: '接下来发生什么？',
    characterPlaceholder: '例如：一个勇敢的机器人',
    placePlaceholder: '例如：在火星上',
    timePlaceholder: '例如：在未来',
    typeOrSay: '打字或说出来，然后按 Enter！',
    typeOrTapNext: '打字或说出来，然后点“下一步”！',
    needHint: '需要提示？选一个吧！',
    howAboutThis: '这个怎么样？',
    yesOkay: '好的，就是它！',
    noLetMePick: '不，让我自己选',
    change: '换一个',
    makeMagic: '创造我的故事！',
    creatingMagic: '正在创造魔法...',
    storyReady: '你的故事准备好了！',
    whatToDo: '你想怎么做？',
    editing: '编辑',
    print: '打印',
    dontBeShy: '别害羞！打点字试试...',
    ideaAppears: '你的创意会在这里出现...',
    onceUponATime: '很久很久以前...',
    points: '分',
  },

  reader: {
    readToMe: '读给我听',
    listening: '正在听',
    page: '第',
    storyteller: '讲故事姐姐',
    buddy: '小伙伴',
    grandpa: '爷爷',
    voiceControl: '语音控制',
    voiceControlOn: '语音控制已开启',
    voiceControlOff: '语音控制已关闭',
    voiceControlHint: '说 "下一页" 或 "上一页"',
    textStyle: '文字样式',
    prev: '上一页',
    next: '下一页',
  },

  editor: {
    editStory: '编辑故事',
    regenerateCover: '重新生成封面',
    regenerateImage: '重新生成图片',
    titleSize: '标题大小',
    titleColor: '标题颜色',
    fontFamily: '字体',
    saveChanges: '保存修改',
    discardChanges: '放弃修改',
    unsavedChanges: '你有未保存的修改',
    saveAndExit: '保存并退出',
    discardAll: '放弃所有修改',
  },

  library: {
    title: '我的故事库',
    noStories: '还没有故事！',
    noStoriesDesc: '快去创作你的第一个魔法冒险吧。',
    by: '作者：',
    read: '阅读',
  },

  progress: {
    start: '开始',
    finish: '完成！',
  },

  admin: {
    dashboard: '管理后台',
    schools: '学校',
    classes: '班级',
    teachers: '老师',
    students: '学生',
    books: '电子书',
    addSchool: '添加学校',
    addClass: '添加班级',
    addTeacher: '添加老师',
    addStudent: '添加学生',
    importCSV: '导入 CSV/XLSX',
    generateQR: '生成二维码',
    viewRecords: '查看记录',
    totalTeachers: '老师总数',
    totalStudents: '学生总数',
    totalStories: '故事总数',
    grade: '年级',
    schoolName: '学校名称',
    className: '班级名称',
    teacherName: '老师姓名',
    studentName: '学生姓名',
    address: '地址',
    email: '邮箱',
    noSchools: '还没有学校，添加你的第一所学校吧！',
    noClasses: '还没有班级，添加你的第一个班级吧！',
    noTeachers: '还没有老师，添加你的第一位老师吧！',
    noStudents: '还没有学生，添加你的第一位学生吧！',
    noStories: '没有找到故事。',
    selectSchool: '选择一所学校查看',
    selectClass: '选择一个班级查看',
    selectTeacher: '选择老师',
    allSchools: '所有学校',
    allClasses: '所有班级',
    all: '全部',
    searchStories: '搜索故事...',
    teacherId: '老师 ID',
    studentId: '学生 ID',
    noEmail: '无邮箱',
    ageGroups: {
      toddler: '3~4 岁',
      earlyReader: '4~5 岁',
      preTeen: '5~6 岁',
    },
  },

  editorExt: {
    sections: '章节',
    bookCover: '书本封面',
    storyPages: '故事页面',
    pages: '页面',
    pageNum: '第',
    regenerateArt: '重新生成插图',
    storyText: '故事文字',
    redrawPicture: '重画图片',
    rewriteText: '重写文字',
  },

  qrCode: {
    scan: '扫描二维码',
    tryAgain: '重试',
    download: '下载二维码',
  },

  stylePicker: {
    comicSans: '漫画字体',
    sansSerif: '无衬线体',
    serif: '衬线体',
    purple: '紫色',
    blue: '蓝色',
    pink: '粉红色',
    green: '绿色',
    yellow: '黄色',
    dark: '深色',
  },

  voice: {
    listening: '正在听...',
    processing: '处理中...',
    tapToSpeak: '点击说话',
    nextPage: '下一页',
    prevPage: '上一页',
    exitCommand: '退出',
  },

  alerts: {
    enterUsernamePassword: '请输入用户名和密码！',
    enterYourName: '请输入你的名字！',
    accountCreated: '已为 {name} 创建账户！请登录。',
    invalidQRCode: '二维码格式无效',
    couldNotRegenerateCover: '无法重新生成封面。',
    couldNotRegenerateImage: '无法重新生成图片。',
    couldNotRewriteText: '无法重写文字。',
    couldNotPlayAudio: '无法播放音频，请重试。',
    cameraAccessError: '无法访问摄像头，请检查权限设置。',
  },

  badges: {
    newBadge: '新徽章！',
    awesome: '太棒了！',
    characterCreator: '角色创作者',
    characterCreatorDesc: '你创造了一个新朋友！',
    worldBuilder: '世界建造者',
    worldBuilderDesc: '你发现了一个新地方！',
    masterStoryteller: '故事大师',
    masterStorytellerDesc: '你创作了一个完整的故事！',
  },

  users: {
    studentQR: '学生（二维码）',
    studentUser: '学生用户',
    teacherUser: '老师用户',
  },
};

export const translations: Record<Language, Translations> = {
  'en': en,
  'zh-HK': zhHK,
  'zh-CN': zhCN,
};

export const languageNames: Record<Language, string> = {
  'en': 'English',
  'zh-HK': '繁體中文',
  'zh-CN': '简体中文',
};

// Helper function to get translation with variable replacement
export const t = (translations: Translations, key: string, vars?: Record<string, string>): string => {
  const keys = key.split('.');
  let value: any = translations;

  for (const k of keys) {
    value = value?.[k];
  }

  if (typeof value !== 'string') return key;

  if (vars) {
    return Object.entries(vars).reduce(
      (str, [k, v]) => str.replace(`{${k}}`, v),
      value
    );
  }

  return value;
};
