import { GoogleGenAI, Modality } from "@google/genai";
import { AgeGroup } from "../types";
import { getPromptTemplateValue, parseJsonPromptTemplate, renderPromptTemplate } from "./promptService";

// Initialize Gemini Client lazily to prevent app crash when API key is missing
let ai: GoogleGenAI | null = null;

const getAI = (): GoogleGenAI | null => {
  if (ai) return ai;
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    console.warn("Gemini API Key not set. AI features will use mock data.");
    return null;
  }
  const baseUrl = process.env.GEMINI_BASE_URL;
  ai = new GoogleGenAI({
    apiKey,
    httpOptions: baseUrl ? { baseUrl } : undefined,
  });
  return ai;
};

/**
 * Generate an image based on a prompt suitable for children's books.
 * Uses Imagen 4 Ultra for high-quality image generation.
 */
export const generateImage = async (prompt: string, style?: string): Promise<string> => {
  const client = getAI();
  const resolvedStyle = style || await getPromptTemplateValue('image_generation_default_style');
  const finalPrompt = await renderPromptTemplate('image_generation_suffix', {
    prompt,
    style: resolvedStyle,
  });
  if (!client) {
    // Return placeholder image when no API key
    return `https://picsum.photos/seed/${encodeURIComponent(prompt).slice(0, 10)}/512/512`;
  }
  try {
    const response = await client.models.generateImages({
      model: 'imagen-4.0-generate-001',
      prompt: finalPrompt,
      config: {
        numberOfImages: 1,
      },
    });

    const image = response.generatedImages?.[0];
    if (image?.image?.imageBytes) {
      return `data:image/png;base64,${image.image.imageBytes}`;
    }

    throw new Error("No image data found in response");

  } catch (error) {
    console.error("Image generation failed, falling back to placeholder.", error);
    // Robust fallback to prevent app crash
    return `https://picsum.photos/seed/${encodeURIComponent(prompt).slice(0, 10)}/512/512`;
  }
};

/**
 * Generate text completion or suggestions.
 */
export const generateText = async (prompt: string, ageGroup: AgeGroup): Promise<string> => {
  const client = getAI();
  if (!client) {
    return renderPromptTemplate('text_generation_no_ai_fallback', {});
  }
  try {
    const contents = await renderPromptTemplate('text_generation_task', {
      ageGroup,
      task: prompt,
    });
    const response = await client.models.generateContent({
      model: 'gemini-2.5-flash',
      contents,
    });
    return response.text || "";
  } catch (error) {
    console.error("Text generation error:", error);
    return renderPromptTemplate('text_generation_error_fallback', {});
  }
};

/**
 * Generate 3 simple suggestions for a user who is stuck.
 */
export const generateSuggestions = async (context: 'character' | 'place' | 'time', ageGroup: AgeGroup): Promise<string[]> => {
    const client = getAI();
    if (!client) {
      return parseJsonPromptTemplate<string[]>(`suggestions_fallback_${context}`, []);
    }
    try {
        const prompt = await renderPromptTemplate('suggestions_generation', {
          context,
          ageGroup,
        });

        const response = await client.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: { responseMimeType: 'application/json' }
        });

        const text = response.text;
        if (!text) {
          return parseJsonPromptTemplate<string[]>('suggestions_empty_fallback', []);
        }
        return JSON.parse(text) as string[];
    } catch (e) {
        return parseJsonPromptTemplate<string[]>('suggestions_error_fallback', []);
    }
}

/**
 * Generate Audio (TTS) for a page.
 * Voices: 'Kore' (Gentle/Female), 'Puck' (Playful), 'Fenrir' (Deep/Male), 'Zephyr', 'Charon'
 */
export const generateSpeech = async (text: string, voiceName: string = 'Kore'): Promise<string | undefined> => {
  const client = getAI();
  if (!client) {
    return undefined;
  }
  try {
    const contents = await renderPromptTemplate('speech_generation_prompt', {
      text,
    });
    const response = await client.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text: contents }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName }, 
          },
        },
      },
    });
    
    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    return base64Audio;
  } catch (error) {
    console.error("Speech generation failed:", error);
    return undefined;
  }
};

/**
 * Generate a full story page content (text + image prompt) based on inputs.
 */
export const generateStorySegment = async (
    inputs: { character: string; place: string; time: string; plot: string },
    ageGroup: AgeGroup
): Promise<{ text: string; imagePrompt: string }> => {
    const client = getAI();
    if (!client) {
      return {
        text: await renderPromptTemplate('story_segment_no_ai_fallback_text', inputs),
        imagePrompt: await renderPromptTemplate('story_segment_no_ai_fallback_image_prompt', inputs),
      };
    }
    const prompt = await renderPromptTemplate('story_segment_generation', {
      ageGroup,
      character: inputs.character,
      place: inputs.place,
      time: inputs.time,
      plot: inputs.plot,
    });

    const response = await client.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: { responseMimeType: 'application/json' }
    });

    try {
        const data = JSON.parse(response.text || "{}");
        return {
            text: data.storyText || await renderPromptTemplate('story_segment_error_fallback_text', inputs),
            imagePrompt: data.imageDescription || await renderPromptTemplate('story_segment_error_fallback_image_prompt', inputs)
        };
    } catch (e) {
        return {
          text: await renderPromptTemplate('story_segment_error_fallback_text', inputs),
          imagePrompt: await renderPromptTemplate('story_segment_error_fallback_image_prompt', inputs),
        };
    }
}

/**
 * Get the number of pages to generate based on age group.
 * - 3~4 years: 5 pages
 * - 4~5 years: 8 pages
 * - 5~6 years: 12 pages
 */
export const getPageCountForAge = (ageGroup: AgeGroup): number => {
    switch (ageGroup) {
        case AgeGroup.TODDLER:
            return 5;
        case AgeGroup.EARLY_READER:
            return 8;
        case AgeGroup.PRE_TEEN:
            return 12;
        default:
            return 5;
    }
};

/**
 * Generate multiple pages for a complete story.
 * Calls onProgress callback for each page generated.
 */
export const generateMultiplePages = async (
    inputs: { character: string; place: string; time: string; plot: string },
    ageGroup: AgeGroup,
    onProgress?: (current: number, total: number) => void
): Promise<{ text: string; imageUrl: string; imagePrompt: string }[]> => {
    const pageCount = getPageCountForAge(ageGroup);
    const pages: { text: string; imageUrl: string; imagePrompt: string }[] = [];

    const client = getAI();

    // Generate story outline first
    let storyOutline: string[] = [];

    if (client) {
        try {
            const outlinePrompt = await renderPromptTemplate('story_outline_generation', {
              pageCount,
              character: inputs.character,
              place: inputs.place,
              time: inputs.time,
              plot: inputs.plot,
              ageGroup,
            });

            const response = await client.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: outlinePrompt,
                config: { responseMimeType: 'application/json' }
            });

            storyOutline = JSON.parse(response.text || "[]");
        } catch (e) {
            console.error('Failed to generate outline:', e);
        }
    }

    // Fallback outline if AI failed
    if (storyOutline.length === 0) {
        storyOutline = await Promise.all(
          Array.from({ length: pageCount }, async (_, i) => {
            if (i === 0) {
              return renderPromptTemplate('story_outline_fallback_intro', {
                character: inputs.character,
              });
            }

            if (i === pageCount - 1) {
              return renderPromptTemplate('story_outline_fallback_ending', {
                character: inputs.character,
              });
            }

            return renderPromptTemplate('story_outline_fallback_middle', {
              pageNumber: i + 1,
            });
          }),
        );
    }

    // Generate each page
    for (let i = 0; i < pageCount; i++) {
        onProgress?.(i + 1, pageCount);

        const pageContext = storyOutline[i] || await renderPromptTemplate('story_outline_missing_page_fallback', {
          pageNumber: i + 1,
        });

        const segment = await generateStorySegment({
            character: inputs.character,
            place: inputs.place,
            time: inputs.time,
            plot: pageContext
        }, ageGroup);

        const imageUrl = await generateImage(segment.imagePrompt);

        pages.push({
            text: segment.text,
            imageUrl,
            imagePrompt: segment.imagePrompt
        });

        // Small delay to avoid rate limiting
        if (i < pageCount - 1) {
            await new Promise(resolve => setTimeout(resolve, 500));
        }
    }

    return pages;
}
