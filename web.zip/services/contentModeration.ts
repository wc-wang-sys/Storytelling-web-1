import { GoogleGenAI } from '@google/genai';
import { Language } from './i18n';
import { renderPromptTemplate } from './promptService';

export interface SensitiveInputGuidance {
  title: string;
  subtitle: string;
  intro: string;
  suggestions: string[];
}

export type ModerationCategory =
  | 'violence'
  | 'terror'
  | 'horror'
  | 'weapon'
  | 'bullying'
  | 'self_harm'
  | 'hate'
  | 'adult'
  | 'dangerous';

export interface ModerationResult {
  safe: boolean;
  source: 'keyword' | 'ai' | 'fallback';
  categories: ModerationCategory[];
  reason?: string;
  matchedTerms?: string[];
}

const GUIDANCE_BY_LANGUAGE: Record<Language, SensitiveInputGuidance> = {
  en: {
    title: 'That idea feels a little too scary or unfriendly.',
    subtitle: "Let's make a warm, happy, and brave story instead.",
    intro: 'You can try one of these directions:',
    suggestions: [
      'Little animals helping each other',
      'Children going on an adventure together',
      'Family and friends spending happy time together',
      'Using wisdom and kindness to solve a problem',
    ],
  },
  'zh-HK': {
    title: '這個想法好像有點嚇人或不太友好哦～',
    subtitle: '我們來創作一個溫暖、快樂、充滿勇氣的故事吧！',
    intro: '可以試試這些方向：',
    suggestions: [
      '小動物互相幫助',
      '小朋友一起冒險',
      '家人和朋友開心相處',
      '用智慧和善良解決問題',
    ],
  },
  'zh-CN': {
    title: '这个想法好像有点吓人或不太友好哦～',
    subtitle: '我们来创作一个温暖、快乐、充满勇气的故事吧！',
    intro: '可以试试这些方向：',
    suggestions: [
      '小动物互相帮助',
      '小朋友一起冒险',
      '家人和朋友开心相处',
      '用智慧和善良解决问题',
    ],
  },
};

interface KeywordRule {
  category: ModerationCategory;
  phrases?: string[];
  patterns?: RegExp[];
}

interface AiModerationPayload {
  safe?: unknown;
  categories?: unknown;
  reason?: unknown;
}

const MODERATION_MODEL = 'gemini-2.5-flash';
const SAFE_RESULT: ModerationResult = {
  safe: true,
  source: 'fallback',
  categories: [],
};

const KEYWORD_RULES: KeywordRule[] = [
  {
    category: 'violence',
    phrases: ['暴力', '血腥', '流血', '鲜血', '尸体', '死亡', '死掉', '打死', '杀死', '谋杀', '捅死', '砍死', '残忍'],
    patterns: [/\b(?:kill|killing|murder|murderer|blood|bloody|death|dead|corpse|gore|violent|violence)\b/i],
  },
  {
    category: 'self_harm',
    phrases: ['自杀', '轻生', '割腕', '上吊'],
    patterns: [/\b(?:suicide|self-harm|self harm|cut myself|hurt myself)\b/i],
  },
  {
    category: 'horror',
    phrases: ['恐怖', '惊悚', '吓人', '鬼屋', '鬼怪', '僵尸', '骷髅', '吸血鬼', '恶魔', '诅咒', '噩梦'],
    patterns: [/\b(?:horror|terrifying|scary|frightening|ghost|haunted|zombie|skeleton|vampire|demon|curse)\b/i],
  },
  {
    category: 'terror',
    phrases: ['恐袭', '恐怖袭击', '炸学校', '炸教室'],
    patterns: [/\b(?:terror|terrorist|terrorism)\b/i],
  },
  {
    category: 'weapon',
    phrases: ['手枪', '枪', '匕首', '大刀', '刀砍', '炸弹', '爆炸', '武器'],
    patterns: [/\b(?:weapon|gun|knife|bomb|explode|explosion|grenade|shoot|shooting)\b/i],
  },
  {
    category: 'bullying',
    phrases: ['威胁', '绑架', '打架', '吵架', '欺负', '霸凌', '报复', '复仇'],
    patterns: [/\b(?:threat|threaten|kidnap|fight|abuse|bully|bullying|revenge)\b/i],
  },
  {
    category: 'hate',
    phrases: ['仇恨', '歧视'],
    patterns: [/\b(?:hate|racist|discrimination)\b/i],
  },
  {
    category: 'adult',
    phrases: ['色情', '成人内容'],
    patterns: [/\b(?:sexual|sex|porn|nude|naked)\b/i],
  },
  {
    category: 'dangerous',
    phrases: ['下毒', '纵火'],
    patterns: [/\b(?:poison|arson|set fire)\b/i],
  },
];

const ALLOWED_CATEGORIES = new Set<ModerationCategory>([
  'violence',
  'terror',
  'horror',
  'weapon',
  'bullying',
  'self_harm',
  'hate',
  'adult',
  'dangerous',
]);

let moderationClient: GoogleGenAI | null | undefined;
const moderationCache = new Map<string, Promise<ModerationResult>>();

const normalizeInput = (input: string) => input.toLowerCase().replace(/\s+/g, '');

const getModerationClient = () => {
  if (moderationClient !== undefined) {
    return moderationClient;
  }

  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    moderationClient = null;
    return moderationClient;
  }

  const baseUrl = process.env.GEMINI_BASE_URL;
  moderationClient = new GoogleGenAI({
    apiKey,
    httpOptions: baseUrl ? { baseUrl } : undefined,
  });
  return moderationClient;
};

const detectKeywordContent = (input: string): ModerationResult => {
  const normalized = normalizeInput(input);
  if (!normalized) {
    return SAFE_RESULT;
  }

  const categories = new Set<ModerationCategory>();
  const matchedTerms = new Set<string>();

  KEYWORD_RULES.forEach((rule) => {
    rule.phrases?.forEach((phrase) => {
      if (normalized.includes(phrase)) {
        categories.add(rule.category);
        matchedTerms.add(phrase);
      }
    });

    rule.patterns?.forEach((pattern) => {
      const match = input.match(pattern);
      if (match) {
        categories.add(rule.category);
        matchedTerms.add(match[0]);
      }
    });
  });

  if (categories.size === 0) {
    return SAFE_RESULT;
  }

  return {
    safe: false,
    source: 'keyword',
    categories: Array.from(categories),
    reason: 'Detected blocked keywords or phrases.',
    matchedTerms: Array.from(matchedTerms),
  };
};

const normalizeAiCategory = (value: string): ModerationCategory | null => {
  const normalized = value.trim().toLowerCase().replace(/[\s-]+/g, '_');

  const mappedValue =
    normalized === 'violence' || normalized === 'violent'
      ? 'violence'
      : normalized === 'terror' || normalized === 'terrorism'
        ? 'terror'
        : normalized === 'horror' || normalized === 'scary'
          ? 'horror'
          : normalized === 'weapon' || normalized === 'weapons'
            ? 'weapon'
            : normalized === 'bullying' || normalized === 'bully'
              ? 'bullying'
              : normalized === 'self_harm' || normalized === 'selfharm' || normalized === 'suicide'
                ? 'self_harm'
                : normalized === 'hate' || normalized === 'hate_speech'
                  ? 'hate'
                  : normalized === 'adult' || normalized === 'sexual'
                    ? 'adult'
                    : normalized === 'dangerous' || normalized === 'danger'
                      ? 'dangerous'
                      : normalized;

  return ALLOWED_CATEGORIES.has(mappedValue as ModerationCategory) ? (mappedValue as ModerationCategory) : null;
};

const parseAiModerationPayload = (rawText: string): ModerationResult | null => {
  const cleaned = rawText
    .trim()
    .replace(/^```json\s*/i, '')
    .replace(/^```\s*/i, '')
    .replace(/\s*```$/, '');

  let payload: AiModerationPayload;
  try {
    payload = JSON.parse(cleaned) as AiModerationPayload;
  } catch {
    return null;
  }

  const categories = Array.isArray(payload.categories)
    ? payload.categories
        .map((item) => (typeof item === 'string' ? normalizeAiCategory(item) : null))
        .filter((item): item is ModerationCategory => Boolean(item))
    : [];

  const safe = typeof payload.safe === 'boolean' ? payload.safe : categories.length === 0;
  const reason = typeof payload.reason === 'string' ? payload.reason.trim() : undefined;

  return {
    safe,
    source: 'ai',
    categories,
    reason,
  };
};

const moderateWithAi = async (input: string): Promise<ModerationResult> => {
  const client = getModerationClient();
  if (!client) {
    return SAFE_RESULT;
  }

  try {
    const prompt = await renderPromptTemplate('input_moderation_prompt', {
      input,
    });

    const response = await client.models.generateContent({
      model: MODERATION_MODEL,
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const parsed = response.text ? parseAiModerationPayload(response.text) : null;
    return parsed || SAFE_RESULT;
  } catch (error) {
    console.warn('AI moderation failed, falling back to keyword-only moderation.', error);
    return SAFE_RESULT;
  }
};

export const containsSensitiveContent = (input: string) => {
  return !detectKeywordContent(input).safe;
};

export const moderateStudentInput = async (input: string): Promise<ModerationResult> => {
  const trimmedInput = input.trim();
  if (!trimmedInput) {
    return SAFE_RESULT;
  }

  const keywordResult = detectKeywordContent(trimmedInput);
  if (!keywordResult.safe) {
    return keywordResult;
  }

  const cacheKey = normalizeInput(trimmedInput);
  const cachedResult = moderationCache.get(cacheKey);
  if (cachedResult) {
    return cachedResult;
  }

  const moderationPromise = moderateWithAi(trimmedInput)
    .then((result) => {
      if (result.safe) {
        return {
          ...result,
          source: result.source === 'fallback' ? 'fallback' : 'ai',
        };
      }

      return result;
    })
    .catch(() => SAFE_RESULT);

  moderationCache.set(cacheKey, moderationPromise);
  return moderationPromise;
};

export const getSensitiveInputGuidance = (language: Language): SensitiveInputGuidance => {
  return GUIDANCE_BY_LANGUAGE[language] || GUIDANCE_BY_LANGUAGE['zh-CN'];
};
