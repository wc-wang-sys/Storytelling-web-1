// Mock data service for StoryBuddy
// Simulates backend data with localStorage persistence

import { Story, AgeGroup } from '../types';

// Types for admin management
export interface School {
  id: string;
  name: string;
  address: string;
  createdAt: number;
}

export interface Class {
  id: string;
  schoolId: string;
  name: string;
  grade: 'K1' | 'K2' | 'K3';
  createdAt: number;
}

export interface Teacher {
  id: string;
  schoolId: string;
  classIds: string[];
  name: string;
  email: string;
  createdAt: number;
}

export interface Student {
  id: string;
  schoolId: string;
  classId: string;
  teacherId: string;
  name: string;
  ageGroup: AgeGroup;
  createdAt: number;
}

export interface StoryRecord {
  id: string;
  storyId: string;
  studentId: string;
  studentName: string;
  classId: string;
  schoolId: string;
  title: string;
  coverImage: string;
  createdAt: number;
}

// Storage keys
const STORAGE_KEYS = {
  SCHOOLS: 'storybuddy_schools',
  CLASSES: 'storybuddy_classes',
  TEACHERS: 'storybuddy_teachers',
  STUDENTS: 'storybuddy_students',
  STORIES: 'storybuddy_stories',
  STORY_RECORDS: 'storybuddy_story_records',
};

// Helper functions
const loadFromStorage = <T>(key: string, defaultValue: T[]): T[] => {
  try {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : defaultValue;
  } catch {
    return defaultValue;
  }
};

const saveToStorage = <T>(key: string, data: T[]): void => {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (e) {
    console.error('Failed to save to localStorage:', e);
  }
};

const normalizeAgeGroup = (ageGroup: string | undefined): AgeGroup => {
  switch (ageGroup) {
    case AgeGroup.TODDLER:
    case '3-5':
      return AgeGroup.TODDLER;
    case AgeGroup.EARLY_READER:
    case '5-7':
      return AgeGroup.EARLY_READER;
    case AgeGroup.PRE_TEEN:
    case '8-10':
      return AgeGroup.PRE_TEEN;
    default:
      return AgeGroup.TODDLER;
  }
};

// Initialize with demo data if empty
const initializeDemoData = () => {
  const schools = loadFromStorage<School>(STORAGE_KEYS.SCHOOLS, []);
  if (schools.length === 0) {
    // Demo Schools
    const demoSchools: School[] = [
      { id: 'school_1', name: '香港幼稚園', address: '香港中環某街1號', createdAt: Date.now() },
      { id: 'school_2', name: 'Happy Kids Kindergarten', address: '九龍尖沙咀某道2號', createdAt: Date.now() },
    ];
    saveToStorage(STORAGE_KEYS.SCHOOLS, demoSchools);

    // Demo Classes
    const demoClasses: Class[] = [
      { id: 'class_1', schoolId: 'school_1', name: 'K1A', grade: 'K1', createdAt: Date.now() },
      { id: 'class_2', schoolId: 'school_1', name: 'K2A', grade: 'K2', createdAt: Date.now() },
      { id: 'class_3', schoolId: 'school_1', name: 'K3A', grade: 'K3', createdAt: Date.now() },
      { id: 'class_4', schoolId: 'school_2', name: 'Rainbow Class', grade: 'K1', createdAt: Date.now() },
      { id: 'class_5', schoolId: 'school_2', name: 'Sunshine Class', grade: 'K2', createdAt: Date.now() },
    ];
    saveToStorage(STORAGE_KEYS.CLASSES, demoClasses);

    // Demo Teachers
    const demoTeachers: Teacher[] = [
      { id: 'teacher_1', schoolId: 'school_1', classIds: ['class_1', 'class_2'], name: '陳老師', email: 'chan@school1.edu.hk', createdAt: Date.now() },
      { id: 'teacher_2', schoolId: 'school_1', classIds: ['class_3'], name: '李老師', email: 'lee@school1.edu.hk', createdAt: Date.now() },
      { id: 'teacher_3', schoolId: 'school_2', classIds: ['class_4', 'class_5'], name: 'Ms. Wong', email: 'wong@school2.edu.hk', createdAt: Date.now() },
    ];
    saveToStorage(STORAGE_KEYS.TEACHERS, demoTeachers);

    // Demo Students
    const demoStudents: Student[] = [
      { id: 'student_1', schoolId: 'school_1', classId: 'class_1', teacherId: 'teacher_1', name: '小明', ageGroup: AgeGroup.TODDLER, createdAt: Date.now() },
      { id: 'student_2', schoolId: 'school_1', classId: 'class_1', teacherId: 'teacher_1', name: '小紅', ageGroup: AgeGroup.TODDLER, createdAt: Date.now() },
      { id: 'student_3', schoolId: 'school_1', classId: 'class_2', teacherId: 'teacher_1', name: '小華', ageGroup: AgeGroup.EARLY_READER, createdAt: Date.now() },
      { id: 'student_4', schoolId: 'school_1', classId: 'class_3', teacherId: 'teacher_2', name: '小美', ageGroup: AgeGroup.PRE_TEEN, createdAt: Date.now() },
      { id: 'student_5', schoolId: 'school_2', classId: 'class_4', teacherId: 'teacher_3', name: 'Tommy', ageGroup: AgeGroup.TODDLER, createdAt: Date.now() },
      { id: 'student_6', schoolId: 'school_2', classId: 'class_5', teacherId: 'teacher_3', name: 'Emily', ageGroup: AgeGroup.EARLY_READER, createdAt: Date.now() },
    ];
    saveToStorage(STORAGE_KEYS.STUDENTS, demoStudents);

    // Demo Story Records
    const demoRecords: StoryRecord[] = [
      { id: 'record_1', storyId: 'story_1', studentId: 'student_1', studentName: '小明', classId: 'class_1', schoolId: 'school_1', title: '勇敢的小兔子', coverImage: 'https://picsum.photos/seed/story1/300/300', createdAt: Date.now() - 86400000 },
      { id: 'record_2', storyId: 'story_2', studentId: 'student_2', studentName: '小紅', classId: 'class_1', schoolId: 'school_1', title: '太空冒險', coverImage: 'https://picsum.photos/seed/story2/300/300', createdAt: Date.now() - 172800000 },
      { id: 'record_3', storyId: 'story_3', studentId: 'student_5', studentName: 'Tommy', classId: 'class_4', schoolId: 'school_2', title: 'The Magic Garden', coverImage: 'https://picsum.photos/seed/story3/300/300', createdAt: Date.now() - 259200000 },
    ];
    saveToStorage(STORAGE_KEYS.STORY_RECORDS, demoRecords);
  }
};

// Initialize demo data on module load
initializeDemoData();

// ============= SCHOOL CRUD =============
export const getSchools = (): School[] => {
  return loadFromStorage<School>(STORAGE_KEYS.SCHOOLS, []);
};

export const addSchool = (school: Omit<School, 'id' | 'createdAt'>): School => {
  const schools = getSchools();
  const newSchool: School = {
    ...school,
    id: `school_${Date.now()}`,
    createdAt: Date.now(),
  };
  schools.push(newSchool);
  saveToStorage(STORAGE_KEYS.SCHOOLS, schools);
  return newSchool;
};

export const updateSchool = (id: string, updates: Partial<School>): School | null => {
  const schools = getSchools();
  const index = schools.findIndex(s => s.id === id);
  if (index === -1) return null;
  schools[index] = { ...schools[index], ...updates };
  saveToStorage(STORAGE_KEYS.SCHOOLS, schools);
  return schools[index];
};

export const deleteSchool = (id: string): boolean => {
  const schools = getSchools();
  const filtered = schools.filter(s => s.id !== id);
  if (filtered.length === schools.length) return false;
  saveToStorage(STORAGE_KEYS.SCHOOLS, filtered);
  // Also delete related classes, teachers, students
  const classes = getClasses().filter(c => c.schoolId !== id);
  saveToStorage(STORAGE_KEYS.CLASSES, classes);
  const teachers = getTeachers().filter(t => t.schoolId !== id);
  saveToStorage(STORAGE_KEYS.TEACHERS, teachers);
  const students = getStudents().filter(s => s.schoolId !== id);
  saveToStorage(STORAGE_KEYS.STUDENTS, students);
  return true;
};

// ============= CLASS CRUD =============
export const getClasses = (schoolId?: string): Class[] => {
  const classes = loadFromStorage<Class>(STORAGE_KEYS.CLASSES, []);
  return schoolId ? classes.filter(c => c.schoolId === schoolId) : classes;
};

export const addClass = (cls: Omit<Class, 'id' | 'createdAt'>): Class => {
  const classes = getClasses();
  const newClass: Class = {
    ...cls,
    id: `class_${Date.now()}`,
    createdAt: Date.now(),
  };
  classes.push(newClass);
  saveToStorage(STORAGE_KEYS.CLASSES, classes);
  return newClass;
};

export const updateClass = (id: string, updates: Partial<Class>): Class | null => {
  const classes = getClasses();
  const index = classes.findIndex(c => c.id === id);
  if (index === -1) return null;
  classes[index] = { ...classes[index], ...updates };
  saveToStorage(STORAGE_KEYS.CLASSES, classes);
  return classes[index];
};

export const deleteClass = (id: string): boolean => {
  const classes = getClasses();
  const filtered = classes.filter(c => c.id !== id);
  if (filtered.length === classes.length) return false;
  saveToStorage(STORAGE_KEYS.CLASSES, filtered);
  // Update teachers to remove this class from their classIds
  const teachers = getTeachers().map(t => ({
    ...t,
    classIds: t.classIds.filter(cid => cid !== id)
  }));
  saveToStorage(STORAGE_KEYS.TEACHERS, teachers);
  // Delete students in this class
  const students = getStudents().filter(s => s.classId !== id);
  saveToStorage(STORAGE_KEYS.STUDENTS, students);
  return true;
};

// ============= TEACHER CRUD =============
export const getTeachers = (schoolId?: string): Teacher[] => {
  const teachers = loadFromStorage<Teacher>(STORAGE_KEYS.TEACHERS, []);
  return schoolId ? teachers.filter(t => t.schoolId === schoolId) : teachers;
};

export const addTeacher = (teacher: Omit<Teacher, 'id' | 'createdAt'>): Teacher => {
  const teachers = getTeachers();
  const newTeacher: Teacher = {
    ...teacher,
    id: `teacher_${Date.now()}`,
    createdAt: Date.now(),
  };
  teachers.push(newTeacher);
  saveToStorage(STORAGE_KEYS.TEACHERS, teachers);
  return newTeacher;
};

export const updateTeacher = (id: string, updates: Partial<Teacher>): Teacher | null => {
  const teachers = getTeachers();
  const index = teachers.findIndex(t => t.id === id);
  if (index === -1) return null;
  teachers[index] = { ...teachers[index], ...updates };
  saveToStorage(STORAGE_KEYS.TEACHERS, teachers);
  return teachers[index];
};

export const deleteTeacher = (id: string): boolean => {
  const teachers = getTeachers();
  const filtered = teachers.filter(t => t.id !== id);
  if (filtered.length === teachers.length) return false;
  saveToStorage(STORAGE_KEYS.TEACHERS, filtered);
  return true;
};

// ============= STUDENT CRUD =============
export const getStudents = (filters?: { schoolId?: string; classId?: string; teacherId?: string }): Student[] => {
  const storedStudents = loadFromStorage<Student>(STORAGE_KEYS.STUDENTS, []);
  let students = storedStudents.map(student => ({
    ...student,
    ageGroup: normalizeAgeGroup(student.ageGroup),
  }));

  if (students.some((student, index) => student.ageGroup !== storedStudents[index]?.ageGroup)) {
    saveToStorage(STORAGE_KEYS.STUDENTS, students);
  }

  if (filters?.schoolId) students = students.filter(s => s.schoolId === filters.schoolId);
  if (filters?.classId) students = students.filter(s => s.classId === filters.classId);
  if (filters?.teacherId) students = students.filter(s => s.teacherId === filters.teacherId);
  return students;
};

export const addStudent = (student: Omit<Student, 'id' | 'createdAt'>): Student => {
  const students = getStudents();
  const newStudent: Student = {
    ...student,
    ageGroup: normalizeAgeGroup(student.ageGroup),
    id: `student_${Date.now()}`,
    createdAt: Date.now(),
  };
  students.push(newStudent);
  saveToStorage(STORAGE_KEYS.STUDENTS, students);
  return newStudent;
};

export const updateStudent = (id: string, updates: Partial<Student>): Student | null => {
  const students = getStudents();
  const index = students.findIndex(s => s.id === id);
  if (index === -1) return null;
  students[index] = {
    ...students[index],
    ...updates,
    ageGroup: updates.ageGroup ? normalizeAgeGroup(updates.ageGroup) : students[index].ageGroup,
  };
  saveToStorage(STORAGE_KEYS.STUDENTS, students);
  return students[index];
};

export const deleteStudent = (id: string): boolean => {
  const students = getStudents();
  const filtered = students.filter(s => s.id !== id);
  if (filtered.length === students.length) return false;
  saveToStorage(STORAGE_KEYS.STUDENTS, filtered);
  return true;
};

// ============= STORY RECORDS =============
export const getStoryRecords = (filters?: { schoolId?: string; classId?: string; studentId?: string }): StoryRecord[] => {
  let records = loadFromStorage<StoryRecord>(STORAGE_KEYS.STORY_RECORDS, []);
  if (filters?.schoolId) records = records.filter(r => r.schoolId === filters.schoolId);
  if (filters?.classId) records = records.filter(r => r.classId === filters.classId);
  if (filters?.studentId) records = records.filter(r => r.studentId === filters.studentId);
  return records.sort((a, b) => b.createdAt - a.createdAt);
};

export const addStoryRecord = (record: Omit<StoryRecord, 'id'>): StoryRecord => {
  const records = getStoryRecords();
  const newRecord: StoryRecord = {
    ...record,
    id: `record_${Date.now()}`,
  };
  records.push(newRecord);
  saveToStorage(STORAGE_KEYS.STORY_RECORDS, records);
  return newRecord;
};

// ============= STATISTICS =============
export const getSchoolStats = (schoolId: string) => {
  const teachers = getTeachers(schoolId);
  const students = getStudents({ schoolId });
  const records = getStoryRecords({ schoolId });
  return {
    teacherCount: teachers.length,
    studentCount: students.length,
    storyCount: records.length,
  };
};

export const getClassStats = (classId: string) => {
  const students = getStudents({ classId });
  const records = getStoryRecords({ classId });
  return {
    studentCount: students.length,
    storyCount: records.length,
  };
};

// ============= CSV IMPORT (Simulated) =============
export const importStudentsFromCSV = (csvContent: string, schoolId: string, classId: string, teacherId: string): Student[] => {
  const lines = csvContent.trim().split('\n');
  const newStudents: Student[] = [];

  // Skip header row
  for (let i = 1; i < lines.length; i++) {
    const [name, ageGroupStr] = lines[i].split(',').map(s => s.trim());
    if (name) {
      const ageGroup = normalizeAgeGroup(ageGroupStr);

      const student = addStudent({
        schoolId,
        classId,
        teacherId,
        name,
        ageGroup,
      });
      newStudents.push(student);
    }
  }

  return newStudents;
};

export const importTeachersFromCSV = (csvContent: string, schoolId: string): Teacher[] => {
  const lines = csvContent.trim().split('\n');
  const newTeachers: Teacher[] = [];

  // Skip header row
  for (let i = 1; i < lines.length; i++) {
    const [name, email] = lines[i].split(',').map(s => s.trim());
    if (name) {
      const teacher = addTeacher({
        schoolId,
        classIds: [],
        name,
        email: email || '',
      });
      newTeachers.push(teacher);
    }
  }

  return newTeachers;
};

// ============= QR CODE DATA =============
export const generateQRData = (type: 'school' | 'teacher' | 'student', id: string): string => {
  return JSON.stringify({ type, id, app: 'storybuddy' });
};

export const parseQRData = (qrContent: string): { type: string; id: string } | null => {
  try {
    const data = JSON.parse(qrContent);
    if (data.app === 'storybuddy' && data.type && data.id) {
      return { type: data.type, id: data.id };
    }
    return null;
  } catch {
    return null;
  }
};
