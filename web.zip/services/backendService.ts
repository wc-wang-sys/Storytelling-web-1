import { Story, User } from '../types';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3030/api';
const ACCESS_TOKEN_KEY = 'storybuddy_access_token';

export interface PublicSchoolOption {
  id: string;
  name: string;
  code: string;
  address?: string;
}

export interface PublicClassOption {
  id: string;
  schoolId: string;
  name: string;
  grade: string;
}

export interface RuntimePromptMap {
  [key: string]: string;
}

export interface IflytekSpeechAuth {
  appId: string;
  url: string;
}

interface AuthResponse {
  accessToken: string;
  user: User;
}

const getErrorMessage = (error: unknown) => {
  if (error instanceof Error) {
    return error.message;
  }
  return 'Request failed';
};

const request = async <T>(endpoint: string, options: RequestInit = {}, requireAuth = true): Promise<T> => {
  const headers = new Headers(options.headers || {});
  if (!headers.has('Content-Type') && options.body) {
    headers.set('Content-Type', 'application/json');
  }

  if (requireAuth) {
    const token = getStoredToken();
    if (!token) {
      throw new Error('Please log in first');
    }
    headers.set('Authorization', `Bearer ${token}`);
  }

  const response = await fetch(`${API_BASE_URL}${endpoint}`, {
    ...options,
    headers,
  });

  const payload = await response.json().catch(() => null);
  if (!response.ok) {
    if (response.status === 401) {
      clearSession();
    }
    throw new Error(payload?.error || `HTTP ${response.status}`);
  }

  return payload.data as T;
};

const persistAuth = (data: AuthResponse) => {
  localStorage.setItem(ACCESS_TOKEN_KEY, data.accessToken);
  return data.user;
};

export const getStoredToken = () => {
  return localStorage.getItem(ACCESS_TOKEN_KEY);
};

export const clearSession = () => {
  localStorage.removeItem(ACCESS_TOKEN_KEY);
};

export const getAdminAppUrl = () => {
  return import.meta.env.VITE_ADMIN_URL || 'http://localhost:5174';
};

export const fetchCurrentUser = async () => {
  if (!getStoredToken()) {
    return null;
  }
  return request<User>('/auth/me');
};

export const loginWithPassword = async (params: { username: string; password: string }) => {
  const data = await request<AuthResponse>(
    '/auth/login/password',
    {
      method: 'POST',
      body: JSON.stringify(params),
    },
    false,
  );

  return persistAuth(data);
};

export const registerStudentAccount = async (params: {
  fullName: string;
  username: string;
  password: string;
  schoolId: string;
  classId: string;
}) => {
  const data = await request<AuthResponse>(
    '/auth/register/student',
    {
      method: 'POST',
      body: JSON.stringify(params),
    },
    false,
  );

  return persistAuth(data);
};

export const loginWithQrToken = async (token: string) => {
  const data = await request<AuthResponse>(
    '/auth/login/qr',
    {
      method: 'POST',
      body: JSON.stringify({ token }),
    },
    false,
  );

  return persistAuth(data);
};

export const fetchPublicSchools = async () => {
  return request<PublicSchoolOption[]>('/public/schools', {}, false);
};

export const fetchPublicClasses = async (schoolId: string) => {
  return request<PublicClassOption[]>(`/public/classes?schoolId=${encodeURIComponent(schoolId)}`, {}, false);
};

export const fetchPublicPromptTemplates = async () => {
  return request<RuntimePromptMap>('/public/prompts', {}, false);
};

export const fetchIflytekSpeechAuth = async () => {
  return request<IflytekSpeechAuth>('/public/speech/iflytek-auth', {}, false);
};

export const fetchScopedStories = async () => {
  return request<Story[]>('/stories?includeContent=true');
};

export const createStory = async (story: Story) => {
  return request<Story>(
    '/stories',
    {
      method: 'POST',
      body: JSON.stringify(story),
    },
  );
};

export const saveStory = async (story: Story) => {
  return request<Story>(
    `/stories/${story.id}`,
    {
      method: 'PATCH',
      body: JSON.stringify(story),
    },
  );
};

export const toErrorMessage = getErrorMessage;
