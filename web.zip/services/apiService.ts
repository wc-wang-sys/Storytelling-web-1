// API Service for StoryBuddy
// Connects frontend to real backend API

import { Story, AgeGroup } from '../types';

// API base URL - 根据环境配置
const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3030/api';

// Types for admin management (same as mockData)
export interface School {
  id: string;
  name: string;
  address: string;
  createdAt: number;
}

export interface Class {
  id: string;
  schoolId: string;
  name: string;
  grade: 'K1' | 'K2' | 'K3';
  createdAt: number;
}

export interface Teacher {
  id: string;
  schoolId: string;
  classIds: string[];
  name: string;
  email: string;
  createdAt: number;
}

export interface Student {
  id: string;
  schoolId: string;
  classId: string;
  teacherId: string;
  name: string;
  ageGroup: AgeGroup;
  createdAt: number;
}

export interface StoryRecord {
  id: string;
  storyId: string;
  studentId: string;
  studentName: string;
  classId: string;
  schoolId: string;
  title: string;
  coverImage: string;
  createdAt: number;
}

// Helper function for API calls
const apiCall = async (endpoint: string, options: RequestInit = {}) => {
  const url = `${API_BASE_URL}${endpoint}`;
  const response = await fetch(url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...options.headers,
    },
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ error: 'Network error' }));
    throw new Error(error.error || `HTTP error! status: ${response.status}`);
  }

  const data = await response.json();
  return data.data;
};

// ============= SCHOOL CRUD =============
export const getSchools = async (): Promise<School[]> => {
  return apiCall('/schools');
};

export const addSchool = async (school: Omit<School, 'id' | 'createdAt'>): Promise<School> => {
  return apiCall('/schools', {
    method: 'POST',
    body: JSON.stringify(school),
  });
};

export const updateSchool = async (id: string, updates: Partial<School>): Promise<School | null> => {
  return apiCall(`/schools/${id}`, {
    method: 'PATCH',
    body: JSON.stringify(updates),
  });
};

export const deleteSchool = async (id: string): Promise<boolean> => {
  await apiCall(`/schools/${id}`, {
    method: 'DELETE',
  });
  return true;
};

// ============= CLASS CRUD =============
export const getClasses = async (schoolId?: string): Promise<Class[]> => {
  const query = schoolId ? `?schoolId=${schoolId}` : '';
  return apiCall(`/classes${query}`);
};

export const addClass = async (cls: Omit<Class, 'id' | 'createdAt'>): Promise<Class> => {
  return apiCall('/classes', {
    method: 'POST',
    body: JSON.stringify(cls),
  });
};

export const updateClass = async (id: string, updates: Partial<Class>): Promise<Class | null> => {
  return apiCall(`/classes/${id}`, {
    method: 'PATCH',
    body: JSON.stringify(updates),
  });
};

export const deleteClass = async (id: string): Promise<boolean> => {
  await apiCall(`/classes/${id}`, {
    method: 'DELETE',
  });
  return true;
};

// ============= TEACHER CRUD =============
export const getTeachers = async (schoolId?: string): Promise<Teacher[]> => {
  const query = schoolId ? `?schoolId=${schoolId}` : '';
  return apiCall(`/teachers${query}`);
};

export const addTeacher = async (teacher: Omit<Teacher, 'id' | 'createdAt'>): Promise<Teacher> => {
  return apiCall('/teachers', {
    method: 'POST',
    body: JSON.stringify(teacher),
  });
};

export const updateTeacher = async (id: string, updates: Partial<Teacher>): Promise<Teacher | null> => {
  return apiCall(`/teachers/${id}`, {
    method: 'PATCH',
    body: JSON.stringify(updates),
  });
};

export const deleteTeacher = async (id: string): Promise<boolean> => {
  await apiCall(`/teachers/${id}`, {
    method: 'DELETE',
  });
  return true;
};

// ============= STUDENT CRUD =============
export const getStudents = async (filters?: { schoolId?: string; classId?: string; teacherId?: string }): Promise<Student[]> => {
  const params = new URLSearchParams();
  if (filters?.schoolId) params.append('schoolId', filters.schoolId);
  if (filters?.classId) params.append('classId', filters.classId);
  if (filters?.teacherId) params.append('teacherId', filters.teacherId);

  const query = params.toString() ? `?${params.toString()}` : '';
  return apiCall(`/students${query}`);
};

export const addStudent = async (student: Omit<Student, 'id' | 'createdAt'>): Promise<Student> => {
  return apiCall('/students', {
    method: 'POST',
    body: JSON.stringify(student),
  });
};

export const updateStudent = async (id: string, updates: Partial<Student>): Promise<Student | null> => {
  return apiCall(`/students/${id}`, {
    method: 'PATCH',
    body: JSON.stringify(updates),
  });
};

export const deleteStudent = async (id: string): Promise<boolean> => {
  await apiCall(`/students/${id}`, {
    method: 'DELETE',
  });
  return true;
};

// ============= STORY RECORDS =============
export const getStoryRecords = async (filters?: { schoolId?: string; classId?: string; studentId?: string }): Promise<StoryRecord[]> => {
  const params = new URLSearchParams();
  if (filters?.schoolId) params.append('schoolId', filters.schoolId);
  if (filters?.classId) params.append('classId', filters.classId);
  if (filters?.studentId) params.append('studentId', filters.studentId);

  const query = params.toString() ? `?${params.toString()}` : '';
  return apiCall(`/stories${query}`);
};

export const getStory = async (id: string): Promise<Story> => {
  return apiCall(`/stories/${id}`);
};

export const addStoryRecord = async (story: Story, studentInfo: { studentId: string; schoolId: string; classId: string }): Promise<StoryRecord> => {
  // 创建完整的故事
  const fullStory = {
    studentId: studentInfo.studentId,
    schoolId: studentInfo.schoolId,
    classId: studentInfo.classId,
    title: story.title,
    coverImage: story.coverImage,
    authorId: story.authorId,
    authorName: story.authorName,
    ageGroup: story.ageGroup,
    character: story.character,
    place: story.place,
    time: story.time,
    pages: story.pages,
    styling: story.styling
  };

  const result = await apiCall('/stories', {
    method: 'POST',
    body: JSON.stringify(fullStory),
  });

  // 转换为StoryRecord格式
  return {
    id: result.id,
    storyId: result.id,
    studentId: studentInfo.studentId,
    studentName: story.authorName,
    classId: studentInfo.classId,
    schoolId: studentInfo.schoolId,
    title: story.title,
    coverImage: story.coverImage,
    createdAt: result.createdAt
  };
};

export const updateStory = async (id: string, updates: Partial<Story>): Promise<Story> => {
  return apiCall(`/stories/${id}`, {
    method: 'PATCH',
    body: JSON.stringify(updates),
  });
};

export const deleteStory = async (id: string): Promise<boolean> => {
  await apiCall(`/stories/${id}`, {
    method: 'DELETE',
  });
  return true;
};

// ============= STATISTICS =============
export const getSchoolStats = async (schoolId: string) => {
  const stats = await apiCall(`/schools/${schoolId}/stats`);
  return {
    teacherCount: stats.teacher_count || 0,
    studentCount: stats.student_count || 0,
    storyCount: stats.story_count || 0,
  };
};

export const getClassStats = async (classId: string) => {
  // 通过获取学生和故事来计算统计
  const students = await getStudents({ classId });
  const stories = await getStoryRecords({ classId });
  return {
    studentCount: students.length,
    storyCount: stories.length,
  };
};

// ============= CSV IMPORT =============
export const importStudentsFromCSV = async (csvContent: string, schoolId: string, classId: string, teacherId: string): Promise<Student[]> => {
  return apiCall('/students/import-csv', {
    method: 'POST',
    body: JSON.stringify({ csvContent, schoolId, classId, teacherId }),
  });
};

export const importTeachersFromCSV = async (csvContent: string, schoolId: string): Promise<Teacher[]> => {
  return apiCall('/teachers/import-csv', {
    method: 'POST',
    body: JSON.stringify({ csvContent, schoolId }),
  });
};

// ============= QR CODE DATA =============
export const generateQRData = async (type: 'school' | 'teacher' | 'student', id: string): Promise<string> => {
  const result = await apiCall(`/qr/generate?type=${type}&id=${id}`);
  return result.qrContent;
};

export const parseQRData = async (qrContent: string): Promise<{ type: string; id: string; entity: any } | null> => {
  try {
    const result = await apiCall('/qr/parse', {
      method: 'POST',
      body: JSON.stringify({ qrContent }),
    });
    return {
      type: result.type,
      id: result.entity.id,
      entity: result.entity
    };
  } catch (error) {
    console.error('Failed to parse QR code:', error);
    return null;
  }
};
