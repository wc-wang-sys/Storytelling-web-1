import { AgeGroup, Story, StoryPage, WizardStep } from '../types';
import { fetchPublicPromptTemplates, RuntimePromptMap } from './backendService';

const DEFAULT_PROMPT_TEMPLATES: RuntimePromptMap = {
  image_generation_default_style: '儿童绘本风格，明亮温暖，可爱治愈，柔和色彩，Q版卡通',
  image_generation_suffix:
    '{{prompt}}，{{style}}。儿童绘本风格，明亮温暖，可爱治愈，柔和色彩，Q版卡通，无恐怖、无黑暗、无暴力、无危险画面，积极阳光，适合小朋友阅读，高清，干净，温馨。',
  text_generation_task:
    `你是专为3-6岁儿童设计的故事创作助手，只输出温暖、阳光、安全的故事。
必须严格遵守以下规则：
1. 绝对不出现暴力、血腥、死亡、恐怖、惊悚、吵架、威胁等内容。
2. 价值观必须正向：友善、勇敢、诚实、分享、合作、爱护家人、热爱自然、乐于助人。
3. 语言简单易懂、可爱、充满想象力。
4. 结局一定是快乐、温暖、积极向上的。
5. 如果用户输入恐怖、暴力、负面内容，自动引导为正向故事，不采纳危险内容。
任务：{{task}}`,
  input_moderation_prompt:
    `你是儿童内容安全审核助手，负责判断学生输入的文本是否适合 3-6 岁儿童故事创作。
请重点识别并拦截这些内容：暴力、血腥、死亡、自残、恐怖、惊悚、鬼怪、武器、爆炸、威胁、绑架、霸凌、仇恨、成人化内容，以及其他明显不适合儿童的危险内容。
如果文本只是普通冒险、友善幻想、轻微紧张但整体安全、温暖、没有伤害和恐吓，可以判定为 safe。
输入文本可能是中文或英文。

只返回 JSON，不要输出任何额外说明，格式如下：
{
  "safe": true,
  "categories": [],
  "reason": "safe"
}

如果不安全，则返回：
{
  "safe": false,
  "categories": ["violence", "horror"],
  "reason": "brief reason"
}

categories 只能从以下枚举中选择：violence, terror, horror, weapon, bullying, self_harm, hate, adult, dangerous

待审核文本：
{{input}}`,
  suggestions_generation:
    `你是为3-6岁儿童提供灵感的小帮手。
请为{{ageGroup}}岁儿童提供 3 个关于{{context}}的温暖、明亮、安全、充满想象力的选项。
不要出现恐怖、黑暗、暴力、危险或不友好的内容。
仅返回 JSON 字符串数组，例如 ["一只爱帮助人的小兔子", "会唱歌的小机器人", "喜欢跳舞的小猫咪"]。`,
  story_segment_generation:
    `你是专为3-6岁儿童设计的故事创作助手，只输出温暖、阳光、安全的故事。
必须严格遵守以下规则：
1. 绝对不出现暴力、血腥、死亡、恐怖、惊悚、吵架、威胁等内容。
2. 价值观必须正向：友善、勇敢、诚实、分享、合作、爱护家人、热爱自然、乐于助人。
3. 语言简单易懂、可爱、充满想象力。
4. 结局一定是快乐、温暖、积极向上的。
5. 如果用户输入恐怖、暴力、负面内容，自动引导为正向故事，不采纳危险内容。

请为{{ageGroup}}岁儿童创作故事的一页，正文 2-3 句。
角色：{{character}}
地点：{{place}}
时间：{{time}}
剧情方向：{{plot}}

只返回 JSON：{ "storyText": "...", "imageDescription": "..." }
其中 imageDescription 必须是适合儿童绘本插图的明亮温暖画面描述。`,
  story_outline_generation:
    `你是专为3-6岁儿童设计的故事创作助手，只输出温暖、阳光、安全的故事。
必须严格遵守以下规则：
1. 绝对不出现暴力、血腥、死亡、恐怖、惊悚、吵架、威胁等内容。
2. 价值观必须正向：友善、勇敢、诚实、分享、合作、爱护家人、热爱自然、乐于助人。
3. 语言简单易懂、可爱、充满想象力。
4. 结局一定是快乐、温暖、积极向上的。
5. 如果用户输入恐怖、暴力、负面内容，自动引导为正向故事，不采纳危险内容。

请生成一个 {{pageCount}} 页的儿童故事大纲。
角色：{{character}}
地点：{{place}}
时间：{{time}}
剧情方向：{{plot}}
年龄段：{{ageGroup}}岁

仅返回包含 {{pageCount}} 个字符串的 JSON 数组，每个字符串代表一页的简短大纲。
每页描述保持简洁、温暖、安全，适合继续扩写成儿童绘本故事。`,
  speech_generation_prompt: '{{text}}',
  cover_regeneration_prompt:
    "Children's book cover for a story about {{characterDescription}} in {{placeDescription}}. Title: {{title}}. Colorful, inviting.",
  page_image_regeneration_prompt: 'Illustration for: {{pageText}}',
  page_text_regeneration_prompt: 'Rewrite this slightly for a {{ageGroup}} year old: "{{pageText}}"',
  wizard_character_image_prompt: 'A cute {{choice}} character',
  wizard_place_image_prompt: 'A cartoon background of {{choice}}',
  wizard_time_image_prompt: "A cartoon scene of {{choice}}, children's book style",
  text_generation_no_ai_fallback: 'Once upon a time, in a magical land far away...',
  text_generation_error_fallback: 'Something magical happened...',
  suggestions_fallback_character: '["A brave bunny", "A silly robot", "A dancing cat"]',
  suggestions_fallback_place: '["A magical forest", "A cozy treehouse", "An underwater castle"]',
  suggestions_fallback_time: '["A sunny morning", "A starry night", "A rainy afternoon"]',
  suggestions_empty_fallback: '["Option 1", "Option 2", "Option 3"]',
  suggestions_error_fallback: '["A funny cat", "A big bear", "A flying fish"]',
  story_segment_no_ai_fallback_text: '{{character}} was in {{place}} during {{time}}. {{plot}}',
  story_segment_no_ai_fallback_image_prompt: '{{character}} in {{place}}',
  story_segment_error_fallback_text: '{{plot}}',
  story_segment_error_fallback_image_prompt: '{{plot}}',
  story_outline_fallback_intro: 'Introduction: Meet {{character}}',
  story_outline_fallback_middle: 'Page {{pageNumber}}: The adventure continues',
  story_outline_fallback_ending: 'Ending: {{character}} lives happily',
  story_outline_missing_page_fallback: 'Page {{pageNumber}} of the story',
};

const PROMPT_CACHE_TTL_MS = 30 * 1000;
let promptCache: RuntimePromptMap | null = null;
let promptCachePromise: Promise<RuntimePromptMap> | null = null;
let promptCacheLoadedAt = 0;

const normalizeValue = (value: unknown) => {
  if (value === null || value === undefined) {
    return '';
  }
  return String(value);
};

export const interpolatePromptTemplate = (template: string, variables: Record<string, unknown>) => {
  return template.replace(/\{\{\s*([a-zA-Z0-9_]+)\s*\}\}/g, (_match, key) => {
    return normalizeValue(variables[key]);
  });
};

export const loadPromptTemplates = async (): Promise<RuntimePromptMap> => {
  if (promptCache && Date.now() - promptCacheLoadedAt < PROMPT_CACHE_TTL_MS) {
    return promptCache;
  }

  if (!promptCachePromise) {
    promptCachePromise = fetchPublicPromptTemplates()
      .then((remoteTemplates) => {
        promptCache = {
          ...DEFAULT_PROMPT_TEMPLATES,
          ...(remoteTemplates || {}),
        };
        promptCacheLoadedAt = Date.now();
        return promptCache;
      })
      .catch(() => {
        promptCache = { ...DEFAULT_PROMPT_TEMPLATES };
        promptCacheLoadedAt = Date.now();
        return promptCache;
      })
      .finally(() => {
        promptCachePromise = null;
      });
  }

  return promptCachePromise;
};

export const getPromptTemplateValue = async (key: string) => {
  const templates = await loadPromptTemplates();
  return templates[key] || DEFAULT_PROMPT_TEMPLATES[key] || '';
};

export const renderPromptTemplate = async (key: string, variables: Record<string, unknown>) => {
  const template = await getPromptTemplateValue(key);
  return interpolatePromptTemplate(template, variables);
};

export const parseJsonPromptTemplate = async <T>(key: string, fallback: T): Promise<T> => {
  const rawValue = await getPromptTemplateValue(key);

  try {
    return JSON.parse(rawValue) as T;
  } catch {
    try {
      return JSON.parse(DEFAULT_PROMPT_TEMPLATES[key]) as T;
    } catch {
      return fallback;
    }
  }
};

export const buildCoverRegenerationPrompt = async (story: Story) => {
  return renderPromptTemplate('cover_regeneration_prompt', {
    characterDescription: story.character.description,
    placeDescription: story.place.description,
    title: story.title,
  });
};

export const buildPageImagePrompt = async (page: StoryPage) => {
  if (page.imagePrompt) {
    return page.imagePrompt;
  }

  return renderPromptTemplate('page_image_regeneration_prompt', {
    pageText: page.text,
  });
};

export const buildPageRewriteTask = async (ageGroup: AgeGroup, pageText: string) => {
  return renderPromptTemplate('page_text_regeneration_prompt', {
    ageGroup,
    pageText,
  });
};

export const buildWizardChoiceImagePrompt = async (step: WizardStep, choice: string) => {
  const key =
    step === WizardStep.PLACE
      ? 'wizard_place_image_prompt'
      : step === WizardStep.TIME
        ? 'wizard_time_image_prompt'
        : 'wizard_character_image_prompt';

  return renderPromptTemplate(key, { choice });
};
