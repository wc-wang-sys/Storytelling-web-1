// Speech Recognition Service
// - Speech input: iFlytek real-time ASR over WebSocket
// - Voice commands: Web Speech API

import { fetchIflytekSpeechAuth } from './backendService';

export type SpeechLanguage = 'zh-HK' | 'zh-CN' | 'en-US';

export interface SpeechRecognitionResult {
  transcript: string;
  confidence: number;
  isFinal: boolean;
}

export type SpeechStatus = 'idle' | 'listening' | 'processing' | 'error';

interface IflytekBusinessConfig {
  language: string;
  domain: string;
  accent: string;
  dwa?: string;
  ptt?: number;
}

interface IflytekResultWord {
  w?: string;
}

interface IflytekResultSegment {
  cw?: IflytekResultWord[];
}

interface IflytekResultPayload {
  sn?: number;
  pgs?: 'apd' | 'rpl';
  rg?: [number, number];
  ws?: IflytekResultSegment[];
}

interface IflytekMessagePayload {
  code?: number;
  message?: string;
  data?: {
    status?: number;
    result?: IflytekResultPayload;
  };
}

const IFLYTEK_ASR_CHUNK_BYTES = 1280;
const IFLYTEK_ASR_TARGET_SAMPLE_RATE = 16000;
const IFLYTEK_ASR_FRAME_INTERVAL_MS = 40;
const IFLYTEK_ASR_VAD_EOS = Number(import.meta.env.VITE_IFLYTEK_IAT_VAD_EOS || 1500);

const iflytekBusinessConfig: Record<SpeechLanguage, IflytekBusinessConfig> = {
  'zh-CN': {
    language: import.meta.env.VITE_IFLYTEK_IAT_LANGUAGE_ZH_CN?.trim() || 'zh_cn',
    domain: import.meta.env.VITE_IFLYTEK_IAT_DOMAIN_ZH_CN?.trim() || 'iat',
    accent: import.meta.env.VITE_IFLYTEK_IAT_ACCENT_ZH_CN?.trim() || 'mandarin',
    dwa: 'wpgs',
    ptt: 1,
  },
  'zh-HK': {
    language: import.meta.env.VITE_IFLYTEK_IAT_LANGUAGE_ZH_HK?.trim() || 'zh_cn',
    domain: import.meta.env.VITE_IFLYTEK_IAT_DOMAIN_ZH_HK?.trim() || 'iat',
    accent: import.meta.env.VITE_IFLYTEK_IAT_ACCENT_ZH_HK?.trim() || 'cantonese',
    ptt: 1,
  },
  'en-US': {
    language: import.meta.env.VITE_IFLYTEK_IAT_LANGUAGE_EN?.trim() || 'en_us',
    domain: import.meta.env.VITE_IFLYTEK_IAT_DOMAIN_EN?.trim() || 'iat',
    accent: import.meta.env.VITE_IFLYTEK_IAT_ACCENT_EN?.trim() || 'mandarin',
  },
};

const getIflytekAsrSupportIssues = (): string[] => {
  const issues: string[] = [];

  if (!window.isSecureContext) {
    issues.push('current page is not running in a secure context (HTTPS or localhost)');
  }

  if (!navigator.mediaDevices?.getUserMedia) {
    issues.push('microphone capture API is unavailable');
  }

  if (!window.WebSocket) {
    issues.push('WebSocket is unavailable');
  }

  if (!window.AudioContext && !(window as any).webkitAudioContext) {
    issues.push('Web Audio API is unavailable');
  }

  return issues;
};

const getIflytekAsrSupportMessage = (): string => {
  const issues = getIflytekAsrSupportIssues();

  if (issues.length === 0) {
    return 'iFlytek speech input is not supported in this browser.';
  }

  return `iFlytek speech input requires HTTPS or localhost plus microphone, WebSocket, and Web Audio support. Missing: ${issues.join(', ')}.`;
};

// Map app language to speech recognition language
export const mapLanguageToSpeech = (lang: string): SpeechLanguage => {
  switch (lang) {
    case 'zh-HK':
      return 'zh-HK';
    case 'zh-CN':
      return 'zh-CN';
    default:
      return 'en-US';
  }
};

// Check if browser supports speech recognition
export const isSpeechRecognitionSupported = (): boolean => {
  return getIflytekAsrSupportIssues().length === 0;
};

// Create speech recognition instance
const createSpeechRecognition = () => {
  const SpeechRecognition =
    window.SpeechRecognition || (window as any).webkitSpeechRecognition;

  if (!SpeechRecognition) {
    return null;
  }

  const recognition = new SpeechRecognition();
  recognition.continuous = false;
  recognition.interimResults = true;
  recognition.maxAlternatives = 1;

  return recognition;
};

const concatUint8Arrays = (left: Uint8Array, right: Uint8Array): Uint8Array => {
  const merged = new Uint8Array(left.length + right.length);
  merged.set(left);
  merged.set(right, left.length);
  return merged;
};

const arrayBufferToBase64 = (buffer: ArrayBuffer): string => {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  for (const byte of bytes) {
    binary += String.fromCharCode(byte);
  }
  return btoa(binary);
};

const uint8ArrayToBase64 = (buffer: Uint8Array): string => {
  return arrayBufferToBase64(buffer.buffer.slice(buffer.byteOffset, buffer.byteOffset + buffer.byteLength));
};

const downsampleBuffer = (input: Float32Array, inputRate: number, targetRate: number): Float32Array => {
  if (inputRate === targetRate || targetRate > inputRate) {
    return input;
  }

  const ratio = inputRate / targetRate;
  const outputLength = Math.round(input.length / ratio);
  const output = new Float32Array(outputLength);
  let inputOffset = 0;

  for (let i = 0; i < outputLength; i += 1) {
    const nextInputOffset = Math.round((i + 1) * ratio);
    let total = 0;
    let count = 0;

    for (let j = inputOffset; j < nextInputOffset && j < input.length; j += 1) {
      total += input[j];
      count += 1;
    }

    output[i] = count > 0 ? total / count : 0;
    inputOffset = nextInputOffset;
  }

  return output;
};

const floatTo16BitPcm = (input: Float32Array): Uint8Array => {
  const buffer = new ArrayBuffer(input.length * 2);
  const view = new DataView(buffer);

  for (let i = 0; i < input.length; i += 1) {
    const sample = Math.max(-1, Math.min(1, input[i]));
    view.setInt16(i * 2, sample < 0 ? sample * 0x8000 : sample * 0x7fff, true);
  }

  return new Uint8Array(buffer);
};

const buildCombinedTranscript = (segments: Map<number, string>): string => {
  return [...segments.entries()]
    .sort(([left], [right]) => left - right)
    .map(([, text]) => text)
    .join('');
};

const extractIflytekTranscript = (result: IflytekResultPayload | undefined): string => {
  if (!result?.ws?.length) {
    return '';
  }

  return result.ws
    .map((segment) => segment.cw?.[0]?.w || '')
    .join('');
};

const buildIflytekBusinessPayload = (language: SpeechLanguage) => {
  const config = iflytekBusinessConfig[language];
  const business: Record<string, string | number> = {
    language: config.language,
    domain: config.domain,
    accent: config.accent,
    vad_eos: IFLYTEK_ASR_VAD_EOS,
  };

  if (typeof config.ptt === 'number') {
    business.ptt = config.ptt;
  }

  if (config.dwa && config.language === 'zh_cn' && config.accent === 'mandarin') {
    business.dwa = config.dwa;
  }

  return business;
};

// Speech recognition class for managing state
export class SpeechRecognizer {
  private language: SpeechLanguage = 'zh-HK';
  private onResultCallback: ((result: SpeechRecognitionResult) => void) | null = null;
  private onStatusChangeCallback: ((status: SpeechStatus) => void) | null = null;
  private onErrorCallback: ((error: string) => void) | null = null;
  private isListening = false;

  private ws: WebSocket | null = null;
  private mediaStream: MediaStream | null = null;
  private audioContext: AudioContext | null = null;
  private sourceNode: MediaStreamAudioSourceNode | null = null;
  private processorNode: ScriptProcessorNode | null = null;
  private monitorGainNode: GainNode | null = null;
  private outgoingBuffer = new Uint8Array(0);
  private queuedChunks: Uint8Array[] = [];
  private isSocketReady = false;
  private isStopping = false;
  private hasSentFirstFrame = false;
  private endFrameRequested = false;
  private sessionToken = 0;
  private sendTimerId: number | null = null;
  private appId = '';
  private transcriptSegments = new Map<number, string>();

  setLanguage(lang: SpeechLanguage) {
    this.language = lang;
  }

  onResult(callback: (result: SpeechRecognitionResult) => void) {
    this.onResultCallback = callback;
  }

  onStatusChange(callback: (status: SpeechStatus) => void) {
    this.onStatusChangeCallback = callback;
  }

  onError(callback: (error: string) => void) {
    this.onErrorCallback = callback;
  }

  start() {
    if (!isSpeechRecognitionSupported()) {
      this.onErrorCallback?.(getIflytekAsrSupportMessage());
      return false;
    }

    if (this.isListening) {
      return true;
    }

    this.sessionToken += 1;
    this.isStopping = false;
    void this.startIflytekSession(this.sessionToken);
    return true;
  }

  stop() {
    this.stopIflytekSession();
  }

  isSupported(): boolean {
    return isSpeechRecognitionSupported();
  }

  getIsListening(): boolean {
    return this.isListening;
  }

  private async startIflytekSession(token: number) {
    try {
      const auth = await fetchIflytekSpeechAuth();
      if (token !== this.sessionToken) {
        return;
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          channelCount: 1,
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });

      if (token !== this.sessionToken) {
        stream.getTracks().forEach((track) => track.stop());
        return;
      }

      this.resetIflytekBuffers();
      this.appId = auth.appId;
      this.mediaStream = stream;

      const AudioContextCtor = window.AudioContext || (window as any).webkitAudioContext;
      this.audioContext = new AudioContextCtor();
      this.sourceNode = this.audioContext.createMediaStreamSource(stream);
      this.processorNode = this.audioContext.createScriptProcessor(4096, 1, 1);
      this.monitorGainNode = this.audioContext.createGain();
      this.monitorGainNode.gain.value = 0;

      this.processorNode.onaudioprocess = (event) => {
        const inputData = event.inputBuffer.getChannelData(0);
        const downsampled = downsampleBuffer(
          inputData,
          this.audioContext?.sampleRate || IFLYTEK_ASR_TARGET_SAMPLE_RATE,
          IFLYTEK_ASR_TARGET_SAMPLE_RATE,
        );

        const pcmChunk = floatTo16BitPcm(downsampled);
        this.bufferIflytekAudioChunk(pcmChunk);
      };

      this.sourceNode.connect(this.processorNode);
      this.processorNode.connect(this.monitorGainNode);
      this.monitorGainNode.connect(this.audioContext.destination);

      this.ws = new WebSocket(auth.url);

      this.ws.onopen = () => {
        this.isSocketReady = true;
        this.isListening = true;
        this.onStatusChangeCallback?.('listening');
        this.startIflytekSendLoop();
      };

      this.ws.onmessage = (event) => {
        this.handleIflytekMessage(event.data);
      };

      this.ws.onerror = () => {
        this.handleIflytekError('iFlytek speech input connection failed.');
      };

      this.ws.onclose = () => {
        const wasStopping = this.isStopping;
        const wasListening = this.isListening;

        this.cleanupIflytekResources();

        if (!wasStopping && wasListening) {
          this.handleIflytekError('iFlytek speech input connection closed unexpectedly.');
          return;
        }

        this.isListening = false;
        this.onStatusChangeCallback?.('idle');
      };
    } catch (error) {
      console.error('Failed to start iFlytek speech input:', error);
      this.cleanupIflytekResources();

      if (error instanceof DOMException && error.name === 'NotAllowedError') {
        this.handleIflytekError('Microphone access denied. Please allow microphone permission.');
        return;
      }

      const message = error instanceof Error ? error.message : 'Failed to start iFlytek speech input.';
      this.handleIflytekError(message);
    }
  }

  private stopIflytekSession() {
    if (!this.ws && !this.mediaStream && !this.audioContext) {
      return;
    }

    this.isStopping = true;
    this.isListening = false;
    this.onStatusChangeCallback?.('processing');

    if (this.processorNode) {
      this.processorNode.onaudioprocess = null;
    }

    if (this.sourceNode && this.processorNode) {
      this.sourceNode.disconnect(this.processorNode);
    }

    if (this.processorNode && this.monitorGainNode) {
      this.processorNode.disconnect(this.monitorGainNode);
    }

    if (this.monitorGainNode) {
      this.monitorGainNode.disconnect();
    }

    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach((track) => track.stop());
      this.mediaStream = null;
    }

    if (this.outgoingBuffer.length > 0) {
      this.queuedChunks.push(this.outgoingBuffer);
      this.outgoingBuffer = new Uint8Array(0);
    }

    this.endFrameRequested = true;

    if (this.ws?.readyState !== WebSocket.OPEN) {
      this.cleanupIflytekResources();
      this.onStatusChangeCallback?.('idle');
    }

    if (this.audioContext) {
      void this.audioContext.close();
      this.audioContext = null;
    }
  }

  private resetIflytekBuffers() {
    this.outgoingBuffer = new Uint8Array(0);
    this.queuedChunks = [];
    this.isSocketReady = false;
    this.hasSentFirstFrame = false;
    this.endFrameRequested = false;
    this.transcriptSegments = new Map();
  }

  private cleanupIflytekResources() {
    if (this.sendTimerId !== null) {
      window.clearInterval(this.sendTimerId);
      this.sendTimerId = null;
    }

    if (this.ws) {
      this.ws.onopen = null;
      this.ws.onclose = null;
      this.ws.onerror = null;
      this.ws.onmessage = null;
      if (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING) {
        this.ws.close();
      }
      this.ws = null;
    }

    if (this.processorNode) {
      this.processorNode.onaudioprocess = null;
      this.processorNode.disconnect();
      this.processorNode = null;
    }

    if (this.monitorGainNode) {
      this.monitorGainNode.disconnect();
      this.monitorGainNode = null;
    }

    if (this.sourceNode) {
      this.sourceNode.disconnect();
      this.sourceNode = null;
    }

    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach((track) => track.stop());
      this.mediaStream = null;
    }

    if (this.audioContext) {
      void this.audioContext.close();
      this.audioContext = null;
    }

    this.resetIflytekBuffers();
    this.appId = '';
    this.isStopping = false;
  }

  private bufferIflytekAudioChunk(chunk: Uint8Array) {
    if (!chunk.length) {
      return;
    }

    this.outgoingBuffer = concatUint8Arrays(this.outgoingBuffer, chunk);
    while (this.outgoingBuffer.length >= IFLYTEK_ASR_CHUNK_BYTES) {
      const nextChunk = this.outgoingBuffer.slice(0, IFLYTEK_ASR_CHUNK_BYTES);
      this.outgoingBuffer = this.outgoingBuffer.slice(IFLYTEK_ASR_CHUNK_BYTES);
      this.queuedChunks.push(nextChunk);
    }
  }

  private startIflytekSendLoop() {
    if (this.sendTimerId !== null) {
      return;
    }

    this.sendTimerId = window.setInterval(() => {
      this.flushIflytekFrame();
    }, IFLYTEK_ASR_FRAME_INTERVAL_MS);
  }

  private flushIflytekFrame() {
    if (!this.isSocketReady || this.ws?.readyState !== WebSocket.OPEN) {
      return;
    }

    const nextChunk = this.queuedChunks.shift();
    if (nextChunk) {
      this.sendIflytekFrame(nextChunk, this.hasSentFirstFrame ? 1 : 0);
      this.hasSentFirstFrame = true;
      return;
    }

    if (!this.endFrameRequested) {
      return;
    }

    if (!this.hasSentFirstFrame) {
      this.sendIflytekFrame(new Uint8Array(0), 0);
      this.hasSentFirstFrame = true;
      return;
    }

    this.sendIflytekFrame(new Uint8Array(0), 2);
    this.endFrameRequested = false;
  }

  private sendIflytekFrame(chunk: Uint8Array, status: 0 | 1 | 2) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
      return;
    }

    const payload: Record<string, unknown> = {
      data: {
        status,
        format: 'audio/L16;rate=16000',
        encoding: 'raw',
        audio: uint8ArrayToBase64(chunk),
      },
    };

    if (status === 0) {
      payload.common = {
        app_id: this.appId,
      };
      payload.business = buildIflytekBusinessPayload(this.language);
    }

    this.ws.send(JSON.stringify(payload));
  }

  private handleIflytekMessage(rawData: string | ArrayBuffer) {
    if (typeof rawData !== 'string') {
      return;
    }

    let data: IflytekMessagePayload;
    try {
      data = JSON.parse(rawData) as IflytekMessagePayload;
    } catch (error) {
      console.error('Failed to parse iFlytek speech input message:', error);
      return;
    }

    if ((data.code || 0) !== 0) {
      this.handleIflytekError(data.message || 'iFlytek speech input failed.');
      return;
    }

    const result = data.data?.result;
    const sn = Number(result?.sn || 0);
    const transcript = extractIflytekTranscript(result);

    if (result?.pgs === 'rpl' && Array.isArray(result.rg) && result.rg.length === 2) {
      const [start, end] = result.rg;
      for (let index = start; index <= end; index += 1) {
        this.transcriptSegments.delete(index);
      }
    }

    if (transcript) {
      this.transcriptSegments.set(sn, transcript);
    }

    const combinedTranscript = buildCombinedTranscript(this.transcriptSegments);
    if (combinedTranscript) {
      this.onResultCallback?.({
        transcript: combinedTranscript,
        confidence: 1,
        isFinal: data.data?.status === 2,
      });
    }

    if (data.data?.status === 2) {
      this.isListening = false;
      this.onStatusChangeCallback?.('idle');
      this.cleanupIflytekResources();
    }
  }

  private handleIflytekError(message: string) {
    this.isListening = false;
    this.onStatusChangeCallback?.('error');
    this.cleanupIflytekResources();
    this.onErrorCallback?.(message);
  }
}

// Singleton instance for voice commands (continuous listening)
export class VoiceCommandListener {
  private recognition: any | null = null;
  private isActive = false;
  private onCommandCallback: ((command: string) => void) | null = null;
  private language: SpeechLanguage = 'zh-HK';

  // Command keywords for different languages
  private commands = {
    next: ['next', 'next page', '下一頁', '下一页', '下一個', '下一个'],
    prev: ['previous', 'previous page', 'back', '上一頁', '上一页', '上一個', '上一个', '返回'],
    exit: ['exit', 'close', 'quit', '退出', '關閉', '关闭', '結束', '结束'],
  };

  constructor() {
    this.recognition = createSpeechRecognition();
    if (this.recognition) {
      this.recognition.continuous = true;
      this.recognition.interimResults = false;
      this.setupEventListeners();
    }
  }

  private setupEventListeners() {
    if (!this.recognition) return;

    this.recognition.onresult = (event: any) => {
      const result = event.results[event.results.length - 1];
      if (result.isFinal) {
        const transcript = result[0].transcript.toLowerCase().trim();
        this.processCommand(transcript);
      }
    };

    this.recognition.onend = () => {
      if (this.isActive) {
        setTimeout(() => {
          try {
            this.recognition?.start();
          } catch (_error) {
            // Ignore restart errors.
          }
        }, 100);
      }
    };

    this.recognition.onerror = (event: any) => {
      if (event.error !== 'no-speech' && event.error !== 'aborted') {
        console.error('Voice command error:', event.error);
      }
    };
  }

  private processCommand(transcript: string) {
    if (this.commands.next.some((cmd) => transcript.includes(cmd))) {
      this.onCommandCallback?.('next');
      return;
    }

    if (this.commands.prev.some((cmd) => transcript.includes(cmd))) {
      this.onCommandCallback?.('prev');
      return;
    }

    if (this.commands.exit.some((cmd) => transcript.includes(cmd))) {
      this.onCommandCallback?.('exit');
    }
  }

  setLanguage(lang: SpeechLanguage) {
    this.language = lang;
    if (this.recognition) {
      this.recognition.lang = lang;
    }
  }

  onCommand(callback: (command: string) => void) {
    this.onCommandCallback = callback;
  }

  start() {
    if (!this.recognition) return false;

    if (this.isActive) return true;

    try {
      this.recognition.lang = this.language;
      this.recognition.start();
      this.isActive = true;
      return true;
    } catch (e) {
      console.error('Failed to start voice commands:', e);
      return false;
    }
  }

  stop() {
    this.isActive = false;
    if (this.recognition) {
      try {
        this.recognition.stop();
      } catch (_error) {
        // Ignore stop errors.
      }
    }
  }

  isSupported(): boolean {
    return this.recognition !== null;
  }

  getIsActive(): boolean {
    return this.isActive;
  }
}

// Create singleton instances
let speechRecognizerInstance: SpeechRecognizer | null = null;
let voiceCommandInstance: VoiceCommandListener | null = null;

export const getSpeechRecognizer = (): SpeechRecognizer => {
  if (!speechRecognizerInstance) {
    speechRecognizerInstance = new SpeechRecognizer();
  }
  return speechRecognizerInstance;
};

export const getVoiceCommandListener = (): VoiceCommandListener => {
  if (!voiceCommandInstance) {
    voiceCommandInstance = new VoiceCommandListener();
  }
  return voiceCommandInstance;
};
