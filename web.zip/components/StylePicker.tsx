import React, { useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { Type, Palette, ChevronDown, ChevronUp } from 'lucide-react';

export interface StyleOptions {
  fontFamily: string;
  fontSize: 'small' | 'medium' | 'large';
  textColor: string;
}

interface StylePickerProps {
  value: StyleOptions;
  onChange: (options: StyleOptions) => void;
  compact?: boolean;
}

const SIZE_OPTIONS = [
  { value: 'small' as const, label: 'S', scale: 'text-lg' },
  { value: 'medium' as const, label: 'M', scale: 'text-2xl' },
  { value: 'large' as const, label: 'L', scale: 'text-4xl' },
];

// Font and color options with translation keys
const FONT_OPTIONS_KEYS = [
  { value: 'font-comic', labelKey: 'comicSans', preview: 'Aa' },
  { value: 'font-sans', labelKey: 'sansSerif', preview: 'Aa' },
  { value: 'font-serif', labelKey: 'serif', preview: 'Aa' },
];

const COLOR_OPTIONS_KEYS = [
  { value: '#7209B7', labelKey: 'purple' },   // kid-purple
  { value: '#4CC9F0', labelKey: 'blue' },     // kid-blue
  { value: '#F72585', labelKey: 'pink' },     // kid-pink
  { value: '#43AA8B', labelKey: 'green' },    // kid-green
  { value: '#F9C74F', labelKey: 'yellow' },   // kid-yellow
  { value: '#374151', labelKey: 'dark' },     // gray-700
];

export const StylePicker: React.FC<StylePickerProps> = ({ value, onChange, compact = false }) => {
  const { t } = useLanguage();
  const [isExpanded, setIsExpanded] = useState(!compact);

  const updateOption = <K extends keyof StyleOptions>(key: K, val: StyleOptions[K]) => {
    onChange({ ...value, [key]: val });
  };

  if (compact && !isExpanded) {
    return (
      <button
        onClick={() => setIsExpanded(true)}
        className="flex items-center gap-2 px-4 py-2 bg-white rounded-xl border-2 border-gray-200 hover:border-kid-blue transition-colors"
      >
        <Type size={20} className="text-gray-500" />
        <span className="font-bold text-gray-600">{t.editor.fontFamily}</span>
        <ChevronDown size={16} className="text-gray-400" />
      </button>
    );
  }

  return (
    <div className="bg-white rounded-2xl border-4 border-gray-100 p-4 space-y-4 shadow-sm">
      {compact && (
        <button
          onClick={() => setIsExpanded(false)}
          className="flex items-center gap-2 text-gray-500 hover:text-gray-700 mb-2"
        >
          <ChevronUp size={16} />
          <span className="text-sm font-bold">{t.close}</span>
        </button>
      )}

      {/* Font Family */}
      <div>
        <label className="text-sm font-bold text-gray-500 mb-2 block">{t.editor.fontFamily}</label>
        <div className="flex gap-2">
          {FONT_OPTIONS_KEYS.map((font) => (
            <button
              key={font.value}
              onClick={() => updateOption('fontFamily', font.value)}
              className={`flex-1 py-3 px-2 rounded-xl border-2 transition-all ${
                value.fontFamily === font.value
                  ? 'border-kid-blue bg-kid-blue/10'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <span className={`${font.value} text-xl block`}>{font.preview}</span>
              <span className="text-xs text-gray-500 mt-1 block">{t.stylePicker[font.labelKey as keyof typeof t.stylePicker]}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Font Size */}
      <div>
        <label className="text-sm font-bold text-gray-500 mb-2 block">{t.editor.titleSize}</label>
        <div className="flex gap-2">
          {SIZE_OPTIONS.map((size) => (
            <button
              key={size.value}
              onClick={() => updateOption('fontSize', size.value)}
              className={`flex-1 py-3 rounded-xl border-2 transition-all ${
                value.fontSize === size.value
                  ? 'border-kid-blue bg-kid-blue/10'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <span className={`${size.scale} font-bold text-gray-700`}>{size.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Text Color */}
      <div>
        <label className="text-sm font-bold text-gray-500 mb-2 block">{t.editor.titleColor}</label>
        <div className="flex gap-2 flex-wrap">
          {COLOR_OPTIONS_KEYS.map((color) => (
            <button
              key={color.value}
              onClick={() => updateOption('textColor', color.value)}
              className={`w-10 h-10 rounded-full border-4 transition-all ${
                value.textColor === color.value
                  ? 'border-gray-800 scale-110'
                  : 'border-white shadow-md hover:scale-105'
              }`}
              style={{ backgroundColor: color.value }}
              title={t.stylePicker[color.labelKey as keyof typeof t.stylePicker]}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

// Helper to get font size class
export const getFontSizeClass = (size: StyleOptions['fontSize']): string => {
  switch (size) {
    case 'small':
      return 'text-xl md:text-2xl';
    case 'medium':
      return 'text-2xl md:text-3xl';
    case 'large':
      return 'text-3xl md:text-4xl lg:text-5xl';
    default:
      return 'text-2xl md:text-3xl';
  }
};
