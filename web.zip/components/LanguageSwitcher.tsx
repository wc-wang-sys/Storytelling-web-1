import React from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { Language, languageNames } from '../services/i18n';
import { Globe } from 'lucide-react';

interface LanguageSwitcherProps {
  compact?: boolean;
}

export const LanguageSwitcher: React.FC<LanguageSwitcherProps> = ({ compact = false }) => {
  const { language, setLanguage } = useLanguage();

  const languages: Language[] = ['zh-HK', 'zh-CN', 'en'];

  if (compact) {
    return (
      <div className="relative inline-block">
        <select
          value={language}
          onChange={(e) => setLanguage(e.target.value as Language)}
          className="appearance-none bg-white border-2 border-gray-200 rounded-xl px-3 py-2 pr-8 font-bold text-gray-700 cursor-pointer hover:border-kid-blue transition-colors focus:outline-none focus:border-kid-blue"
        >
          {languages.map((lang) => (
            <option key={lang} value={lang}>
              {languageNames[lang]}
            </option>
          ))}
        </select>
        <Globe className="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-400 pointer-events-none" size={16} />
      </div>
    );
  }

  return (
    <div className="flex items-center gap-2 bg-gray-100 p-1 rounded-2xl">
      {languages.map((lang) => (
        <button
          key={lang}
          onClick={() => setLanguage(lang)}
          className={`px-4 py-2 rounded-xl font-bold transition-all ${
            language === lang
              ? 'bg-white text-kid-blue shadow-sm'
              : 'text-gray-400 hover:text-gray-600'
          }`}
        >
          {languageNames[lang]}
        </button>
      ))}
    </div>
  );
};
