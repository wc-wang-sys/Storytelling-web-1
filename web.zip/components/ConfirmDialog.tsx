import React from 'react';
import { AlertTriangle, Check, X } from 'lucide-react';
import { Button } from './Button';

interface ConfirmDialogProps {
  isOpen: boolean;
  title: string;
  message: string;
  confirmLabel: string;
  cancelLabel: string;
  onConfirm: () => void;
  onCancel: () => void;
  variant?: 'danger' | 'warning' | 'info';
}

export const ConfirmDialog: React.FC<ConfirmDialogProps> = ({
  isOpen,
  title,
  message,
  confirmLabel,
  cancelLabel,
  onConfirm,
  onCancel,
  variant = 'warning',
}) => {
  if (!isOpen) return null;

  const variantStyles = {
    danger: {
      bg: 'bg-kid-pink/10',
      border: 'border-kid-pink',
      icon: 'text-kid-pink',
      button: 'bg-kid-pink hover:bg-pink-600',
    },
    warning: {
      bg: 'bg-kid-yellow/10',
      border: 'border-kid-yellow',
      icon: 'text-kid-yellow',
      button: 'bg-kid-yellow hover:bg-yellow-500 text-gray-800',
    },
    info: {
      bg: 'bg-kid-blue/10',
      border: 'border-kid-blue',
      icon: 'text-kid-blue',
      button: 'bg-kid-blue hover:bg-blue-500',
    },
  };

  const styles = variantStyles[variant];

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/50 backdrop-blur-sm"
        onClick={onCancel}
      />

      {/* Dialog */}
      <div className={`relative bg-white rounded-3xl shadow-2xl max-w-md w-full p-8 border-4 ${styles.border} animate-bounce-in`}>
        {/* Icon */}
        <div className={`w-16 h-16 rounded-full ${styles.bg} flex items-center justify-center mx-auto mb-6`}>
          <AlertTriangle size={32} className={styles.icon} />
        </div>

        {/* Title */}
        <h2 className="text-2xl font-extrabold text-center text-gray-800 mb-4">
          {title}
        </h2>

        {/* Message */}
        <p className="text-center text-gray-600 mb-8 leading-relaxed">
          {message}
        </p>

        {/* Buttons */}
        <div className="flex gap-4">
          <button
            onClick={onCancel}
            className="flex-1 py-4 px-6 rounded-2xl border-2 border-gray-200 font-bold text-gray-600 hover:bg-gray-50 transition-colors flex items-center justify-center gap-2"
          >
            <X size={20} />
            {cancelLabel}
          </button>
          <button
            onClick={onConfirm}
            className={`flex-1 py-4 px-6 rounded-2xl font-bold text-white transition-colors flex items-center justify-center gap-2 ${styles.button}`}
          >
            <Check size={20} />
            {confirmLabel}
          </button>
        </div>
      </div>

      <style>{`
        @keyframes bounce-in {
          0% { transform: scale(0.9); opacity: 0; }
          50% { transform: scale(1.02); }
          100% { transform: scale(1); opacity: 1; }
        }
        .animate-bounce-in {
          animation: bounce-in 0.3s ease-out forwards;
        }
      `}</style>
    </div>
  );
};
