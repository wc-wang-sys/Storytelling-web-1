import React, { useRef, useState, useEffect } from 'react';
import { Camera, X, AlertCircle, RefreshCw } from 'lucide-react';
import { Button } from './Button';
import { useLanguage } from '../contexts/LanguageContext';

interface BarcodeLike {
  rawValue?: string;
}

interface BarcodeDetectorLike {
  detect: (source: CanvasImageSource) => Promise<BarcodeLike[]>;
}

declare global {
  interface Window {
    BarcodeDetector?: new (options?: { formats?: string[] }) => BarcodeDetectorLike;
  }
}

interface QRCodeScannerProps {
  onScan: (data: string) => void;
  onClose: () => void;
}

export const QRCodeScanner: React.FC<QRCodeScannerProps> = ({ onScan, onClose }) => {
  const { t } = useLanguage();
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [error, setError] = useState<string | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const detectorRef = useRef<BarcodeDetectorLike | null>(null);
  const isFrameBusyRef = useRef(false);

  useEffect(() => {
    startCamera();
    return () => {
      stopCamera();
    };
  }, []);

  const startCamera = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' }
      });

      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
        await videoRef.current.play();
        setStream(mediaStream);
        setIsScanning(true);
        setError(null);

        if (window.BarcodeDetector && !detectorRef.current) {
          detectorRef.current = new window.BarcodeDetector({ formats: ['qr_code'] });
        }

        requestAnimationFrame(scanFrame);
      }
    } catch (err) {
      console.error('Camera access failed:', err);
      setError(t.alerts.cameraAccessError);
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
    setIsScanning(false);
  };

  const scanFrame = () => {
    if (!isScanning || !videoRef.current || !canvasRef.current) return;

    const video = videoRef.current;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');

    if (!ctx || video.readyState !== video.HAVE_ENOUGH_DATA) {
      requestAnimationFrame(scanFrame);
      return;
    }

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

    if (detectorRef.current && !isFrameBusyRef.current) {
      isFrameBusyRef.current = true;
      detectorRef.current.detect(canvas)
        .then((codes) => {
          const value = codes.find((item) => item.rawValue)?.rawValue;
          if (value) {
            stopCamera();
            onScan(value);
            return;
          }
          requestAnimationFrame(scanFrame);
        })
        .catch(() => {
          requestAnimationFrame(scanFrame);
        })
        .finally(() => {
          isFrameBusyRef.current = false;
        });
      return;
    }

    requestAnimationFrame(scanFrame);
  };

  const handleSimulateScan = () => {
    const manualToken = window.prompt('Paste QR token');
    if (!manualToken?.trim()) {
      return;
    }
    stopCamera();
    onScan(manualToken.trim());
  };

  const handleClose = () => {
    stopCamera();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black">
      <div className="absolute inset-0 flex flex-col">
        {/* Header */}
        <div className="flex justify-between items-center p-4 text-white">
          <h2 className="text-lg font-bold flex items-center gap-2">
            <Camera /> {t.qrCode.scan}
          </h2>
          <button
            onClick={handleClose}
            className="p-2 rounded-full hover:bg-white/20"
          >
            <X size={24} />
          </button>
        </div>

        {/* Camera View */}
        <div className="flex-1 relative overflow-hidden">
          {error ? (
            <div className="absolute inset-0 flex flex-col items-center justify-center text-white p-8 text-center">
              <AlertCircle size={64} className="mb-4 text-red-400" />
              <p className="text-lg mb-4">{error}</p>
              <Button variant="secondary" onClick={startCamera} icon={<RefreshCw />}>
                {t.qrCode.tryAgain}
              </Button>
            </div>
          ) : (
            <>
              <video
                ref={videoRef}
                className="w-full h-full object-cover"
                playsInline
                muted
              />
              <canvas ref={canvasRef} className="hidden" />

              {/* Scan Frame Overlay */}
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div className="w-64 h-64 relative">
                  {/* Corner decorations */}
                  <div className="absolute top-0 left-0 w-12 h-12 border-t-4 border-l-4 border-white rounded-tl-lg" />
                  <div className="absolute top-0 right-0 w-12 h-12 border-t-4 border-r-4 border-white rounded-tr-lg" />
                  <div className="absolute bottom-0 left-0 w-12 h-12 border-b-4 border-l-4 border-white rounded-bl-lg" />
                  <div className="absolute bottom-0 right-0 w-12 h-12 border-b-4 border-r-4 border-white rounded-br-lg" />

                  {/* Scanning line animation */}
                  <div className="absolute top-0 left-4 right-4 h-0.5 bg-kid-green animate-scan" />
                </div>
              </div>

              {/* Vignette */}
              <div className="absolute inset-0 pointer-events-none">
                <div className="absolute inset-0 bg-black/60" style={{
                  maskImage: 'radial-gradient(circle at center, transparent 120px, black 150px)',
                  WebkitMaskImage: 'radial-gradient(circle at center, transparent 120px, black 150px)'
                }} />
              </div>
            </>
          )}
        </div>

        {/* Footer */}
        <div className="p-6 text-center">
          <p className="text-white/70 text-sm mb-4">
            {t.login.showBadge}
          </p>

          {/* Simulate Scan Button (for demo) */}
          <Button
            variant="secondary"
            onClick={handleSimulateScan}
          >
            {t.login.simulateScan}
          </Button>
        </div>
      </div>

      <style>{`
        @keyframes scan {
          0% { transform: translateY(0); }
          50% { transform: translateY(256px); }
          100% { transform: translateY(0); }
        }
        .animate-scan {
          animation: scan 2s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
};
