import React, { useRef, useEffect } from 'react';
import { Download, X } from 'lucide-react';
import { Button } from './Button';
import { useLanguage } from '../contexts/LanguageContext';

interface QRCodeGeneratorProps {
  data: string;
  title: string;
  onClose: () => void;
}

// Simple QR code generator using Canvas
// In a real application, you would use a library like 'qrcode'
export const QRCodeGenerator: React.FC<QRCodeGeneratorProps> = ({ data, title, onClose }) => {
  const { t } = useLanguage();
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    generateQRCode();
  }, [data]);

  const generateQRCode = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const size = 200;
    const moduleSize = 5;
    canvas.width = size;
    canvas.height = size;

    // Fill white background
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, size, size);

    // Simple pattern generation (not a real QR code, just visual placeholder)
    // In production, use a proper QR code library
    const hash = simpleHash(data);
    const moduleCount = Math.floor(size / moduleSize);

    ctx.fillStyle = '#000000';

    // Finder patterns (the three big squares in corners)
    drawFinderPattern(ctx, 0, 0, moduleSize);
    drawFinderPattern(ctx, (moduleCount - 7) * moduleSize, 0, moduleSize);
    drawFinderPattern(ctx, 0, (moduleCount - 7) * moduleSize, moduleSize);

    // Data modules (pseudo-random based on hash)
    for (let i = 0; i < moduleCount; i++) {
      for (let j = 0; j < moduleCount; j++) {
        // Skip finder pattern areas
        if (isInFinderPattern(i, j, moduleCount)) continue;

        // Pseudo-random pattern based on data hash
        const shouldFill = ((hash * (i + 1) * (j + 1)) % 7) < 3;
        if (shouldFill) {
          ctx.fillRect(i * moduleSize, j * moduleSize, moduleSize - 1, moduleSize - 1);
        }
      }
    }
  };

  const simpleHash = (str: string): number => {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    return Math.abs(hash);
  };

  const isInFinderPattern = (x: number, y: number, size: number): boolean => {
    // Top-left
    if (x < 8 && y < 8) return true;
    // Top-right
    if (x >= size - 8 && y < 8) return true;
    // Bottom-left
    if (x < 8 && y >= size - 8) return true;
    return false;
  };

  const drawFinderPattern = (ctx: CanvasRenderingContext2D, x: number, y: number, moduleSize: number) => {
    // Outer square (7x7)
    ctx.fillStyle = '#000000';
    ctx.fillRect(x, y, 7 * moduleSize, moduleSize);
    ctx.fillRect(x, y + 6 * moduleSize, 7 * moduleSize, moduleSize);
    ctx.fillRect(x, y, moduleSize, 7 * moduleSize);
    ctx.fillRect(x + 6 * moduleSize, y, moduleSize, 7 * moduleSize);

    // Inner square (3x3)
    ctx.fillRect(x + 2 * moduleSize, y + 2 * moduleSize, 3 * moduleSize, 3 * moduleSize);
  };

  const handleDownload = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const link = document.createElement('a');
    link.download = `qrcode-${title.replace(/\s+/g, '-')}.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={onClose} />

      <div className="relative bg-white rounded-3xl shadow-2xl max-w-sm w-full p-8 text-center">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full hover:bg-gray-100 text-gray-400 hover:text-gray-600"
        >
          <X size={24} />
        </button>

        <h3 className="text-xl font-bold text-gray-800 mb-2">{t.admin.generateQR}</h3>
        <p className="text-gray-500 text-sm mb-6">{title}</p>

        <div className="bg-white p-4 rounded-2xl border-4 border-gray-100 inline-block mb-6">
          <canvas
            ref={canvasRef}
            className="mx-auto"
            style={{ imageRendering: 'pixelated' }}
          />
        </div>

        <p className="text-xs text-gray-400 mb-6 font-mono break-all px-4">
          {data}
        </p>

        <Button variant="primary" onClick={handleDownload} icon={<Download />} className="w-full">
          {t.qrCode.download}
        </Button>
      </div>
    </div>
  );
};
