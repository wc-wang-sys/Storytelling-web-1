export enum UserRole {
  STUDENT = 'Student',
  TEACHER = 'Teacher',
  TESTER = 'Tester'
}

export type BackendRole = 'student' | 'teacher' | 'school_admin' | 'super_admin';

export enum AgeGroup {
  TODDLER = '3~4',
  EARLY_READER = '4~5',
  PRE_TEEN = '5~6'
}

export interface Badge {
  id: string;
  name: string;
  icon: string;
  description: string;
}

export interface User {
  id: string;
  name: string;
  username?: string;
  role: UserRole;
  backendRole: BackendRole;
  schoolId?: string | null;
  schoolName?: string | null;
  classId?: string | null;
  classIds?: string[];
  teacherId?: string | null;
  studentId?: string | null;
  ageGroup?: AgeGroup | null;
  points: number;
  badges: Badge[];
}

export interface StoryPage {
  text: string;
  imageUrl: string;
  imagePrompt?: string; // Added to help with regeneration
  audioBase64?: string;
}

export interface StoryStyling {
  titleColor: string;
  fontFamily: 'font-sans' | 'font-serif' | 'font-mono' | 'font-comic';
}

export interface Story {
  id: string;
  title: string;
  coverImage: string;
  authorId: string;
  authorName: string;
  ageGroup: AgeGroup;
  character: { name: string; description: string; imageUrl: string };
  place: { name: string; description: string; imageUrl: string };
  time: string;
  pages: StoryPage[];
  styling: StoryStyling;
  createdAt: number;
  updatedAt?: number;
}

export enum WizardStep {
  AGE_SELECTION = 0,
  CHARACTER = 1,
  PLACE = 2,
  TIME = 3,
  PLOT = 4,
  PREVIEW = 5
}

export interface WizardState {
  step: WizardStep;
  ageGroup: AgeGroup | null;
  character: { description: string; imageUrl: string } | null;
  place: { description: string; imageUrl: string } | null;
  time: { description: string; imageUrl: string } | null;
  plotInput: string;
  generatedPages: StoryPage[];
}
