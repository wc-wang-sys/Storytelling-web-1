import React, { useEffect, useMemo, useState } from 'react';
import { User, UserRole } from '../types';
import { Button } from '../components/Button';
import { QrCode, User as UserIcon, Lock, GraduationCap, School, Bug, Smile, Camera } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { LanguageSwitcher } from '../components/LanguageSwitcher';
import { QRCodeScanner } from '../components/QRCodeScanner';
import {
  fetchPublicClasses,
  fetchPublicSchools,
  loginWithPassword,
  loginWithQrToken,
  registerStudentAccount,
  PublicClassOption,
  PublicSchoolOption,
  toErrorMessage,
} from '../services/backendService';

interface LoginProps {
  onLogin: (user: User) => Promise<void> | void;
}

export const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const { t } = useLanguage();
  const [fullName, setFullName] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [selectedRole, setSelectedRole] = useState<UserRole>(UserRole.STUDENT);
  const [method, setMethod] = useState<'form' | 'qr'>('form');
  const [isRegistering, setIsRegistering] = useState(false);
  const [showScanner, setShowScanner] = useState(false);
  const [schools, setSchools] = useState<PublicSchoolOption[]>([]);
  const [classes, setClasses] = useState<PublicClassOption[]>([]);
  const [selectedSchoolId, setSelectedSchoolId] = useState('');
  const [selectedClassId, setSelectedClassId] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (!isRegistering) {
      return;
    }

    fetchPublicSchools()
      .then(setSchools)
      .catch((error) => alert(toErrorMessage(error)));
  }, [isRegistering]);

  useEffect(() => {
    if (!isRegistering || !selectedSchoolId) {
      setClasses([]);
      setSelectedClassId('');
      return;
    }

    fetchPublicClasses(selectedSchoolId)
      .then(setClasses)
      .catch((error) => alert(toErrorMessage(error)));
  }, [isRegistering, selectedSchoolId]);

  const canRegister = useMemo(
    () => isRegistering && selectedRole === UserRole.STUDENT,
    [isRegistering, selectedRole],
  );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!username || !password) {
      alert(t.alerts.enterUsernamePassword);
      return;
    }

    setIsSubmitting(true);

    try {
      if (isRegistering) {
        if (!fullName) {
          alert(t.alerts.enterYourName);
          return;
        }

        if (selectedRole !== UserRole.STUDENT) {
          throw new Error('Only student sign-up is supported here');
        }

        if (!selectedSchoolId || !selectedClassId) {
          throw new Error(`${t.admin.selectSchool} / ${t.admin.selectClass}`);
        }

        const registeredUser = await registerStudentAccount({
          fullName,
          username,
          password,
          schoolId: selectedSchoolId,
          classId: selectedClassId,
        });

        await onLogin(registeredUser);
        return;
      }

      const loggedInUser = await loginWithPassword({ username, password });
      if (selectedRole !== loggedInUser.role) {
        throw new Error('Selected role does not match this account');
      }

      await onLogin(loggedInUser);
    } catch (error) {
      alert(toErrorMessage(error));
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleQrScan = async (token: string) => {
    setShowScanner(false);

    try {
      const loggedInUser = await loginWithQrToken(token);
      await onLogin(loggedInUser);
    } catch (error) {
      alert(toErrorMessage(error));
    }
  };

  const handleManualQrLogin = async () => {
    const token = window.prompt('Paste QR token');
    if (!token?.trim()) {
      return;
    }

    try {
      const loggedInUser = await loginWithQrToken(token.trim());
      await onLogin(loggedInUser);
    } catch (error) {
      alert(toErrorMessage(error));
    }
  };

  const toggleRegister = () => {
    const next = !isRegistering;
    setIsRegistering(next);

    if (next) {
      setSelectedRole(UserRole.STUDENT);
      setSelectedSchoolId('');
      setSelectedClassId('');
      return;
    }

    setFullName('');
    setSelectedSchoolId('');
    setSelectedClassId('');
  };

  const roleOptions = [
    { role: UserRole.STUDENT, icon: <GraduationCap size={24} />, label: t.login.student, color: "bg-kid-blue border-blue-300" },
    { role: UserRole.TEACHER, icon: <School size={24} />, label: t.login.teacher, color: "bg-kid-green border-green-300" },
    { role: UserRole.TESTER, icon: <Bug size={24} />, label: t.login.tester, color: "bg-kid-pink border-pink-300" }
  ];

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-gradient-to-b from-kid-blue to-purple-200">
      <div className="absolute top-4 right-4">
        <LanguageSwitcher compact />
      </div>

      <div className="bg-white p-6 md:p-8 rounded-[3rem] shadow-2xl max-w-lg w-full border-8 border-kid-yellow animate-fade-in">
        <h1 className="text-4xl font-extrabold text-center text-kid-purple mb-2">
          {t.login.title}
        </h1>
        <p className="text-center text-gray-500 font-bold mb-6">{t.login.subtitle}</p>

        <div className="bg-gray-100 p-1 rounded-2xl flex mb-6">
          <button
            onClick={() => setMethod('form')}
            className={`flex-1 py-3 rounded-xl font-bold transition-all ${method === 'form' ? 'bg-white text-kid-blue shadow-sm' : 'text-gray-400'}`}
          >
            {t.login.password}
          </button>
          <button
            onClick={() => setMethod('qr')}
            className={`flex-1 py-3 rounded-xl font-bold transition-all ${method === 'qr' ? 'bg-white text-kid-blue shadow-sm' : 'text-gray-400'}`}
          >
            {t.login.qrCode}
          </button>
        </div>

        {method === 'form' ? (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-3 gap-2 mb-4">
              {roleOptions.map((opt) => (
                <button
                  key={opt.role}
                  type="button"
                  onClick={() => setSelectedRole(opt.role)}
                  className={`flex flex-col items-center justify-center p-2 rounded-2xl border-2 transition-all ${
                    selectedRole === opt.role
                      ? `${opt.color} text-white shadow-md scale-105 border-transparent`
                      : 'bg-white border-gray-200 text-gray-400 hover:bg-gray-50'
                  }`}
                >
                  {opt.icon}
                  <span className="text-xs font-bold mt-1">{opt.label}</span>
                </button>
              ))}
            </div>

            <div className="space-y-4">
              {isRegistering && (
                <>
                  <div className="relative animate-slide-up">
                    <Smile className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" size={24} />
                    <input
                      type="text"
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      className="w-full pl-12 pr-4 py-4 text-lg rounded-2xl border-4 border-gray-200 focus:border-kid-pink outline-none placeholder-gray-400 font-bold text-gray-700"
                      placeholder={t.login.yourName}
                    />
                  </div>

                  <select
                    value={selectedSchoolId}
                    onChange={(e) => setSelectedSchoolId(e.target.value)}
                    className="w-full px-4 py-4 text-lg rounded-2xl border-4 border-gray-200 focus:border-kid-pink outline-none font-bold text-gray-700 bg-white"
                  >
                    <option value="">{t.admin.selectSchool}</option>
                    {schools.map((school) => (
                      <option key={school.id} value={school.id}>
                        {school.name}
                      </option>
                    ))}
                  </select>

                  <select
                    value={selectedClassId}
                    onChange={(e) => setSelectedClassId(e.target.value)}
                    disabled={!selectedSchoolId}
                    className="w-full px-4 py-4 text-lg rounded-2xl border-4 border-gray-200 focus:border-kid-pink outline-none font-bold text-gray-700 bg-white disabled:opacity-60"
                  >
                    <option value="">{t.admin.selectClass}</option>
                    {classes.map((schoolClass) => (
                      <option key={schoolClass.id} value={schoolClass.id}>
                        {schoolClass.grade} · {schoolClass.name}
                      </option>
                    ))}
                  </select>
                </>
              )}

              <div className="relative">
                <UserIcon className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" size={24} />
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full pl-12 pr-4 py-4 text-lg rounded-2xl border-4 border-gray-200 focus:border-kid-pink outline-none placeholder-gray-400 font-bold text-gray-700"
                  placeholder={t.login.username}
                />
              </div>

              <div className="relative">
                <Lock className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" size={24} />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-12 pr-4 py-4 text-lg rounded-2xl border-4 border-gray-200 focus:border-kid-pink outline-none placeholder-gray-400 font-bold text-gray-700"
                  placeholder={t.login.password}
                />
              </div>
            </div>

            {!canRegister && isRegistering && (
              <p className="text-sm text-center text-gray-500">{t.login.student} only</p>
            )}

            <Button type="submit" size="xl" variant="primary" className="w-full mt-6 bg-kid-blue hover:bg-blue-400 border-none shadow-blue-200">
              {isSubmitting ? t.loading : isRegistering ? t.login.signUp : t.login.logIn}
            </Button>

            <div className="text-center pt-4">
              <button
                type="button"
                onClick={toggleRegister}
                className="text-kid-purple font-bold text-lg"
              >
                <span className="text-gray-500 font-normal mr-1">{isRegistering ? t.login.hasAccount : t.login.noAccount}</span>
                {isRegistering ? t.login.logIn : t.login.signUp}
              </button>
            </div>
          </form>
        ) : (
          <div className="text-center py-8">
            <div className="bg-gray-200 w-48 h-48 mx-auto rounded-xl flex items-center justify-center mb-6 border-4 border-dashed border-gray-400">
              <div className="space-y-2">
                <QrCode size={48} className="mx-auto text-gray-400" />
                <span className="text-gray-400 font-bold block">{t.login.qrCode}</span>
              </div>
            </div>
            <p className="text-lg text-gray-600 mb-6">{t.login.showBadge}</p>
            <div className="flex flex-col gap-3 items-center">
              <Button type="button" onClick={() => setShowScanner(true)} size="lg" variant="primary" icon={<Camera />}>
                {t.qrCode.scan}
              </Button>
              <Button type="button" onClick={handleManualQrLogin} size="sm" variant="outline">
                {t.login.simulateScan}
              </Button>
            </div>
          </div>
        )}

        {showScanner && (
          <QRCodeScanner
            onScan={handleQrScan}
            onClose={() => setShowScanner(false)}
          />
        )}
      </div>
    </div>
  );
};
