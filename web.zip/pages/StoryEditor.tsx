import React, { useState, useEffect, useCallback } from 'react';
import { Story } from '../types';
import { Button } from '../components/Button';
import { generateImage, generateText } from '../services/geminiService';
import { buildCoverRegenerationPrompt, buildPageImagePrompt, buildPageRewriteTask } from '../services/promptService';
import { useLanguage } from '../contexts/LanguageContext';
import { ConfirmDialog } from '../components/ConfirmDialog';
import { SensitiveInputGuidance, getSensitiveInputGuidance, moderateStudentInput } from '../services/contentModeration';
import { Save, X, RefreshCw, Type, Palette, Image as ImageIcon, LayoutTemplate } from 'lucide-react';

interface StoryEditorProps {
  story: Story;
  onSave: (updatedStory: Story) => void;
  onDiscard: () => void;
}

type EditorTab = 'cover' | 'content';

const TITLE_SIZE_OPTIONS = [
  { value: 'text-2xl', label: 'S' },
  { value: 'text-3xl', label: 'M' },
  { value: 'text-4xl', label: 'L' },
  { value: 'text-5xl', label: 'XL' },
];

export const StoryEditor: React.FC<StoryEditorProps> = ({ story, onSave, onDiscard }) => {
  const { t, language } = useLanguage();
  const [editedStory, setEditedStory] = useState<Story>({ ...story });
  const [activeTab, setActiveTab] = useState<EditorTab>('cover');
  const [currentPageIndex, setCurrentPageIndex] = useState(0);
  const [isRegenerating, setIsRegenerating] = useState(false);
  const [isModerating, setIsModerating] = useState(false);
  const [hasChanges, setHasChanges] = useState(false);
  const [showDiscardDialog, setShowDiscardDialog] = useState(false);
  const [titleSize, setTitleSize] = useState('text-3xl');
  const [moderationGuidance, setModerationGuidance] = useState<SensitiveInputGuidance | null>(null);

  // Track changes
  useEffect(() => {
    const isChanged = JSON.stringify(story) !== JSON.stringify(editedStory);
    setHasChanges(isChanged);
  }, [editedStory, story]);

  // Handle discard with confirmation
  const handleDiscard = useCallback(() => {
    if (hasChanges) {
      setShowDiscardDialog(true);
    } else {
      onDiscard();
    }
  }, [hasChanges, onDiscard]);

  const confirmDiscard = () => {
    setShowDiscardDialog(false);
    onDiscard();
  };

  const clearModerationGuidance = useCallback(() => {
    setModerationGuidance(null);
  }, []);

  const showModerationGuidance = useCallback(() => {
    setModerationGuidance(getSensitiveInputGuidance(language));
  }, [language]);

  // --- Cover Editing Functions ---

  const handleTitleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    clearModerationGuidance();
    setEditedStory(prev => ({ ...prev, title: e.target.value }));
  };

  const handleColorChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setEditedStory(prev => ({ 
        ...prev, 
        styling: { ...prev.styling, titleColor: e.target.value } 
    }));
  };

  const handleFontChange = (font: any) => {
    setEditedStory(prev => ({ 
        ...prev, 
        styling: { ...prev.styling, fontFamily: font } 
    }));
  };

  const regenerateCoverImage = async () => {
    setIsRegenerating(true);
    try {
        const prompt = await buildCoverRegenerationPrompt(editedStory);
        const newUrl = await generateImage(prompt);
        setEditedStory(prev => ({ ...prev, coverImage: newUrl }));
    } catch (e) {
        alert(t.alerts.couldNotRegenerateCover);
    } finally {
        setIsRegenerating(false);
    }
  };

  // --- Content Editing Functions ---

  const handlePageTextChange = (text: string) => {
      clearModerationGuidance();
      const newPages = [...editedStory.pages];
      newPages[currentPageIndex].text = text;
      setEditedStory(prev => ({ ...prev, pages: newPages }));
  };

  const regeneratePageImage = async () => {
    setIsRegenerating(true);
    const page = editedStory.pages[currentPageIndex];
    try {
        const prompt = await buildPageImagePrompt(page);
        const newUrl = await generateImage(prompt);

        const newPages = [...editedStory.pages];
        newPages[currentPageIndex].imageUrl = newUrl;
        setEditedStory(prev => ({ ...prev, pages: newPages }));
    } catch (e) {
        alert(t.alerts.couldNotRegenerateImage);
    } finally {
        setIsRegenerating(false);
    }
  };

  const regeneratePageText = async () => {
    setIsRegenerating(true);
    const page = editedStory.pages[currentPageIndex];
    try {
        const task = await buildPageRewriteTask(editedStory.ageGroup, page.text);
        const newText = await generateText(task, editedStory.ageGroup);
        const newPages = [...editedStory.pages];
        newPages[currentPageIndex].text = newText;
        setEditedStory(prev => ({ ...prev, pages: newPages }));
    } catch (e) {
        alert(t.alerts.couldNotRewriteText);
    } finally {
        setIsRegenerating(false);
    }
  }

  const validateEditedStory = useCallback(async () => {
    const titleChanged = editedStory.title.trim() !== story.title.trim();
    if (titleChanged && editedStory.title.trim()) {
      const result = await moderateStudentInput(editedStory.title);
      if (!result.safe) {
        setActiveTab('cover');
        showModerationGuidance();
        return false;
      }
    }

    for (let index = 0; index < editedStory.pages.length; index += 1) {
      const currentText = editedStory.pages[index]?.text?.trim() || '';
      const originalText = story.pages[index]?.text?.trim() || '';

      if (!currentText || currentText === originalText) {
        continue;
      }

      const result = await moderateStudentInput(currentText);
      if (!result.safe) {
        setActiveTab('content');
        setCurrentPageIndex(index);
        showModerationGuidance();
        return false;
      }
    }

    clearModerationGuidance();
    return true;
  }, [clearModerationGuidance, editedStory, showModerationGuidance, story]);

  const handleSave = async () => {
    setIsModerating(true);
    try {
      const isSafe = await validateEditedStory();
      if (!isSafe) {
        return;
      }

      onSave(editedStory);
    } finally {
      setIsModerating(false);
    }
  };

  const renderModerationGuidance = () => {
    if (!moderationGuidance) {
      return null;
    }

    return (
      <div className="rounded-3xl border-4 border-amber-200 bg-amber-50 p-5 text-left shadow-sm">
        <p className="text-lg font-bold text-amber-700">{moderationGuidance.title}</p>
        <p className="mt-2 text-base font-semibold text-amber-700">{moderationGuidance.subtitle}</p>
        <p className="mt-4 text-sm font-bold text-amber-600">{moderationGuidance.intro}</p>
        <div className="mt-2 space-y-1 text-sm text-amber-800">
          {moderationGuidance.suggestions.map((suggestion) => (
            <p key={suggestion}>• {suggestion}</p>
          ))}
        </div>
      </div>
    );
  };

  // --- Render Helpers ---

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Discard Confirmation Dialog */}
      <ConfirmDialog
        isOpen={showDiscardDialog}
        title={t.editor.unsavedChanges}
        message={t.editor.discardChanges + '?'}
        confirmLabel={t.editor.discardAll}
        cancelLabel={t.cancel}
        onConfirm={confirmDiscard}
        onCancel={() => setShowDiscardDialog(false)}
        variant="danger"
      />

      {/* Top Toolbar */}
      <header className="bg-white border-b-4 border-kid-blue p-4 flex justify-between items-center sticky top-0 z-50 shadow-sm">
        <h2 className="text-2xl font-extrabold text-kid-purple flex items-center gap-2">
            <LayoutTemplate /> {t.editor.editStory}
            {hasChanges && <span className="text-sm bg-kid-yellow text-gray-800 px-2 py-1 rounded-full">*</span>}
        </h2>
        <div className="flex gap-4">
            <Button variant="outline" onClick={handleDiscard} icon={<X />} disabled={isModerating}>{t.editor.discardChanges}</Button>
            <Button variant="primary" onClick={() => void handleSave()} icon={<Save />} disabled={isRegenerating || isModerating}>
              {isModerating ? t.loading : t.editor.saveAndExit}
            </Button>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar Navigation */}
        <aside className="w-64 bg-white border-r border-gray-200 flex flex-col p-4 overflow-y-auto">
            <div className="mb-6">
                <h3 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-2">{t.editorExt.sections}</h3>
                <button
                    onClick={() => setActiveTab('cover')}
                    className={`w-full text-left p-3 rounded-xl font-bold mb-2 transition-colors ${activeTab === 'cover' ? 'bg-kid-blue text-white' : 'hover:bg-gray-100 text-gray-600'}`}
                >
                    {t.editorExt.bookCover}
                </button>
                <button
                    onClick={() => setActiveTab('content')}
                    className={`w-full text-left p-3 rounded-xl font-bold transition-colors ${activeTab === 'content' ? 'bg-kid-blue text-white' : 'hover:bg-gray-100 text-gray-600'}`}
                >
                    {t.editorExt.storyPages}
                </button>
            </div>

            {activeTab === 'content' && (
                <div>
                     <h3 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-2">{t.editorExt.pages}</h3>
                     <div className="space-y-2">
                        {editedStory.pages.map((p, idx) => (
                            <button
                                key={idx}
                                onClick={() => setCurrentPageIndex(idx)}
                                className={`w-full p-2 rounded-lg border-2 flex items-center gap-2 ${currentPageIndex === idx ? 'border-kid-pink bg-pink-50' : 'border-gray-100 hover:border-gray-300'}`}
                            >
                                <div className="w-8 h-8 rounded bg-gray-200 overflow-hidden flex-shrink-0">
                                    <img src={p.imageUrl} className="w-full h-full object-cover" />
                                </div>
                                <span className="text-xs font-bold truncate">{t.editorExt.pageNum} {idx + 1}</span>
                            </button>
                        ))}
                     </div>
                </div>
            )}
        </aside>

        {/* Main Editor Area */}
        <main className="flex-1 p-8 overflow-y-auto bg-gray-50 flex justify-center">
            
            {/* --- COVER EDITOR --- */}
            {activeTab === 'cover' && (
                <div className="w-full max-w-2xl bg-white rounded-[2rem] shadow-xl overflow-hidden border-8 border-white animate-fade-in">
                    <div className="relative h-96 group">
                        <img src={editedStory.coverImage} className="w-full h-full object-cover" />
                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                            <Button
                                onClick={regenerateCoverImage}
                                icon={isRegenerating ? <RefreshCw className="animate-spin"/> : <RefreshCw />}
                                variant="secondary"
                                disabled={isRegenerating || isModerating}
                            >
                                {t.editorExt.regenerateArt}
                            </Button>
                        </div>
                    </div>
                    <div className="p-8 space-y-6">
                        <div>
                            <label className="block text-gray-500 font-bold mb-2 text-sm uppercase">{t.editor.editStory}</label>
                            <input
                                value={editedStory.title}
                                onChange={handleTitleChange}
                                disabled={isModerating}
                                className={`w-full ${titleSize} font-bold border-b-4 border-gray-200 focus:border-kid-blue outline-none py-2 ${editedStory.styling.fontFamily}`}
                                style={{ color: editedStory.styling.titleColor }}
                            />
                        </div>

                        {activeTab === 'cover' && renderModerationGuidance()}

                        <div className="grid grid-cols-3 gap-6">
                            <div>
                                <label className="block text-gray-500 font-bold mb-2 text-sm uppercase flex items-center gap-2">
                                    <Type size={16}/> {t.editor.titleSize}
                                </label>
                                <div className="flex gap-2">
                                    {TITLE_SIZE_OPTIONS.map(size => (
                                        <button
                                            key={size.value}
                                            onClick={() => setTitleSize(size.value)}
                                            className={`w-10 h-10 rounded-lg border-2 flex items-center justify-center font-bold transition-all ${titleSize === size.value ? 'border-kid-purple bg-purple-50 text-kid-purple' : 'border-gray-200 hover:border-gray-300'}`}
                                        >
                                            {size.label}
                                        </button>
                                    ))}
                                </div>
                            </div>
                            <div>
                                <label className="block text-gray-500 font-bold mb-2 text-sm uppercase flex items-center gap-2">
                                    <Palette size={16}/> {t.editor.titleColor}
                                </label>
                                <div className="flex items-center gap-3">
                                    <input
                                        type="color"
                                        value={editedStory.styling.titleColor}
                                        onChange={handleColorChange}
                                        className="w-12 h-12 rounded-full cursor-pointer border-none"
                                    />
                                    <span className="text-gray-400 font-mono">{editedStory.styling.titleColor}</span>
                                </div>
                            </div>
                            <div>
                                <label className="block text-gray-500 font-bold mb-2 text-sm uppercase flex items-center gap-2">
                                    <Type size={16}/> {t.editor.fontFamily}
                                </label>
                                <div className="flex gap-2">
                                    {['font-sans', 'font-serif', 'font-comic'].map(f => (
                                        <button
                                            key={f}
                                            onClick={() => handleFontChange(f)}
                                            className={`w-10 h-10 rounded-lg border-2 flex items-center justify-center text-xl ${f} ${editedStory.styling.fontFamily === f ? 'border-kid-blue bg-blue-50 text-kid-blue' : 'border-gray-200'}`}
                                        >
                                            Aa
                                        </button>
                                    ))}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {/* --- PAGE CONTENT EDITOR --- */}
            {activeTab === 'content' && (
                <div className="w-full max-w-4xl flex flex-col md:flex-row gap-8 items-start animate-fade-in">
                    {/* Visual Side */}
                    <div className="flex-1 w-full relative group">
                         <div className="aspect-square bg-white rounded-3xl border-8 border-white shadow-lg overflow-hidden relative">
                             <img src={editedStory.pages[currentPageIndex].imageUrl} className="w-full h-full object-cover" />
                             {isRegenerating && <div className="absolute inset-0 bg-white/80 flex items-center justify-center"><RefreshCw className="animate-spin text-kid-blue" size={48}/></div>}
                         </div>
                         <div className="mt-4 flex justify-center">
                            <Button size="sm" variant="secondary" onClick={regeneratePageImage} icon={<ImageIcon />} disabled={isRegenerating || isModerating}>
                                {t.editorExt.redrawPicture}
                            </Button>
                         </div>
                    </div>

                    {/* Text Side */}
                    <div className="flex-1 w-full bg-white p-6 rounded-3xl border-4 border-kid-yellow shadow-sm">
                        <label className="block text-gray-500 font-bold mb-2 text-sm uppercase">{t.editorExt.storyText}</label>
                        <textarea
                            className="w-full h-48 p-4 text-xl leading-relaxed font-comic border-2 border-dashed border-gray-300 rounded-xl focus:border-kid-yellow outline-none resize-none"
                            value={editedStory.pages[currentPageIndex].text}
                            disabled={isModerating}
                            onChange={(e) => handlePageTextChange(e.target.value)}
                        />
                        {activeTab === 'content' && renderModerationGuidance()}
                         <div className="mt-4 flex justify-end">
                            <Button size="sm" variant="outline" onClick={regeneratePageText} icon={<RefreshCw />} disabled={isRegenerating || isModerating}>
                                {t.editorExt.rewriteText}
                            </Button>
                         </div>
                    </div>
                </div>
            )}

        </main>
      </div>
    </div>
  );
};
