import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Story } from '../types';
import { Button } from '../components/Button';
import { generateSpeech } from '../services/geminiService';
import { useLanguage } from '../contexts/LanguageContext';
import { getVoiceCommandListener, mapLanguageToSpeech } from '../services/speechService';
import { StylePicker, StyleOptions, getFontSizeClass } from '../components/StylePicker';
import { ArrowLeft, ArrowRight, X, Volume2, StopCircle, Mic, MicOff, Type } from 'lucide-react';

interface StoryReaderProps {
  story: Story;
  onExit: () => void;
}

// Voices mapping for UI
const VOICES = [
  { id: 'Kore', labelKey: 'storyteller' as const, icon: '👩' },
  { id: 'Puck', labelKey: 'buddy' as const, icon: '🧒' },
  { id: 'Fenrir', labelKey: 'grandpa' as const, icon: '👴' },
];

export const StoryReader: React.FC<StoryReaderProps> = ({ story, onExit }) => {
  const { t, language } = useLanguage();
  const [currentPage, setCurrentPage] = useState(0);
  const [selectedVoice, setSelectedVoice] = useState('Kore');
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoadingAudio, setIsLoadingAudio] = useState(false);
  const [isVoiceControlActive, setIsVoiceControlActive] = useState(false);
  const [showStylePicker, setShowStylePicker] = useState(false);
  const [styleOptions, setStyleOptions] = useState<StyleOptions>({
    fontFamily: story.styling.fontFamily || 'font-comic',
    fontSize: 'medium',
    textColor: story.styling.titleColor || '#374151',
  });

  // Audio Context Refs
  const audioContextRef = useRef<AudioContext | null>(null);
  const sourceNodeRef = useRef<AudioBufferSourceNode | null>(null);
  const voiceCommandRef = useRef(getVoiceCommandListener());

  // Voice command handling
  const handleVoiceCommand = useCallback((command: string) => {
    switch (command) {
      case 'next':
        setCurrentPage(prev => {
          if (prev < story.pages.length - 1) {
            stopAudioInternal();
            return prev + 1;
          }
          return prev;
        });
        break;
      case 'prev':
        setCurrentPage(prev => {
          if (prev > 0) {
            stopAudioInternal();
            return prev - 1;
          }
          return prev;
        });
        break;
      case 'exit':
        onExit();
        break;
    }
  }, [story.pages.length, onExit]);

  // Internal stop audio function (doesn't update state)
  const stopAudioInternal = () => {
    if (sourceNodeRef.current) {
      try {
        sourceNodeRef.current.stop();
      } catch (e) {
        // Ignore errors if already stopped
      }
      sourceNodeRef.current = null;
    }
  };

  useEffect(() => {
    const voiceListener = voiceCommandRef.current;
    voiceListener.setLanguage(mapLanguageToSpeech(language));
    voiceListener.onCommand(handleVoiceCommand);

    return () => {
      stopAudio();
      voiceListener.stop();
      if (audioContextRef.current) {
        audioContextRef.current.close();
      }
    };
  }, [handleVoiceCommand, language]);

  // Toggle voice control
  const toggleVoiceControl = () => {
    const voiceListener = voiceCommandRef.current;
    if (isVoiceControlActive) {
      voiceListener.stop();
      setIsVoiceControlActive(false);
    } else {
      voiceListener.setLanguage(mapLanguageToSpeech(language));
      if (voiceListener.start()) {
        setIsVoiceControlActive(true);
      }
    }
  };

  // Stop current playback
  const stopAudio = () => {
    if (sourceNodeRef.current) {
      try {
        sourceNodeRef.current.stop();
      } catch (e) {
        // Ignore errors if already stopped
      }
      sourceNodeRef.current = null;
    }
    setIsPlaying(false);
  };

  // Decode Base64 Audio
  const decodeAndPlay = async (base64Data: string) => {
    try {
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      }

      // Resume context if suspended (browser policy)
      if (audioContextRef.current.state === 'suspended') {
        await audioContextRef.current.resume();
      }

      // 1. Decode Base64 to ArrayBuffer
      const binaryString = atob(base64Data);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      
      // 2. Convert raw PCM to AudioBuffer
      // NOTE: gemini-2.5-flash-preview-tts returns raw PCM 16-bit 24kHz mono
      const dataInt16 = new Int16Array(bytes.buffer);
      const numChannels = 1;
      const sampleRate = 24000;
      const frameCount = dataInt16.length / numChannels;
      
      const audioBuffer = audioContextRef.current.createBuffer(numChannels, frameCount, sampleRate);
      
      for (let channel = 0; channel < numChannels; channel++) {
        const channelData = audioBuffer.getChannelData(channel);
        for (let i = 0; i < frameCount; i++) {
          channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
        }
      }

      // 3. Play
      const source = audioContextRef.current.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(audioContextRef.current.destination);
      source.onended = () => setIsPlaying(false);
      
      sourceNodeRef.current = source;
      source.start();
      setIsPlaying(true);

    } catch (e) {
      console.error("Error playing audio", e);
      alert(t.alerts.couldNotPlayAudio);
      setIsPlaying(false);
    }
  };

  const handlePlay = async () => {
    if (isPlaying) {
      stopAudio();
      return;
    }

    const text = story.pages[currentPage].text;
    if (!text) return;

    setIsLoadingAudio(true);
    try {
      // In a real app, we would cache this in the story object to avoid re-generating
      const base64 = await generateSpeech(text, selectedVoice);
      if (base64) {
        await decodeAndPlay(base64);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoadingAudio(false);
    }
  };

  const handleNext = () => {
    stopAudio();
    if (currentPage < story.pages.length - 1) {
      setCurrentPage(prev => prev + 1);
    }
  };

  const handlePrev = () => {
    stopAudio();
    if (currentPage > 0) {
      setCurrentPage(prev => prev - 1);
    }
  };

  const page = story.pages[currentPage];

  return (
    <div className="fixed inset-0 bg-kid-blue/10 flex flex-col z-50 overflow-hidden font-sans">
      {/* Top Bar */}
      <div className="bg-white p-4 shadow-md flex justify-between items-center z-10">
        <div className="flex items-center gap-4">
          <Button variant="outline" size="sm" onClick={onExit} icon={<X />}>
            {t.close}
          </Button>
          <span className="font-bold text-kid-purple text-lg truncate max-w-xs hidden md:block">
            {story.title}
          </span>
        </div>

        <div className="flex items-center gap-2">
          {/* Voice Control Toggle */}
          <button
            onClick={toggleVoiceControl}
            className={`p-2 rounded-xl border-2 transition-all flex items-center gap-2 ${
              isVoiceControlActive
                ? 'bg-kid-green/10 border-kid-green text-kid-green'
                : 'border-gray-200 text-gray-400 hover:border-gray-300'
            }`}
            title={t.reader.voiceControl}
          >
            {isVoiceControlActive ? <Mic size={20} className="animate-pulse" /> : <MicOff size={20} />}
            <span className="hidden md:inline text-sm font-bold">{t.reader.voiceControl}</span>
          </button>

          {/* Style Picker Toggle */}
          <button
            onClick={() => setShowStylePicker(!showStylePicker)}
            className={`p-2 rounded-xl border-2 transition-all ${
              showStylePicker
                ? 'bg-kid-blue/10 border-kid-blue text-kid-blue'
                : 'border-gray-200 text-gray-400 hover:border-gray-300'
            }`}
            title={t.reader.textStyle}
          >
            <Type size={20} />
          </button>

          {/* Voice Selector */}
          <div className="flex items-center gap-1 bg-gray-100 p-1 rounded-2xl">
            {VOICES.map(v => (
              <button
                key={v.id}
                onClick={() => { stopAudio(); setSelectedVoice(v.id); }}
                className={`px-3 py-2 rounded-xl text-sm font-bold flex items-center gap-1 transition-all ${selectedVoice === v.id ? 'bg-white shadow-sm text-kid-blue' : 'text-gray-400'}`}
              >
                <span>{v.icon}</span> <span className="hidden sm:inline">{t.reader[v.labelKey]}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Style Picker Overlay */}
      {showStylePicker && (
        <div className="absolute top-20 right-4 z-20 w-80">
          <StylePicker
            value={styleOptions}
            onChange={setStyleOptions}
          />
        </div>
      )}

      {/* Book View */}
      <div className="flex-1 flex items-center justify-center p-4 md:p-8 overflow-y-auto">
        <div className="bg-white w-full max-w-6xl aspect-[4/3] md:aspect-[16/9] rounded-[3rem] shadow-2xl border-8 border-white overflow-hidden flex flex-col md:flex-row relative">
          
          {/* Image Side */}
          <div className="md:w-1/2 h-1/2 md:h-full relative bg-gray-100">
             <img 
               src={page.imageUrl} 
               alt={`Page ${currentPage + 1}`} 
               className="w-full h-full object-cover"
             />
             <div className="absolute top-4 left-4 bg-white/80 backdrop-blur px-4 py-2 rounded-full font-bold text-gray-600 border-2 border-white shadow-sm">
                {t.reader.page} {currentPage + 1}
             </div>
          </div>

          {/* Text Side */}
          <div className="md:w-1/2 h-1/2 md:h-full p-8 md:p-12 flex flex-col justify-center items-center bg-yellow-50/50">
             <p
                className={`${getFontSizeClass(styleOptions.fontSize)} leading-relaxed text-center ${styleOptions.fontFamily}`}
                style={{ color: styleOptions.textColor }}
             >
                {page.text}
             </p>

             <div className="mt-8 md:mt-12">
               <button
                  onClick={handlePlay}
                  disabled={isLoadingAudio}
                  className={`w-20 h-20 rounded-full flex items-center justify-center shadow-lg transform transition-all active:scale-95 border-4 border-white ${isPlaying ? 'bg-kid-pink animate-pulse' : 'bg-kid-green hover:bg-green-400'}`}
               >
                 {isLoadingAudio ? (
                    <div className="w-8 h-8 border-4 border-white border-t-transparent rounded-full animate-spin" />
                 ) : isPlaying ? (
                    <StopCircle size={40} className="text-white fill-current" />
                 ) : (
                    <Volume2 size={40} className="text-white fill-current" />
                 )}
               </button>
               <p className="text-center text-gray-400 font-bold mt-2 text-sm uppercase tracking-wide">
                  {isPlaying ? t.reader.listening : t.reader.readToMe}
               </p>
             </div>
          </div>

        </div>
      </div>

      {/* Navigation Bar */}
      <div className="bg-white p-4 pb-8 flex justify-center items-center gap-8 shadow-[0_-10px_40px_rgba(0,0,0,0.1)]">
         <Button
            variant="secondary"
            size="lg"
            onClick={handlePrev}
            disabled={currentPage === 0}
            className={currentPage === 0 ? 'opacity-50' : ''}
            icon={<ArrowLeft />}
         >
           {t.reader.prev}
         </Button>

         <div className="text-2xl font-bold text-gray-300">
           {currentPage + 1} / {story.pages.length}
         </div>

         <Button
            variant="primary"
            size="lg"
            onClick={handleNext}
            disabled={currentPage === story.pages.length - 1}
            className={currentPage === story.pages.length - 1 ? 'opacity-50' : ''}
         >
           {t.reader.next} <ArrowRight className="inline ml-2" size={24}/>
         </Button>
      </div>

      {/* Voice Control Instructions */}
      {isVoiceControlActive && (
        <div className="fixed bottom-32 left-1/2 -translate-x-1/2 bg-kid-green text-white px-6 py-3 rounded-full shadow-lg flex items-center gap-3 animate-bounce">
          <Mic size={20} className="animate-pulse" />
          <span className="font-bold">{t.reader.voiceControlHint}</span>
        </div>
      )}
    </div>
  );
};