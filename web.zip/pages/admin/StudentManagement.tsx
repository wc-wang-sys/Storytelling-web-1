import React, { useState, useMemo, useRef } from 'react';
import { Button } from '../../components/Button';
import { useLanguage } from '../../contexts/LanguageContext';
import { AgeGroup } from '../../types';
import {
  getStudents,
  addStudent,
  updateStudent,
  deleteStudent,
  getSchools,
  getClasses,
  getTeachers,
  importStudentsFromCSV,
  getStoryRecords,
  Student,
} from '../../services/mockData';
import {
  Users,
  Plus,
  Edit,
  Trash2,
  QrCode,
  ArrowLeft,
  X,
  Check,
  FileSpreadsheet,
  BookOpen,
  GraduationCap,
} from 'lucide-react';
import { ConfirmDialog } from '../../components/ConfirmDialog';

interface StudentManagementProps {
  schoolId: string | null;
  classId: string | null;
  onBack: () => void;
}

// Age group labels are defined inside component to use translations
const getAgeGroupLabel = (ageGroup: AgeGroup | string, t: any): string => {
  switch (ageGroup) {
    case AgeGroup.TODDLER:
    case '3-5':
      return t.admin.ageGroups.toddler;
    case AgeGroup.EARLY_READER:
    case '5-7':
      return t.admin.ageGroups.earlyReader;
    case AgeGroup.PRE_TEEN:
    case '8-10':
      return t.admin.ageGroups.preTeen;
    default:
      return String(ageGroup || '');
  }
};

export const StudentManagement: React.FC<StudentManagementProps> = ({ schoolId, classId, onBack }) => {
  const { t } = useLanguage();
  const [students, setStudents] = useState<Student[]>(
    getStudents({ schoolId: schoolId || undefined, classId: classId || undefined })
  );
  const schools = useMemo(() => getSchools(), []);
  const allClasses = useMemo(() => getClasses(), []);
  const allTeachers = useMemo(() => getTeachers(), []);
  const [selectedSchool, setSelectedSchool] = useState<string>(schoolId || '');
  const [selectedClass, setSelectedClass] = useState<string>(classId || '');
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [newStudent, setNewStudent] = useState({
    name: '',
    ageGroup: AgeGroup.TODDLER,
    teacherId: '',
  });
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [showQR, setShowQR] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const schoolClasses = useMemo(() =>
    selectedSchool ? allClasses.filter(c => c.schoolId === selectedSchool) : allClasses,
  [selectedSchool, allClasses]);

  const classTeachers = useMemo(() => {
    if (selectedClass) {
      return allTeachers.filter(t => t.classIds.includes(selectedClass));
    }
    if (selectedSchool) {
      return allTeachers.filter(t => t.schoolId === selectedSchool);
    }
    return allTeachers;
  }, [selectedSchool, selectedClass, allTeachers]);

  const refreshStudents = () => {
    setStudents(getStudents({
      schoolId: selectedSchool || undefined,
      classId: selectedClass || undefined
    }));
  };

  const handleSchoolChange = (newSchoolId: string) => {
    setSelectedSchool(newSchoolId);
    setSelectedClass('');
    setStudents(getStudents({ schoolId: newSchoolId || undefined }));
  };

  const handleClassChange = (newClassId: string) => {
    setSelectedClass(newClassId);
    setStudents(getStudents({
      schoolId: selectedSchool || undefined,
      classId: newClassId || undefined
    }));
  };

  const handleAdd = () => {
    if (newStudent.name.trim() && selectedSchool && selectedClass) {
      addStudent({
        schoolId: selectedSchool,
        classId: selectedClass,
        teacherId: newStudent.teacherId || classTeachers[0]?.id || '',
        name: newStudent.name.trim(),
        ageGroup: newStudent.ageGroup,
      });
      setNewStudent({ name: '', ageGroup: AgeGroup.TODDLER, teacherId: '' });
      setIsAdding(false);
      refreshStudents();
    }
  };

  const handleUpdate = (id: string, updates: Partial<Student>) => {
    updateStudent(id, updates);
    setEditingId(null);
    refreshStudents();
  };

  const handleDelete = (id: string) => {
    deleteStudent(id);
    setDeleteConfirm(null);
    refreshStudents();
  };

  const handleImportCSV = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && selectedSchool && selectedClass) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const csvContent = event.target?.result as string;
        const teacherId = classTeachers[0]?.id || '';
        importStudentsFromCSV(csvContent, selectedSchool, selectedClass, teacherId);
        refreshStudents();
      };
      reader.readAsText(file);
    }
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const getStudentStoryCount = (studentId: string) => {
    return getStoryRecords({ studentId }).length;
  };

  return (
    <div className="p-8">
      <div className="flex items-center gap-4 mb-6">
        <Button variant="outline" size="sm" onClick={onBack} icon={<ArrowLeft />}>
          {t.back}
        </Button>
        <h1 className="text-2xl font-extrabold text-gray-800 flex items-center gap-3">
          <Users className="text-kid-pink" /> {t.admin.students}
        </h1>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-2xl border-4 border-gray-100 p-4 mb-6 flex flex-wrap items-center gap-4">
        <div className="flex items-center gap-2">
          <span className="font-bold text-gray-500">{t.admin.schools}:</span>
          <select
            value={selectedSchool}
            onChange={(e) => handleSchoolChange(e.target.value)}
            className="px-4 py-2 border-2 border-gray-200 rounded-xl focus:border-kid-blue outline-none"
          >
            <option value="">-- {t.admin.all} --</option>
            {schools.map(school => (
              <option key={school.id} value={school.id}>{school.name}</option>
            ))}
          </select>
        </div>

        <div className="flex items-center gap-2">
          <span className="font-bold text-gray-500">{t.admin.classes}:</span>
          <select
            value={selectedClass}
            onChange={(e) => handleClassChange(e.target.value)}
            className="px-4 py-2 border-2 border-gray-200 rounded-xl focus:border-kid-blue outline-none"
            disabled={!selectedSchool}
          >
            <option value="">-- {t.admin.all} --</option>
            {schoolClasses.map(cls => (
              <option key={cls.id} value={cls.id}>{cls.name}</option>
            ))}
          </select>
        </div>

        {selectedSchool && selectedClass && (
          <>
            <input
              ref={fileInputRef}
              type="file"
              accept=".csv"
              onChange={handleImportCSV}
              className="hidden"
            />
            <Button variant="outline" onClick={() => fileInputRef.current?.click()} icon={<FileSpreadsheet />}>
              {t.admin.importCSV}
            </Button>
            <Button variant="primary" onClick={() => setIsAdding(true)} icon={<Plus />}>
              {t.admin.addStudent}
            </Button>
          </>
        )}
      </div>

      {/* Delete Confirmation */}
      <ConfirmDialog
        isOpen={!!deleteConfirm}
        title={t.delete}
        message={t.confirm + '?'}
        confirmLabel={t.delete}
        cancelLabel={t.cancel}
        onConfirm={() => deleteConfirm && handleDelete(deleteConfirm)}
        onCancel={() => setDeleteConfirm(null)}
        variant="danger"
      />

      {/* QR Code Modal */}
      {showQR && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/50" onClick={() => setShowQR(null)} />
          <div className="relative bg-white rounded-3xl p-8 shadow-2xl max-w-sm w-full text-center">
            <button onClick={() => setShowQR(null)} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600">
              <X size={24} />
            </button>
            <h3 className="text-xl font-bold mb-4">{t.admin.generateQR}</h3>
            <div className="w-48 h-48 mx-auto bg-gray-100 rounded-2xl flex items-center justify-center mb-4">
              <QrCode size={120} className="text-gray-400" />
            </div>
            <p className="text-sm text-gray-500">{t.admin.studentId}: {showQR}</p>
          </div>
        </div>
      )}

      {/* Add Form */}
      {isAdding && selectedSchool && selectedClass && (
        <div className="bg-white rounded-2xl border-4 border-kid-pink p-6 mb-6">
          <h3 className="font-bold text-lg mb-4">{t.admin.addStudent}</h3>
          <div className="grid grid-cols-3 gap-4 mb-4">
            <input
              type="text"
              placeholder={t.admin.studentName}
              value={newStudent.name}
              onChange={(e) => setNewStudent({ ...newStudent, name: e.target.value })}
              className="px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-kid-pink outline-none"
            />
            <select
              value={newStudent.ageGroup}
              onChange={(e) => setNewStudent({ ...newStudent, ageGroup: e.target.value as AgeGroup })}
              className="px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-kid-pink outline-none"
            >
              {Object.values(AgeGroup).map(ag => (
                <option key={ag} value={ag}>{getAgeGroupLabel(ag, t)}</option>
              ))}
            </select>
            <select
              value={newStudent.teacherId}
              onChange={(e) => setNewStudent({ ...newStudent, teacherId: e.target.value })}
              className="px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-kid-pink outline-none"
            >
              <option value="">-- {t.admin.selectTeacher} --</option>
              {classTeachers.map(teacher => (
                <option key={teacher.id} value={teacher.id}>{teacher.name}</option>
              ))}
            </select>
          </div>
          <div className="flex gap-3">
            <Button variant="primary" onClick={handleAdd} icon={<Check />}>{t.confirm}</Button>
            <Button variant="outline" onClick={() => { setIsAdding(false); setNewStudent({ name: '', ageGroup: AgeGroup.TODDLER, teacherId: '' }); }} icon={<X />}>{t.cancel}</Button>
          </div>
        </div>
      )}

      {/* Students Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {students.map(student => {
          const cls = allClasses.find(c => c.id === student.classId);
          const teacher = allTeachers.find(t => t.id === student.teacherId);
          const storyCount = getStudentStoryCount(student.id);
          const isEditing = editingId === student.id;
          const ageLabel = getAgeGroupLabel(student.ageGroup, t);

          return (
            <div
              key={student.id}
              className="bg-white rounded-2xl border-4 border-gray-100 p-4 hover:border-gray-200 transition-colors"
            >
              {isEditing ? (
                <div className="space-y-3">
                  <input
                    type="text"
                    defaultValue={student.name}
                    onBlur={(e) => handleUpdate(student.id, { name: e.target.value })}
                    className="w-full px-3 py-2 border-2 border-kid-pink rounded-xl font-bold"
                    autoFocus
                  />
                  <select
                    defaultValue={student.ageGroup}
                    onChange={(e) => handleUpdate(student.id, { ageGroup: e.target.value as AgeGroup })}
                    className="w-full px-3 py-2 border-2 border-gray-200 rounded-xl"
                  >
                    {Object.values(AgeGroup).map(ag => (
                      <option key={ag} value={ag}>{getAgeGroupLabel(ag, t)}</option>
                    ))}
                  </select>
                  <Button variant="primary" size="sm" onClick={() => setEditingId(null)} icon={<Check />}>{t.confirm}</Button>
                </div>
              ) : (
                <>
                  <div className="flex items-start justify-between mb-2">
                    <div className="w-12 h-12 bg-kid-pink/20 rounded-full flex items-center justify-center text-2xl">
                      {student.name.slice(0, 1)}
                    </div>
                    <div className="flex gap-1">
                      <button
                        onClick={() => setShowQR(student.id)}
                        className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400"
                        title={t.admin.generateQR}
                      >
                        <QrCode size={14} />
                      </button>
                      <button
                        onClick={() => setEditingId(student.id)}
                        className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400"
                      >
                        <Edit size={14} />
                      </button>
                      <button
                        onClick={() => setDeleteConfirm(student.id)}
                        className="p-1.5 rounded-lg hover:bg-red-50 text-gray-400 hover:text-red-500"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </div>

                  <h3 className="font-bold text-gray-800 mb-1">{student.name}</h3>
                  <p className="text-xs text-gray-400 mb-2">{ageLabel}</p>

                  {cls && (
                    <div className="flex items-center gap-1 text-xs text-kid-blue mb-1">
                      <GraduationCap size={12} /> {cls.name}
                    </div>
                  )}

                  <div className="flex items-center gap-1 text-xs text-kid-purple">
                    <BookOpen size={12} /> {storyCount} {t.admin.books}
                  </div>
                </>
              )}
            </div>
          );
        })}

        {students.length === 0 && (
          <div className="col-span-full text-center py-12 text-gray-400">
            <Users size={48} className="mx-auto mb-4 opacity-50" />
            <p>{selectedClass ? t.admin.noStudents : t.admin.selectClass}</p>
          </div>
        )}
      </div>
    </div>
  );
};
