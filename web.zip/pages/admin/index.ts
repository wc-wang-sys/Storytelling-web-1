export { AdminDashboard } from './AdminDashboard';
export { SchoolManagement } from './SchoolManagement';
export { ClassManagement } from './ClassManagement';
export { TeacherManagement } from './TeacherManagement';
export { StudentManagement } from './StudentManagement';
export { BookCollection } from './BookCollection';
