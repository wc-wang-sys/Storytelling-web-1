import React, { useState, useMemo } from 'react';
import { Button } from '../../components/Button';
import { useLanguage } from '../../contexts/LanguageContext';
import {
  getClasses,
  addClass,
  updateClass,
  deleteClass,
  getSchools,
  getClassStats,
  Class,
} from '../../services/mockData';
import {
  GraduationCap,
  Plus,
  Edit,
  Trash2,
  ChevronRight,
  ArrowLeft,
  X,
  Check,
  Users,
  BookOpen,
} from 'lucide-react';
import { ConfirmDialog } from '../../components/ConfirmDialog';

interface ClassManagementProps {
  schoolId: string | null;
  onSelectClass: (classId: string) => void;
  onBack: () => void;
}

const GRADES: Array<'K1' | 'K2' | 'K3'> = ['K1', 'K2', 'K3'];

export const ClassManagement: React.FC<ClassManagementProps> = ({ schoolId, onSelectClass, onBack }) => {
  const { t } = useLanguage();
  const [classes, setClasses] = useState<Class[]>(getClasses(schoolId || undefined));
  const schools = useMemo(() => getSchools(), []);
  const [selectedSchool, setSelectedSchool] = useState<string>(schoolId || '');
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [newClass, setNewClass] = useState({ name: '', grade: 'K1' as const });
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);

  const refreshClasses = () => setClasses(getClasses(selectedSchool || undefined));

  const handleSchoolChange = (newSchoolId: string) => {
    setSelectedSchool(newSchoolId);
    setClasses(getClasses(newSchoolId || undefined));
  };

  const handleAdd = () => {
    if (newClass.name.trim() && selectedSchool) {
      addClass({
        schoolId: selectedSchool,
        name: newClass.name.trim(),
        grade: newClass.grade,
      });
      setNewClass({ name: '', grade: 'K1' });
      setIsAdding(false);
      refreshClasses();
    }
  };

  const handleUpdate = (id: string, updates: Partial<Class>) => {
    updateClass(id, updates);
    setEditingId(null);
    refreshClasses();
  };

  const handleDelete = (id: string) => {
    deleteClass(id);
    setDeleteConfirm(null);
    refreshClasses();
  };

  const currentSchool = schools.find(s => s.id === selectedSchool);

  return (
    <div className="p-8">
      <div className="flex items-center gap-4 mb-6">
        <Button variant="outline" size="sm" onClick={onBack} icon={<ArrowLeft />}>
          {t.back}
        </Button>
        <h1 className="text-2xl font-extrabold text-gray-800 flex items-center gap-3">
          <GraduationCap className="text-kid-blue" /> {t.admin.classes}
        </h1>
      </div>

      {/* School Filter */}
      <div className="bg-white rounded-2xl border-4 border-gray-100 p-4 mb-6 flex items-center gap-4">
        <span className="font-bold text-gray-500">{t.admin.schools}:</span>
        <select
          value={selectedSchool}
          onChange={(e) => handleSchoolChange(e.target.value)}
          className="flex-1 px-4 py-2 border-2 border-gray-200 rounded-xl focus:border-kid-blue outline-none"
        >
          <option value="">-- {t.admin.allSchools} --</option>
          {schools.map(school => (
            <option key={school.id} value={school.id}>{school.name}</option>
          ))}
        </select>
        {selectedSchool && (
          <Button variant="primary" onClick={() => setIsAdding(true)} icon={<Plus />}>
            {t.admin.addClass}
          </Button>
        )}
      </div>

      {/* Delete Confirmation */}
      <ConfirmDialog
        isOpen={!!deleteConfirm}
        title={t.delete}
        message={t.confirm + '?'}
        confirmLabel={t.delete}
        cancelLabel={t.cancel}
        onConfirm={() => deleteConfirm && handleDelete(deleteConfirm)}
        onCancel={() => setDeleteConfirm(null)}
        variant="danger"
      />

      {/* Add Form */}
      {isAdding && selectedSchool && (
        <div className="bg-white rounded-2xl border-4 border-kid-blue p-6 mb-6">
          <h3 className="font-bold text-lg mb-4">{t.admin.addClass}</h3>
          <div className="grid grid-cols-3 gap-4 mb-4">
            <input
              type="text"
              placeholder={t.admin.className}
              value={newClass.name}
              onChange={(e) => setNewClass({ ...newClass, name: e.target.value })}
              className="px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-kid-blue outline-none"
            />
            <select
              value={newClass.grade}
              onChange={(e) => setNewClass({ ...newClass, grade: e.target.value as 'K1' | 'K2' | 'K3' })}
              className="px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-kid-blue outline-none"
            >
              {GRADES.map(grade => (
                <option key={grade} value={grade}>{grade}</option>
              ))}
            </select>
            <div className="flex gap-3">
              <Button variant="primary" onClick={handleAdd} icon={<Check />}>{t.confirm}</Button>
              <Button variant="outline" onClick={() => { setIsAdding(false); setNewClass({ name: '', grade: 'K1' }); }} icon={<X />}>{t.cancel}</Button>
            </div>
          </div>
        </div>
      )}

      {/* Classes Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {classes.map(cls => {
          const stats = getClassStats(cls.id);
          const school = schools.find(s => s.id === cls.schoolId);
          const isEditing = editingId === cls.id;

          return (
            <div
              key={cls.id}
              className="bg-white rounded-2xl border-4 border-gray-100 p-6 hover:border-gray-200 transition-colors"
            >
              {isEditing ? (
                <div className="space-y-3">
                  <input
                    type="text"
                    defaultValue={cls.name}
                    onBlur={(e) => handleUpdate(cls.id, { name: e.target.value })}
                    className="w-full px-3 py-2 border-2 border-kid-blue rounded-xl font-bold"
                    autoFocus
                  />
                  <select
                    defaultValue={cls.grade}
                    onChange={(e) => handleUpdate(cls.id, { grade: e.target.value as 'K1' | 'K2' | 'K3' })}
                    className="w-full px-3 py-2 border-2 border-gray-200 rounded-xl"
                  >
                    {GRADES.map(grade => (
                      <option key={grade} value={grade}>{grade}</option>
                    ))}
                  </select>
                  <Button variant="primary" size="sm" onClick={() => setEditingId(null)} icon={<Check />}>{t.confirm}</Button>
                </div>
              ) : (
                <>
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <span className={`inline-block px-3 py-1 rounded-full text-sm font-bold mb-2 ${
                        cls.grade === 'K1' ? 'bg-kid-green/20 text-kid-green' :
                        cls.grade === 'K2' ? 'bg-kid-blue/20 text-kid-blue' :
                        'bg-kid-purple/20 text-kid-purple'
                      }`}>
                        {cls.grade}
                      </span>
                      <h3 className="text-lg font-bold text-gray-800">{cls.name}</h3>
                      {!selectedSchool && school && (
                        <p className="text-xs text-gray-400">{school.name}</p>
                      )}
                    </div>
                    <div className="flex gap-1">
                      <button
                        onClick={() => setEditingId(cls.id)}
                        className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400"
                      >
                        <Edit size={16} />
                      </button>
                      <button
                        onClick={() => setDeleteConfirm(cls.id)}
                        className="p-1.5 rounded-lg hover:bg-red-50 text-gray-400 hover:text-red-500"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>

                  <div className="flex gap-3 text-sm mb-4">
                    <span className="flex items-center gap-1 text-kid-pink">
                      <Users size={14} /> {stats.studentCount}
                    </span>
                    <span className="flex items-center gap-1 text-kid-purple">
                      <BookOpen size={14} /> {stats.storyCount}
                    </span>
                  </div>

                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onSelectClass(cls.id)}
                    className="w-full"
                  >
                    {t.admin.students} <ChevronRight size={16} className="ml-1" />
                  </Button>
                </>
              )}
            </div>
          );
        })}

        {classes.length === 0 && (
          <div className="col-span-full text-center py-12 text-gray-400">
            <GraduationCap size={48} className="mx-auto mb-4 opacity-50" />
            <p>{selectedSchool ? t.admin.noClasses : t.admin.selectSchool}</p>
          </div>
        )}
      </div>
    </div>
  );
};
