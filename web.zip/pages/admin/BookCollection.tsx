import React, { useState, useMemo } from 'react';
import { Button } from '../../components/Button';
import { useLanguage } from '../../contexts/LanguageContext';
import {
  getStoryRecords,
  getSchools,
  getClasses,
  StoryRecord,
} from '../../services/mockData';
import {
  BookOpen,
  ArrowLeft,
  Search,
  Calendar,
  User,
  GraduationCap,
} from 'lucide-react';

interface BookCollectionProps {
  schoolId: string | null;
  classId: string | null;
  onBack: () => void;
}

export const BookCollection: React.FC<BookCollectionProps> = ({ schoolId, classId, onBack }) => {
  const { t } = useLanguage();
  const schools = useMemo(() => getSchools(), []);
  const allClasses = useMemo(() => getClasses(), []);
  const [selectedSchool, setSelectedSchool] = useState<string>(schoolId || '');
  const [selectedClass, setSelectedClass] = useState<string>(classId || '');
  const [searchQuery, setSearchQuery] = useState('');

  const schoolClasses = useMemo(() =>
    selectedSchool ? allClasses.filter(c => c.schoolId === selectedSchool) : allClasses,
  [selectedSchool, allClasses]);

  const storyRecords = useMemo(() => {
    let records = getStoryRecords({
      schoolId: selectedSchool || undefined,
      classId: selectedClass || undefined,
    });

    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      records = records.filter(r =>
        r.title.toLowerCase().includes(query) ||
        r.studentName.toLowerCase().includes(query)
      );
    }

    return records;
  }, [selectedSchool, selectedClass, searchQuery]);

  const handleSchoolChange = (newSchoolId: string) => {
    setSelectedSchool(newSchoolId);
    setSelectedClass('');
  };

  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleDateString();
  };

  return (
    <div className="p-8">
      <div className="flex items-center gap-4 mb-6">
        <Button variant="outline" size="sm" onClick={onBack} icon={<ArrowLeft />}>
          {t.back}
        </Button>
        <h1 className="text-2xl font-extrabold text-gray-800 flex items-center gap-3">
          <BookOpen className="text-kid-purple" /> {t.admin.books}
        </h1>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-2xl border-4 border-gray-100 p-4 mb-6 flex flex-wrap items-center gap-4">
        <div className="flex items-center gap-2">
          <span className="font-bold text-gray-500">{t.admin.schools}:</span>
          <select
            value={selectedSchool}
            onChange={(e) => handleSchoolChange(e.target.value)}
            className="px-4 py-2 border-2 border-gray-200 rounded-xl focus:border-kid-blue outline-none"
          >
            <option value="">-- {t.admin.all} --</option>
            {schools.map(school => (
              <option key={school.id} value={school.id}>{school.name}</option>
            ))}
          </select>
        </div>

        <div className="flex items-center gap-2">
          <span className="font-bold text-gray-500">{t.admin.classes}:</span>
          <select
            value={selectedClass}
            onChange={(e) => setSelectedClass(e.target.value)}
            className="px-4 py-2 border-2 border-gray-200 rounded-xl focus:border-kid-blue outline-none"
          >
            <option value="">-- {t.admin.all} --</option>
            {schoolClasses.map(cls => (
              <option key={cls.id} value={cls.id}>{cls.name}</option>
            ))}
          </select>
        </div>

        <div className="flex-1 relative">
          <Search size={20} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder={t.admin.searchStories}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-4 py-2 border-2 border-gray-200 rounded-xl focus:border-kid-blue outline-none"
          />
        </div>
      </div>

      {/* Stories Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-6">
        {storyRecords.map(record => {
          const cls = allClasses.find(c => c.id === record.classId);
          const school = schools.find(s => s.id === record.schoolId);

          return (
            <div
              key={record.id}
              className="bg-white rounded-2xl border-4 border-gray-100 overflow-hidden hover:border-kid-purple hover:shadow-lg transition-all group"
            >
              <div className="aspect-square relative overflow-hidden bg-gray-100">
                <img
                  src={record.coverImage}
                  alt={record.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-4">
                  <Button variant="primary" size="sm" className="w-full">
                    {t.library.read}
                  </Button>
                </div>
              </div>

              <div className="p-4">
                <h3 className="font-bold text-gray-800 truncate mb-2" title={record.title}>
                  {record.title}
                </h3>

                <div className="space-y-1 text-xs text-gray-500">
                  <div className="flex items-center gap-1">
                    <User size={12} /> {record.studentName}
                  </div>
                  {cls && (
                    <div className="flex items-center gap-1">
                      <GraduationCap size={12} /> {cls.name}
                    </div>
                  )}
                  <div className="flex items-center gap-1">
                    <Calendar size={12} /> {formatDate(record.createdAt)}
                  </div>
                </div>
              </div>
            </div>
          );
        })}

        {storyRecords.length === 0 && (
          <div className="col-span-full text-center py-12 text-gray-400">
            <BookOpen size={48} className="mx-auto mb-4 opacity-50" />
            <p>{t.admin.noStories}</p>
          </div>
        )}
      </div>

      {/* Stats Summary */}
      <div className="mt-8 text-center text-gray-500">
        <p className="font-bold">{storyRecords.length} {t.admin.books}</p>
      </div>
    </div>
  );
};
