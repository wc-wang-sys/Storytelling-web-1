import React, { useState, useMemo, useRef } from 'react';
import { Button } from '../../components/Button';
import { useLanguage } from '../../contexts/LanguageContext';
import {
  getTeachers,
  addTeacher,
  updateTeacher,
  deleteTeacher,
  getSchools,
  getClasses,
  importTeachersFromCSV,
  Teacher,
} from '../../services/mockData';
import {
  Users,
  Plus,
  Edit,
  Trash2,
  QrCode,
  ArrowLeft,
  X,
  Check,
  FileSpreadsheet,
  Mail,
  GraduationCap,
} from 'lucide-react';
import { ConfirmDialog } from '../../components/ConfirmDialog';

interface TeacherManagementProps {
  schoolId: string | null;
  onBack: () => void;
}

export const TeacherManagement: React.FC<TeacherManagementProps> = ({ schoolId, onBack }) => {
  const { t } = useLanguage();
  const [teachers, setTeachers] = useState<Teacher[]>(getTeachers(schoolId || undefined));
  const schools = useMemo(() => getSchools(), []);
  const allClasses = useMemo(() => getClasses(), []);
  const [selectedSchool, setSelectedSchool] = useState<string>(schoolId || '');
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [newTeacher, setNewTeacher] = useState({ name: '', email: '', classIds: [] as string[] });
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [showQR, setShowQR] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const schoolClasses = useMemo(() =>
    selectedSchool ? allClasses.filter(c => c.schoolId === selectedSchool) : [],
  [selectedSchool, allClasses]);

  const refreshTeachers = () => setTeachers(getTeachers(selectedSchool || undefined));

  const handleSchoolChange = (newSchoolId: string) => {
    setSelectedSchool(newSchoolId);
    setTeachers(getTeachers(newSchoolId || undefined));
  };

  const handleAdd = () => {
    if (newTeacher.name.trim() && selectedSchool) {
      addTeacher({
        schoolId: selectedSchool,
        name: newTeacher.name.trim(),
        email: newTeacher.email.trim(),
        classIds: newTeacher.classIds,
      });
      setNewTeacher({ name: '', email: '', classIds: [] });
      setIsAdding(false);
      refreshTeachers();
    }
  };

  const handleUpdate = (id: string, updates: Partial<Teacher>) => {
    updateTeacher(id, updates);
    setEditingId(null);
    refreshTeachers();
  };

  const handleDelete = (id: string) => {
    deleteTeacher(id);
    setDeleteConfirm(null);
    refreshTeachers();
  };

  const handleImportCSV = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && selectedSchool) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const csvContent = event.target?.result as string;
        importTeachersFromCSV(csvContent, selectedSchool);
        refreshTeachers();
      };
      reader.readAsText(file);
    }
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const toggleClassId = (classId: string) => {
    setNewTeacher(prev => ({
      ...prev,
      classIds: prev.classIds.includes(classId)
        ? prev.classIds.filter(id => id !== classId)
        : [...prev.classIds, classId]
    }));
  };

  return (
    <div className="p-8">
      <div className="flex items-center gap-4 mb-6">
        <Button variant="outline" size="sm" onClick={onBack} icon={<ArrowLeft />}>
          {t.back}
        </Button>
        <h1 className="text-2xl font-extrabold text-gray-800 flex items-center gap-3">
          <Users className="text-kid-green" /> {t.admin.teachers}
        </h1>
      </div>

      {/* School Filter */}
      <div className="bg-white rounded-2xl border-4 border-gray-100 p-4 mb-6 flex items-center gap-4">
        <span className="font-bold text-gray-500">{t.admin.schools}:</span>
        <select
          value={selectedSchool}
          onChange={(e) => handleSchoolChange(e.target.value)}
          className="flex-1 px-4 py-2 border-2 border-gray-200 rounded-xl focus:border-kid-blue outline-none"
        >
          <option value="">-- {t.admin.allSchools} --</option>
          {schools.map(school => (
            <option key={school.id} value={school.id}>{school.name}</option>
          ))}
        </select>
        {selectedSchool && (
          <>
            <input
              ref={fileInputRef}
              type="file"
              accept=".csv"
              onChange={handleImportCSV}
              className="hidden"
            />
            <Button variant="outline" onClick={() => fileInputRef.current?.click()} icon={<FileSpreadsheet />}>
              {t.admin.importCSV}
            </Button>
            <Button variant="primary" onClick={() => setIsAdding(true)} icon={<Plus />}>
              {t.admin.addTeacher}
            </Button>
          </>
        )}
      </div>

      {/* Delete Confirmation */}
      <ConfirmDialog
        isOpen={!!deleteConfirm}
        title={t.delete}
        message={t.confirm + '?'}
        confirmLabel={t.delete}
        cancelLabel={t.cancel}
        onConfirm={() => deleteConfirm && handleDelete(deleteConfirm)}
        onCancel={() => setDeleteConfirm(null)}
        variant="danger"
      />

      {/* QR Code Modal */}
      {showQR && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/50" onClick={() => setShowQR(null)} />
          <div className="relative bg-white rounded-3xl p-8 shadow-2xl max-w-sm w-full text-center">
            <button onClick={() => setShowQR(null)} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600">
              <X size={24} />
            </button>
            <h3 className="text-xl font-bold mb-4">{t.admin.generateQR}</h3>
            <div className="w-48 h-48 mx-auto bg-gray-100 rounded-2xl flex items-center justify-center mb-4">
              <QrCode size={120} className="text-gray-400" />
            </div>
            <p className="text-sm text-gray-500">{t.admin.teacherId}: {showQR}</p>
          </div>
        </div>
      )}

      {/* Add Form */}
      {isAdding && selectedSchool && (
        <div className="bg-white rounded-2xl border-4 border-kid-green p-6 mb-6">
          <h3 className="font-bold text-lg mb-4">{t.admin.addTeacher}</h3>
          <div className="grid grid-cols-2 gap-4 mb-4">
            <input
              type="text"
              placeholder={t.admin.teacherName}
              value={newTeacher.name}
              onChange={(e) => setNewTeacher({ ...newTeacher, name: e.target.value })}
              className="px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-kid-green outline-none"
            />
            <input
              type="email"
              placeholder={t.admin.email}
              value={newTeacher.email}
              onChange={(e) => setNewTeacher({ ...newTeacher, email: e.target.value })}
              className="px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-kid-green outline-none"
            />
          </div>

          {schoolClasses.length > 0 && (
            <div className="mb-4">
              <label className="block font-bold text-gray-500 mb-2">{t.admin.classes}:</label>
              <div className="flex flex-wrap gap-2">
                {schoolClasses.map(cls => (
                  <button
                    key={cls.id}
                    onClick={() => toggleClassId(cls.id)}
                    className={`px-3 py-2 rounded-xl text-sm font-bold transition-colors ${
                      newTeacher.classIds.includes(cls.id)
                        ? 'bg-kid-green text-white'
                        : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                    }`}
                  >
                    {cls.name}
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="flex gap-3">
            <Button variant="primary" onClick={handleAdd} icon={<Check />}>{t.confirm}</Button>
            <Button variant="outline" onClick={() => { setIsAdding(false); setNewTeacher({ name: '', email: '', classIds: [] }); }} icon={<X />}>{t.cancel}</Button>
          </div>
        </div>
      )}

      {/* Teachers List */}
      <div className="space-y-4">
        {teachers.map(teacher => {
          const school = schools.find(s => s.id === teacher.schoolId);
          const teacherClasses = allClasses.filter(c => teacher.classIds.includes(c.id));
          const isEditing = editingId === teacher.id;

          return (
            <div
              key={teacher.id}
              className="bg-white rounded-2xl border-4 border-gray-100 p-6 hover:border-gray-200 transition-colors"
            >
              {isEditing ? (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <input
                      type="text"
                      defaultValue={teacher.name}
                      onBlur={(e) => handleUpdate(teacher.id, { name: e.target.value })}
                      className="px-4 py-2 border-2 border-kid-green rounded-xl font-bold"
                      autoFocus
                    />
                    <input
                      type="email"
                      defaultValue={teacher.email}
                      onBlur={(e) => handleUpdate(teacher.id, { email: e.target.value })}
                      className="px-4 py-2 border-2 border-gray-200 rounded-xl"
                    />
                  </div>
                  <Button variant="primary" size="sm" onClick={() => setEditingId(null)} icon={<Check />}>{t.confirm}</Button>
                </div>
              ) : (
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-gray-800 mb-1">{teacher.name}</h3>
                    <div className="flex items-center gap-4 text-sm text-gray-500 mb-2">
                      <span className="flex items-center gap-1">
                        <Mail size={14} /> {teacher.email || t.admin.noEmail}
                      </span>
                      {!selectedSchool && school && (
                        <span>{school.name}</span>
                      )}
                    </div>
                    {teacherClasses.length > 0 && (
                      <div className="flex flex-wrap gap-2">
                        {teacherClasses.map(cls => (
                          <span
                            key={cls.id}
                            className="inline-flex items-center gap-1 px-2 py-1 bg-kid-blue/10 text-kid-blue text-xs font-bold rounded-lg"
                          >
                            <GraduationCap size={12} /> {cls.name}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setShowQR(teacher.id)}
                      className="p-2 rounded-xl border-2 border-gray-200 hover:border-gray-300 text-gray-500"
                      title={t.admin.generateQR}
                    >
                      <QrCode size={20} />
                    </button>
                    <button
                      onClick={() => setEditingId(teacher.id)}
                      className="p-2 rounded-xl border-2 border-gray-200 hover:border-gray-300 text-gray-500"
                    >
                      <Edit size={20} />
                    </button>
                    <button
                      onClick={() => setDeleteConfirm(teacher.id)}
                      className="p-2 rounded-xl border-2 border-gray-200 hover:border-red-300 text-gray-500 hover:text-red-500"
                    >
                      <Trash2 size={20} />
                    </button>
                  </div>
                </div>
              )}
            </div>
          );
        })}

        {teachers.length === 0 && (
          <div className="text-center py-12 text-gray-400">
            <Users size={48} className="mx-auto mb-4 opacity-50" />
            <p>{selectedSchool ? t.admin.noTeachers : t.admin.selectSchool}</p>
          </div>
        )}
      </div>
    </div>
  );
};
