import React, { useState, useMemo } from 'react';
import { Button } from '../../components/Button';
import { useLanguage } from '../../contexts/LanguageContext';
import {
  getSchools,
  addSchool,
  updateSchool,
  deleteSchool,
  getSchoolStats,
  School,
} from '../../services/mockData';
import {
  Building2,
  Plus,
  Edit,
  Trash2,
  QrCode,
  ChevronRight,
  X,
  Check,
  Users,
  BookOpen,
} from 'lucide-react';
import { ConfirmDialog } from '../../components/ConfirmDialog';

interface SchoolManagementProps {
  onSelectSchool: (schoolId: string) => void;
}

export const SchoolManagement: React.FC<SchoolManagementProps> = ({ onSelectSchool }) => {
  const { t } = useLanguage();
  const [schools, setSchools] = useState<School[]>(getSchools());
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [newSchool, setNewSchool] = useState({ name: '', address: '' });
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [showQR, setShowQR] = useState<string | null>(null);

  const refreshSchools = () => setSchools(getSchools());

  const handleAdd = () => {
    if (newSchool.name.trim()) {
      addSchool({ name: newSchool.name.trim(), address: newSchool.address.trim() });
      setNewSchool({ name: '', address: '' });
      setIsAdding(false);
      refreshSchools();
    }
  };

  const handleUpdate = (id: string, updates: Partial<School>) => {
    updateSchool(id, updates);
    setEditingId(null);
    refreshSchools();
  };

  const handleDelete = (id: string) => {
    deleteSchool(id);
    setDeleteConfirm(null);
    refreshSchools();
  };

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-extrabold text-gray-800 flex items-center gap-3">
          <Building2 className="text-kid-purple" /> {t.admin.schools}
        </h1>
        <Button variant="primary" onClick={() => setIsAdding(true)} icon={<Plus />}>
          {t.admin.addSchool}
        </Button>
      </div>

      {/* Delete Confirmation */}
      <ConfirmDialog
        isOpen={!!deleteConfirm}
        title={t.delete}
        message={t.confirm + '?'}
        confirmLabel={t.delete}
        cancelLabel={t.cancel}
        onConfirm={() => deleteConfirm && handleDelete(deleteConfirm)}
        onCancel={() => setDeleteConfirm(null)}
        variant="danger"
      />

      {/* QR Code Modal */}
      {showQR && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/50" onClick={() => setShowQR(null)} />
          <div className="relative bg-white rounded-3xl p-8 shadow-2xl max-w-sm w-full text-center">
            <button onClick={() => setShowQR(null)} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600">
              <X size={24} />
            </button>
            <h3 className="text-xl font-bold mb-4">{t.admin.generateQR}</h3>
            <div className="w-48 h-48 mx-auto bg-gray-100 rounded-2xl flex items-center justify-center mb-4">
              <QrCode size={120} className="text-gray-400" />
            </div>
            <p className="text-sm text-gray-500">ID: {showQR}</p>
          </div>
        </div>
      )}

      {/* Add Form */}
      {isAdding && (
        <div className="bg-white rounded-2xl border-4 border-kid-blue p-6 mb-6">
          <h3 className="font-bold text-lg mb-4">{t.admin.addSchool}</h3>
          <div className="grid grid-cols-2 gap-4 mb-4">
            <input
              type="text"
              placeholder={t.admin.schoolName}
              value={newSchool.name}
              onChange={(e) => setNewSchool({ ...newSchool, name: e.target.value })}
              className="px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-kid-blue outline-none"
            />
            <input
              type="text"
              placeholder={t.admin.address}
              value={newSchool.address}
              onChange={(e) => setNewSchool({ ...newSchool, address: e.target.value })}
              className="px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-kid-blue outline-none"
            />
          </div>
          <div className="flex gap-3">
            <Button variant="primary" onClick={handleAdd} icon={<Check />}>{t.confirm}</Button>
            <Button variant="outline" onClick={() => { setIsAdding(false); setNewSchool({ name: '', address: '' }); }} icon={<X />}>{t.cancel}</Button>
          </div>
        </div>
      )}

      {/* Schools List */}
      <div className="space-y-4">
        {schools.map(school => {
          const stats = getSchoolStats(school.id);
          const isEditing = editingId === school.id;

          return (
            <div
              key={school.id}
              className="bg-white rounded-2xl border-4 border-gray-100 p-6 hover:border-gray-200 transition-colors"
            >
              {isEditing ? (
                <div className="space-y-4">
                  <input
                    type="text"
                    defaultValue={school.name}
                    onBlur={(e) => handleUpdate(school.id, { name: e.target.value })}
                    className="w-full px-4 py-2 border-2 border-kid-blue rounded-xl text-xl font-bold"
                    autoFocus
                  />
                  <input
                    type="text"
                    defaultValue={school.address}
                    onBlur={(e) => handleUpdate(school.id, { address: e.target.value })}
                    className="w-full px-4 py-2 border-2 border-gray-200 rounded-xl"
                  />
                  <Button variant="primary" size="sm" onClick={() => setEditingId(null)} icon={<Check />}>{t.confirm}</Button>
                </div>
              ) : (
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-gray-800 mb-1">{school.name}</h3>
                    <p className="text-gray-500 text-sm mb-3">{school.address}</p>
                    <div className="flex gap-4 text-sm">
                      <span className="flex items-center gap-1 text-kid-green">
                        <Users size={16} /> {stats.teacherCount} {t.admin.teachers}
                      </span>
                      <span className="flex items-center gap-1 text-kid-pink">
                        <Users size={16} /> {stats.studentCount} {t.admin.students}
                      </span>
                      <span className="flex items-center gap-1 text-kid-purple">
                        <BookOpen size={16} /> {stats.storyCount} {t.admin.books}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setShowQR(school.id)}
                      className="p-2 rounded-xl border-2 border-gray-200 hover:border-gray-300 text-gray-500"
                      title={t.admin.generateQR}
                    >
                      <QrCode size={20} />
                    </button>
                    <button
                      onClick={() => setEditingId(school.id)}
                      className="p-2 rounded-xl border-2 border-gray-200 hover:border-gray-300 text-gray-500"
                    >
                      <Edit size={20} />
                    </button>
                    <button
                      onClick={() => setDeleteConfirm(school.id)}
                      className="p-2 rounded-xl border-2 border-gray-200 hover:border-red-300 text-gray-500 hover:text-red-500"
                    >
                      <Trash2 size={20} />
                    </button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => onSelectSchool(school.id)}
                    >
                      {t.admin.classes} <ChevronRight size={16} className="ml-1" />
                    </Button>
                  </div>
                </div>
              )}
            </div>
          );
        })}

        {schools.length === 0 && (
          <div className="text-center py-12 text-gray-400">
            <Building2 size={48} className="mx-auto mb-4 opacity-50" />
            <p>{t.admin.noSchools}</p>
          </div>
        )}
      </div>
    </div>
  );
};
