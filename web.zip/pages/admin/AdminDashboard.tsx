import React, { useState, useMemo } from 'react';
import { Button } from '../../components/Button';
import { useLanguage } from '../../contexts/LanguageContext';
import {
  getSchools,
  getClasses,
  getTeachers,
  getStudents,
  getStoryRecords,
  getSchoolStats,
  School,
  Class,
  Teacher,
  Student,
  StoryRecord,
} from '../../services/mockData';
import {
  Building2,
  Users,
  GraduationCap,
  BookOpen,
  ChevronRight,
  ArrowLeft,
  Plus,
  Search,
  FileSpreadsheet,
  QrCode,
  LayoutDashboard,
} from 'lucide-react';

// Sub-components for different management views
import { SchoolManagement } from './SchoolManagement';
import { ClassManagement } from './ClassManagement';
import { TeacherManagement } from './TeacherManagement';
import { StudentManagement } from './StudentManagement';
import { BookCollection } from './BookCollection';

type AdminView = 'dashboard' | 'schools' | 'classes' | 'teachers' | 'students' | 'books';

interface AdminDashboardProps {
  onExit: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onExit }) => {
  const { t } = useLanguage();
  const [currentView, setCurrentView] = useState<AdminView>('dashboard');
  const [selectedSchoolId, setSelectedSchoolId] = useState<string | null>(null);
  const [selectedClassId, setSelectedClassId] = useState<string | null>(null);

  // Load data
  const schools = useMemo(() => getSchools(), []);
  const classes = useMemo(() => getClasses(selectedSchoolId || undefined), [selectedSchoolId]);
  const teachers = useMemo(() => getTeachers(selectedSchoolId || undefined), [selectedSchoolId]);
  const students = useMemo(() => getStudents({ schoolId: selectedSchoolId || undefined, classId: selectedClassId || undefined }), [selectedSchoolId, selectedClassId]);
  const storyRecords = useMemo(() => getStoryRecords({ schoolId: selectedSchoolId || undefined }), [selectedSchoolId]);

  // Calculate totals
  const totalStats = useMemo(() => ({
    schools: schools.length,
    classes: getClasses().length,
    teachers: getTeachers().length,
    students: getStudents().length,
    stories: getStoryRecords().length,
  }), [schools]);

  const navItems = [
    { id: 'dashboard' as const, icon: LayoutDashboard, label: t.admin.dashboard },
    { id: 'schools' as const, icon: Building2, label: t.admin.schools, count: totalStats.schools },
    { id: 'classes' as const, icon: GraduationCap, label: t.admin.classes, count: totalStats.classes },
    { id: 'teachers' as const, icon: Users, label: t.admin.teachers, count: totalStats.teachers },
    { id: 'students' as const, icon: Users, label: t.admin.students, count: totalStats.students },
    { id: 'books' as const, icon: BookOpen, label: t.admin.books, count: totalStats.stories },
  ];

  const renderMainContent = () => {
    switch (currentView) {
      case 'dashboard':
        return (
          <div className="p-8">
            <h1 className="text-3xl font-extrabold text-gray-800 mb-8">{t.admin.dashboard}</h1>

            {/* Stats Cards */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
              <StatCard
                icon={<Building2 size={32} />}
                label={t.admin.schools}
                value={totalStats.schools}
                color="bg-kid-purple"
                onClick={() => setCurrentView('schools')}
              />
              <StatCard
                icon={<GraduationCap size={32} />}
                label={t.admin.classes}
                value={totalStats.classes}
                color="bg-kid-blue"
                onClick={() => setCurrentView('classes')}
              />
              <StatCard
                icon={<Users size={32} />}
                label={t.admin.teachers}
                value={totalStats.teachers}
                color="bg-kid-green"
                onClick={() => setCurrentView('teachers')}
              />
              <StatCard
                icon={<Users size={32} />}
                label={t.admin.students}
                value={totalStats.students}
                color="bg-kid-pink"
                onClick={() => setCurrentView('students')}
              />
            </div>

            {/* Recent Stories */}
            <div className="bg-white rounded-2xl border-4 border-gray-100 p-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold text-gray-700">{t.admin.books}</h2>
                <Button variant="outline" size="sm" onClick={() => setCurrentView('books')}>
                  {t.admin.viewRecords} <ChevronRight size={16} className="ml-1" />
                </Button>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {storyRecords.slice(0, 4).map(record => (
                  <div key={record.id} className="bg-gray-50 rounded-xl overflow-hidden">
                    <img src={record.coverImage} alt={record.title} className="w-full h-24 object-cover" />
                    <div className="p-3">
                      <p className="font-bold text-sm truncate">{record.title}</p>
                      <p className="text-xs text-gray-500">{record.studentName}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );

      case 'schools':
        return <SchoolManagement onSelectSchool={(id) => { setSelectedSchoolId(id); setCurrentView('classes'); }} />;

      case 'classes':
        return <ClassManagement schoolId={selectedSchoolId} onSelectClass={(id) => { setSelectedClassId(id); setCurrentView('students'); }} onBack={() => { setSelectedSchoolId(null); setCurrentView('schools'); }} />;

      case 'teachers':
        return <TeacherManagement schoolId={selectedSchoolId} onBack={() => setCurrentView('dashboard')} />;

      case 'students':
        return <StudentManagement schoolId={selectedSchoolId} classId={selectedClassId} onBack={() => { setSelectedClassId(null); setCurrentView('classes'); }} />;

      case 'books':
        return <BookCollection schoolId={selectedSchoolId} classId={selectedClassId} onBack={() => setCurrentView('dashboard')} />;

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-gray-200 flex flex-col">
        <div className="p-6 border-b border-gray-100">
          <h1 className="text-xl font-extrabold text-kid-purple flex items-center gap-2">
            <LayoutDashboard /> {t.admin.dashboard}
          </h1>
        </div>

        <nav className="flex-1 p-4 space-y-2">
          {navItems.map(item => (
            <button
              key={item.id}
              onClick={() => setCurrentView(item.id)}
              className={`w-full flex items-center gap-3 p-3 rounded-xl font-bold transition-colors ${
                currentView === item.id
                  ? 'bg-kid-blue text-white'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              <item.icon size={20} />
              <span className="flex-1 text-left">{item.label}</span>
              {item.count !== undefined && (
                <span className={`text-sm px-2 py-0.5 rounded-full ${
                  currentView === item.id ? 'bg-white/20' : 'bg-gray-100'
                }`}>
                  {item.count}
                </span>
              )}
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-gray-100">
          <Button variant="outline" onClick={onExit} icon={<ArrowLeft />} className="w-full">
            {t.back}
          </Button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto">
        {renderMainContent()}
      </main>
    </div>
  );
};

// Stat Card Component
interface StatCardProps {
  icon: React.ReactNode;
  label: string;
  value: number;
  color: string;
  onClick: () => void;
}

const StatCard: React.FC<StatCardProps> = ({ icon, label, value, color, onClick }) => (
  <button
    onClick={onClick}
    className="bg-white rounded-2xl border-4 border-gray-100 p-6 text-left hover:border-gray-200 transition-colors group"
  >
    <div className={`w-14 h-14 ${color} rounded-2xl flex items-center justify-center text-white mb-4 group-hover:scale-110 transition-transform`}>
      {icon}
    </div>
    <p className="text-3xl font-extrabold text-gray-800">{value}</p>
    <p className="text-sm font-bold text-gray-500 uppercase tracking-wide">{label}</p>
  </button>
);
