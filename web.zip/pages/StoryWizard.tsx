import React, { useState, useEffect, useCallback, useRef } from 'react';
import { WizardState, WizardStep, AgeGroup, User, UserRole, Badge, StoryPage } from '../types';
import { Button } from '../components/Button';
import { ProgressBar } from '../components/ProgressBar';
import { BadgeNotification } from '../components/BadgeNotification';
import { generateImage, generateSuggestions, generateMultiplePages } from '../services/geminiService';
import { buildWizardChoiceImagePrompt } from '../services/promptService';
import { SensitiveInputGuidance, getSensitiveInputGuidance, moderateStudentInput } from '../services/contentModeration';
import { Mic, MicOff, Volume2, ArrowLeft, ArrowRight, Wand2, RefreshCw, Star, Edit, Save, Printer, Check } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { getSpeechRecognizer, mapLanguageToSpeech, SpeechStatus } from '../services/speechService';

interface StoryWizardProps {
  user: User;
  onFinish: (storyData: WizardState, action: 'save' | 'edit') => void;
  onCancel: () => void;
}

// Interaction states for the 3-step inactivity flow
type InteractionMode = 'input' | 'options' | 'confirmation';

interface OptionCard {
  label: string;
  imageUrl: string | null;
  loading: boolean;
}

const normalizeVoiceLanguage = (value: string) => value.toLowerCase().replace('_', '-');

const getPlayfulVoice = (language: string): SpeechSynthesisVoice | null => {
  if (!('speechSynthesis' in window)) {
    return null;
  }

  const voices = window.speechSynthesis.getVoices();
  if (voices.length === 0) {
    return null;
  }

  const targetLang = normalizeVoiceLanguage(language);
  const matchingVoices = voices.filter((voice) => normalizeVoiceLanguage(voice.lang).startsWith(targetLang));
  const candidates = matchingVoices.length > 0 ? matchingVoices : voices;

  const preferredKeywords =
    targetLang === 'zh-hk'
      ? ['sin-ji', 'jia-jia', 'female', 'woman', 'girl', 'mei', 'ting']
      : targetLang === 'zh-cn'
        ? ['xiaoxiao', 'xiaoyi', 'tingting', 'female', 'woman', 'girl', 'mei', 'ting']
        : ['ava', 'aria', 'emma', 'samantha', 'karen', 'female', 'woman', 'girl', 'junior'];

  const rankedVoice = [...candidates]
    .map((voice) => {
      const name = voice.name.toLowerCase();
      let score = 0;

      preferredKeywords.forEach((keyword, index) => {
        if (name.includes(keyword)) {
          score += preferredKeywords.length - index;
        }
      });

      if (name.includes('child') || name.includes('kid')) {
        score += 10;
      }

      if (voice.default) {
        score += 1;
      }

      return { voice, score };
    })
    .sort((left, right) => right.score - left.score)[0];

  return rankedVoice?.voice || candidates[0] || null;
};

export const StoryWizard: React.FC<StoryWizardProps> = ({ user, onFinish, onCancel }) => {
  const { t, language } = useLanguage();

  const [state, setState] = useState<WizardState>({
    step: WizardStep.AGE_SELECTION,
    ageGroup: null,
    character: null,
    place: null,
    time: null,
    plotInput: '',
    generatedPages: []
  });

  const [isLoading, setIsLoading] = useState(false);
  const [isModerating, setIsModerating] = useState(false);
  const [inactivityTimer, setInactivityTimer] = useState(0);

  // New Inactivity Flow State
  const [mode, setMode] = useState<InteractionMode>('input');
  const [suggestedOptions, setSuggestedOptions] = useState<OptionCard[]>([]);
  const [autoSelectCandidate, setAutoSelectCandidate] = useState<OptionCard | null>(null);

  // Gamification State
  const [currentPoints, setCurrentPoints] = useState(user.points);
  const [newBadge, setNewBadge] = useState<Badge | null>(null);

  // Speech Recognition State
  const [speechStatus, setSpeechStatus] = useState<SpeechStatus>('idle');
  const [inputValue, setInputValue] = useState('');
  const [moderationGuidance, setModerationGuidance] = useState<SensitiveInputGuidance | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const speechRecognizer = useRef(getSpeechRecognizer());

  // Generation progress for multi-page stories
  const [generationProgress, setGenerationProgress] = useState(0);
  const [totalPages, setTotalPages] = useState(0);

  // Track current step for speech recognition routing
  const stepRef = useRef(state.step);
  stepRef.current = state.step;
  const optionSpeechRequestIdRef = useRef(0);
  const moderationRequestIdRef = useRef(0);
  const isBusy = isLoading || isModerating;

  const stopOptionSpeech = useCallback(() => {
    optionSpeechRequestIdRef.current += 1;
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
  }, []);

  const clearModerationGuidance = useCallback(() => {
    setModerationGuidance(null);
  }, []);

  const showModerationGuidance = useCallback(() => {
    setModerationGuidance(getSensitiveInputGuidance(language));
  }, [language]);

  const validateStudentInput = useCallback(async (value: string) => {
    const trimmedValue = value.trim();
    if (!trimmedValue) {
      clearModerationGuidance();
      return true;
    }

    const requestId = moderationRequestIdRef.current + 1;
    moderationRequestIdRef.current = requestId;
    setIsModerating(true);

    try {
      const result = await moderateStudentInput(trimmedValue);
      if (moderationRequestIdRef.current !== requestId) {
        return false;
      }

      if (result.safe) {
        clearModerationGuidance();
        return true;
      }

      stopOptionSpeech();
      setMode('input');
      setInactivityTimer(0);
      showModerationGuidance();
      return false;
    } finally {
      if (moderationRequestIdRef.current === requestId) {
        setIsModerating(false);
      }
    }
  }, [clearModerationGuidance, showModerationGuidance, stopOptionSpeech]);

  const fillSuggestionInput = useCallback((text: string) => {
    setInputValue(text);
    setMode('input');
    setInactivityTimer(0);
    if (inputRef.current) {
      inputRef.current.value = text;
      inputRef.current.focus();
    }
  }, []);

  const playOptionSpeech = useCallback((text: string) => {
    if (!text) {
      return;
    }

    stopOptionSpeech();

    if (!('speechSynthesis' in window)) {
      fillSuggestionInput(text);
      return;
    }

    const requestId = optionSpeechRequestIdRef.current;
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = mapLanguageToSpeech(language);
    utterance.voice = getPlayfulVoice(utterance.lang);
    utterance.rate = language === 'en' ? 1.06 : 1;
    utterance.pitch = language === 'en' ? 1.22 : 1.35;
    utterance.volume = 1;

    const finalizePreview = () => {
      if (optionSpeechRequestIdRef.current !== requestId) {
        return;
      }

      fillSuggestionInput(text);
    };

    utterance.onend = finalizePreview;
    utterance.onerror = finalizePreview;

    window.speechSynthesis.speak(utterance);
  }, [fillSuggestionInput, language, stopOptionSpeech]);

  // Setup speech recognition
  useEffect(() => {
    const recognizer = speechRecognizer.current;
    recognizer.setLanguage(mapLanguageToSpeech(language));

    recognizer.onStatusChange((status) => {
      setSpeechStatus(status);
    });

    recognizer.onResult((result) => {
      if (stepRef.current === WizardStep.PLOT) {
        setState(prev => ({ ...prev, plotInput: result.transcript }));
      } else {
        setInputValue(result.transcript);
        if (inputRef.current) {
          inputRef.current.value = result.transcript;
        }

        if (result.isFinal) {
          recognizer.stop();
        }
      }
    });

    recognizer.onError((error) => {
      console.error('Speech error:', error);
      alert(error);
    });

    return () => {
      recognizer.stop();
      stopOptionSpeech();
    };
  }, [language, stopOptionSpeech]);

  useEffect(() => {
    if (mode !== 'options') {
      stopOptionSpeech();
    }
  }, [mode, stopOptionSpeech]);

  // Handle microphone button click
  const handleMicClick = () => {
    if (isModerating) {
      return;
    }

    if (speechStatus === 'listening' || speechStatus === 'processing') {
      speechRecognizer.current.stop();
    } else {
      setInputValue('');
      speechRecognizer.current.start();
    }
  };

  const resetInteractiveState = useCallback(() => {
    setInactivityTimer(0);
    setMode('input');
    setSuggestedOptions([]);
    setAutoSelectCandidate(null);
    setInputValue('');
    clearModerationGuidance();
    speechRecognizer.current.stop();
    stopOptionSpeech();
  }, [clearModerationGuidance, stopOptionSpeech]);

  // Main Timer & State Machine Logic
  useEffect(() => {
    // Only run timer for creation steps
    const activeSteps = [WizardStep.CHARACTER, WizardStep.PLACE, WizardStep.TIME];
    if (isBusy || !activeSteps.includes(state.step)) return;

    const interval = setInterval(() => {
      setInactivityTimer(prev => {
        const t = prev + 1;

        // Step 1: 30s -> Show 3 Options
        if (t === 30 && mode === 'input') {
           handleShowOptions();
        }

        // Step 2: 60s (30s after options) -> Show Single Confirmation
        if (t === 60 && mode === 'options') {
           handleShowConfirmation();
        }

        // Step 3: 70s (10s after confirmation) -> Auto Select
        if (t === 70 && mode === 'confirmation') {
           handleAutoSelect();
        }

        return t;
      });
    }, 1000);

    const events = ['mousemove', 'keydown', 'touchstart'];
    const handler = () => {
        // Only reset if we are in input mode or early options mode. 
        // If we are in confirmation, we might want to let the user cancel manually or click.
        // For simplicity, any interaction resets to input unless explicitly handled.
        if (mode === 'input') setInactivityTimer(0);
    };
    
    events.forEach(e => window.addEventListener(e, handler));

    return () => {
      clearInterval(interval);
      events.forEach(e => window.removeEventListener(e, handler));
    };
  }, [state.step, mode, isBusy]);

  // --- Logic Handlers ---

  const getContext = () => {
      if (state.step === WizardStep.PLACE) return 'place';
      if (state.step === WizardStep.TIME) return 'time';
      return 'character';
  }

  const rewindWizardState = (prev: WizardState, targetStep: WizardStep, resetCurrentSelection = false): WizardState => {
      const next: WizardState = { ...prev, step: targetStep };

      switch (targetStep) {
        case WizardStep.AGE_SELECTION:
          return {
            ...next,
            character: null,
            place: null,
            time: null,
            plotInput: '',
            generatedPages: []
          };
        case WizardStep.CHARACTER:
          return {
            ...next,
            character: resetCurrentSelection ? null : prev.character,
            place: null,
            time: null,
            plotInput: '',
            generatedPages: []
          };
        case WizardStep.PLACE:
          return {
            ...next,
            place: resetCurrentSelection ? null : prev.place,
            time: null,
            plotInput: '',
            generatedPages: []
          };
        case WizardStep.TIME:
          return {
            ...next,
            time: resetCurrentSelection ? null : prev.time,
            plotInput: '',
            generatedPages: []
          };
        case WizardStep.PLOT:
          return {
            ...next,
            plotInput: resetCurrentSelection ? '' : prev.plotInput,
            generatedPages: []
          };
        default:
          return next;
      }
  };

  const handlePreviousStep = () => {
      if (state.step === WizardStep.AGE_SELECTION || isBusy) return;

      resetInteractiveState();
      setState(prev => rewindWizardState(prev, (prev.step - 1) as WizardStep));
  };

  const handleResetCurrentStep = () => {
      if (state.step === WizardStep.AGE_SELECTION || state.step === WizardStep.PREVIEW || isBusy) return;

      resetInteractiveState();
      setState(prev => rewindWizardState(prev, prev.step, true));
  };

  const handleShowOptions = async () => {
    setMode('options');
    const context = getContext();
    
    // 1. Get Text Suggestions
    const texts = await generateSuggestions(context, state.ageGroup || AgeGroup.EARLY_READER);
    
    // 2. Initialize options with loading state for images
    const initialOptions = texts.map(t => ({ label: t, imageUrl: null, loading: true }));
    setSuggestedOptions(initialOptions);

    // 3. Generate images for options (in background)
    // We do this one by one to avoid rate limits if possible, or parallel if quota allows.
    // Given the quota error history, we'll try parallel but with a fallback in the service.
    texts.forEach(async (text, index) => {
        try {
            const prompt = await buildWizardChoiceImagePrompt(state.step, text);
            
            const url = await generateImage(prompt);
            
            setSuggestedOptions(prev => {
                const next = [...prev];
                next[index] = { ...next[index], imageUrl: url, loading: false };
                return next;
            });
        } catch (e) {
             setSuggestedOptions(prev => {
                const next = [...prev];
                next[index] = { ...next[index], loading: false }; // Leave image null (placeholder)
                return next;
            });
        }
    });
  };

  const handleShowConfirmation = () => {
    setMode('confirmation');
    // Pick the first option, or a default if empty
    const candidate = suggestedOptions[0] || { label: "A Magical Friend", imageUrl: null, loading: false };
    setAutoSelectCandidate(candidate);
  };

  const handleAutoSelect = () => {
      if (autoSelectCandidate) {
          void handleSelection(autoSelectCandidate.label, autoSelectCandidate.imageUrl || undefined);
      } else {
          void handleSelection('A Magical Friend');
      }
  };

  const handleSelection = async (choice: string, preGeneratedImage?: string) => {
      const trimmedChoice = choice.trim();
      if (!trimmedChoice) {
          return false;
      }

      if (!await validateStudentInput(trimmedChoice)) {
          setInputValue(trimmedChoice);
          if (inputRef.current) {
              inputRef.current.value = trimmedChoice;
              inputRef.current.focus();
          }
          return false;
      }

      resetInteractiveState();
      setIsLoading(true);
      
      try {
        if (state.step === WizardStep.CHARACTER) {
            const prompt = await buildWizardChoiceImagePrompt(WizardStep.CHARACTER, trimmedChoice);
            const img = preGeneratedImage || await generateImage(prompt);
            setState(prev => ({ ...prev, character: { description: trimmedChoice, imageUrl: img } }));
        } else if (state.step === WizardStep.PLACE) {
            const prompt = await buildWizardChoiceImagePrompt(WizardStep.PLACE, trimmedChoice);
            const img = preGeneratedImage || await generateImage(prompt);
            setState(prev => ({ ...prev, place: { description: trimmedChoice, imageUrl: img } }));
        } else if (state.step === WizardStep.TIME) {
            const prompt = await buildWizardChoiceImagePrompt(WizardStep.TIME, trimmedChoice);
            const img = preGeneratedImage || await generateImage(prompt);
            setState(prev => ({ ...prev, time: { description: trimmedChoice, imageUrl: img } }));
        }
        return true;
      } catch (e) {
          console.error(e);
          return false;
      } finally {
        setIsLoading(false);
      }
  };

  const awardPoints = (amount: number) => {
      setCurrentPoints(prev => prev + amount);
  };

  const checkBadges = (step: WizardStep) => {
      let badge: Badge | null = null;
      if (step === WizardStep.CHARACTER) {
          badge = { id: 'char_creator', name: t.badges.characterCreator, icon: '🦁', description: t.badges.characterCreatorDesc };
      } else if (step === WizardStep.PLACE) {
          badge = { id: 'world_builder', name: t.badges.worldBuilder, icon: '🌍', description: t.badges.worldBuilderDesc };
      }

      if (badge) {
          setNewBadge(badge);
      }
  };

  const confirmStep = () => {
      resetInteractiveState();
      awardPoints(10);
      checkBadges(state.step);
      setState(prev => ({ ...prev, step: prev.step + 1 }));
  };

  const generatePage = async () => {
      if (!state.character || !state.place || !state.time) return;
      const trimmedPlotInput = state.plotInput.trim();
      if (trimmedPlotInput && !await validateStudentInput(trimmedPlotInput)) {
          return;
      }

      setIsLoading(true);
      setGenerationProgress(0);

      try {
          const pages = await generateMultiplePages(
              {
                  character: state.character.description,
                  place: state.place.description,
                  time: state.time.description,
                  plot: trimmedPlotInput || t.wizard.onceUponATime
              },
              state.ageGroup!,
              (current, total) => {
                  setGenerationProgress(current);
                  setTotalPages(total);
              }
          );

          const storyPages: StoryPage[] = pages.map(p => ({
              text: p.text,
              imageUrl: p.imageUrl,
              imagePrompt: p.imagePrompt
          }));

          awardPoints(50);
          setNewBadge({ id: 'master_story', name: t.badges.masterStoryteller, icon: '👑', description: t.badges.masterStorytellerDesc });

          setState(prev => ({
              ...prev,
              generatedPages: storyPages,
              step: WizardStep.PREVIEW
          }));
      } catch (e) {
          console.error('Failed to generate story:', e);
      } finally {
          setIsLoading(false);
          setGenerationProgress(0);
      }
  };

  const handleDownload = () => {
      window.print();
  };

  // --- Render Steps ---

  const renderAgeSelection = () => (
    <div className="text-center space-y-8 animate-fade-in">
      <h2 className="text-4xl font-bold text-kid-purple mb-4">{t.wizard.greeting}</h2>
      <h3 className="text-2xl font-bold text-kid-blue">{t.wizard.howOld}</h3>
      <div className="flex flex-col gap-4 max-w-sm mx-auto">
        {Object.values(AgeGroup).map(age => (
          <Button
            key={age}
            size="lg"
            variant="secondary"
            onClick={() => setState(prev => ({ ...prev, ageGroup: age, step: WizardStep.CHARACTER }))}
          >
            {t.wizard.yearsOld.replace('{age}', age)}
          </Button>
        ))}
      </div>
    </div>
  );

  const renderModerationGuidance = () => {
    if (!moderationGuidance) {
      return null;
    }

    return (
      <div className="w-full max-w-xl rounded-3xl border-4 border-amber-200 bg-amber-50 p-5 text-left shadow-sm animate-fade-in">
        <p className="text-lg font-bold text-amber-700">{moderationGuidance.title}</p>
        <p className="mt-2 text-base font-semibold text-amber-700">{moderationGuidance.subtitle}</p>
        <p className="mt-4 text-sm font-bold text-amber-600">{moderationGuidance.intro}</p>
        <div className="mt-2 space-y-1 text-sm text-amber-800">
          {moderationGuidance.suggestions.map((suggestion) => (
            <p key={suggestion}>• {suggestion}</p>
          ))}
        </div>
      </div>
    );
  };

  const renderInputStep = (title: string, value: string | null, field: 'character' | 'place' | 'time', placeholder: string) => {
    const hasValue = state[field] !== null;
    const data = state[field];
    
    const imageUrl = (typeof data === 'object' && data !== null && 'imageUrl' in data) ? data.imageUrl : null;

    return (
      <div className="flex flex-col items-center space-y-6 w-full max-w-4xl mx-auto">
        <h2 className="text-4xl font-bold text-kid-purple">{title}</h2>
        
        {/* Main Visual Area */}
        <div className="w-full relative min-h-[400px] flex flex-col items-center justify-center">
            
            {/* Case 1: Loading */}
            {isLoading && (
               <div className="animate-bounce text-6xl">🎨</div>
            )}

            {/* Case 2: Selected Value Exists */}
            {!isLoading && imageUrl && (
                <div className="w-64 h-64 bg-white rounded-3xl border-4 border-kid-blue overflow-hidden shadow-lg mb-4">
                    <img src={imageUrl} alt="Selected" className="w-full h-full object-cover" />
                </div>
            )}

            {/* Case 3: Inactivity - Options Mode (30s) */}
            {!isLoading && !hasValue && mode === 'options' && (
                <div className="w-full animate-fade-in">
                    <p className="text-xl font-bold text-kid-blue mb-6 text-center">{t.wizard.needHint}</p>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        {suggestedOptions.map((opt, idx) => (
                            <button 
                                key={idx}
                                type="button"
                                onClick={() => playOptionSpeech(opt.label)}
                                disabled={isBusy}
                                className="bg-white p-4 rounded-3xl border-4 border-kid-yellow hover:border-kid-pink hover:scale-105 transition-all shadow-md flex flex-col items-center gap-3"
                            >
                                <div className="w-32 h-32 bg-gray-100 rounded-2xl overflow-hidden flex items-center justify-center">
                                    {opt.loading ? (
                                        <span className="text-2xl animate-spin">⏳</span>
                                    ) : opt.imageUrl ? (
                                        <img src={opt.imageUrl} className="w-full h-full object-cover" />
                                    ) : (
                                        <span className="text-4xl">✨</span>
                                    )}
                                </div>
                                <span className="font-bold text-gray-700">{opt.label}</span>
                            </button>
                        ))}
                    </div>
                </div>
            )}

            {/* Case 4: Inactivity - Confirmation Mode (60s) */}
            {!isLoading && !hasValue && mode === 'confirmation' && autoSelectCandidate && (
                <div className="bg-white p-8 rounded-[3rem] border-8 border-kid-green shadow-2xl animate-bounce-in max-w-md w-full text-center">
                    <h3 className="text-2xl font-bold text-kid-purple mb-4">{t.wizard.howAboutThis}</h3>
                    <div className="w-48 h-48 mx-auto bg-gray-100 rounded-3xl overflow-hidden mb-4 border-4 border-gray-100">
                         {autoSelectCandidate.imageUrl ? (
                            <img src={autoSelectCandidate.imageUrl} className="w-full h-full object-cover" />
                         ) : (
                            <div className="w-full h-full flex items-center justify-center text-6xl">🤔</div>
                         )}
                    </div>
                    <p className="text-xl font-bold text-gray-700 mb-6">{autoSelectCandidate.label}</p>
                    <div className="flex gap-4 justify-center">
                        <Button variant="secondary" onClick={() => setMode('options')}>{t.wizard.noLetMePick}</Button>
                        <Button variant="primary" icon={<Check />} onClick={() => void handleSelection(autoSelectCandidate.label, autoSelectCandidate.imageUrl || undefined)} disabled={isBusy}>
                            {t.wizard.yesOkay}
                        </Button>
                    </div>
                </div>
            )}

            {/* Case 5: Standard Input Mode (0-30s) */}
            {!isLoading && !hasValue && mode === 'input' && (
               <div className="w-full max-w-xl text-center">
                   <div className="w-full h-64 bg-white/50 rounded-3xl border-4 border-dashed border-gray-300 flex items-center justify-center mb-8">
                       <span className="text-gray-400 font-bold text-xl">{t.wizard.ideaAppears}</span>
                   </div>
                   {/* Encouragement text only appears after a few seconds */}
                   {inactivityTimer > 10 && (
                       <p className="text-kid-pink font-bold animate-pulse mb-4">{t.wizard.dontBeShy}</p>
                   )}
               </div>
            )}

        </div>

        {/* Input Controls (Hidden if in strict confirmation mode to reduce clutter, or kept for override) */}
        {!hasValue && mode !== 'confirmation' && (
             <div className="w-full max-w-xl space-y-4">
                <div className="flex gap-2">
                    <input
                        ref={inputRef}
                        type="text"
                        placeholder={placeholder}
                        value={inputValue}
                        disabled={isBusy}
                        className="flex-1 p-4 rounded-2xl border-4 border-gray-300 text-xl focus:border-kid-pink outline-none"
                        onKeyDown={(e) => {
                            if (e.key === 'Enter' && inputValue.trim()) {
                                void handleSelection(inputValue.trim());
                            }
                        }}
                        onChange={(e) => {
                            setInputValue(e.target.value);
                            setInactivityTimer(0);
                            if (moderationGuidance) {
                                clearModerationGuidance();
                            }
                        }}
                    />
                    <Button
                        variant={speechStatus === 'listening' ? 'primary' : 'secondary'}
                        icon={speechStatus === 'listening' ? <MicOff size={24} /> : <Mic size={24} />}
                        onClick={handleMicClick}
                        disabled={isBusy}
                        className={speechStatus === 'listening' ? 'animate-pulse bg-kid-pink' : ''}
                    />
                </div>
                <p className="text-gray-500 text-center">
                    {speechStatus === 'listening' ? (
                      t.voice.listening
                    ) : (
                      <>
                        <span className="hidden md:inline">{t.wizard.typeOrSay}</span>
                        <span className="md:hidden">{t.wizard.typeOrTapNext}</span>
                      </>
                    )}
                </p>
                {isModerating && <p className="text-center font-bold text-kid-blue">{t.loading}</p>}
                {renderModerationGuidance()}
             </div>
        )}

        {/* Confirmation Buttons if value exists */}
        {hasValue && (
            <div className="flex flex-wrap justify-center gap-4">
                <Button variant="outline" icon={<ArrowLeft />} onClick={handlePreviousStep} disabled={isBusy}>
                    {t.previous}
                </Button>
                <Button variant="outline" icon={<RefreshCw />} onClick={handleResetCurrentStep} disabled={isBusy}>
                    {t.wizard.change}
                </Button>
                <Button variant="primary" icon={<ArrowRight />} size="lg" onClick={confirmStep} disabled={isBusy}>
                    {t.next}
                </Button>
            </div>
        )}

        {!hasValue && state.step > WizardStep.AGE_SELECTION && (
            <div className="flex w-full max-w-xl gap-4 md:w-auto md:max-w-none md:justify-center">
                <Button
                  variant="outline"
                  icon={<ArrowLeft />}
                  onClick={handlePreviousStep}
                  disabled={isBusy}
                  className="flex-1 md:flex-none"
                >
                    {t.previous}
                </Button>
                <Button
                  variant="primary"
                  icon={<ArrowRight />}
                  onClick={() => void handleSelection(inputValue.trim())}
                  disabled={isBusy || !inputValue.trim()}
                  className="flex-1 md:flex-none"
                >
                    {t.next}
                </Button>
            </div>
        )}
      </div>
    );
  };

  const renderPlotStep = () => (
      <div className="flex flex-col items-center space-y-6 max-w-xl mx-auto w-full">
          <h2 className="text-3xl font-bold text-kid-green">{t.wizard.whatHappens}</h2>

          <div className="w-full bg-white p-4 rounded-2xl border-4 border-kid-green shadow-sm">
              <p className="text-gray-500 text-sm mb-2">{t.wizard.whoInStory.replace('?', '')}: {state.character?.description}</p>
              <p className="text-gray-500 text-sm mb-2">{t.wizard.whereAreThey.replace('?', '')}: {state.place?.description}</p>
          </div>

          <textarea
            className="w-full h-40 p-4 rounded-2xl border-4 border-gray-300 text-xl focus:border-kid-green outline-none resize-none"
            placeholder={t.wizard.onceUponATime}
            value={state.plotInput}
            disabled={isBusy}
            onChange={(e) => {
              if (moderationGuidance) {
                clearModerationGuidance();
              }
              setState(prev => ({...prev, plotInput: e.target.value}));
            }}
          />

          {renderModerationGuidance()}
          {isModerating && <p className="w-full text-center font-bold text-kid-blue">{t.loading}</p>}

          {isLoading && totalPages > 0 && (
            <div className="w-full bg-gray-200 rounded-full h-4 overflow-hidden">
              <div
                className="bg-kid-green h-full transition-all duration-300"
                style={{ width: `${(generationProgress / totalPages) * 100}%` }}
              />
            </div>
          )}

          <div className="flex gap-2 w-full">
            <Button
              variant="outline"
              icon={<ArrowLeft />}
              onClick={handlePreviousStep}
              disabled={isBusy}
            >
              {t.previous}
            </Button>
            <Button
              disabled={isBusy}
              size="xl"
              variant="primary"
              icon={<Wand2 />}
              onClick={generatePage}
              className="flex-1"
            >
              {isLoading ? `${t.wizard.creatingMagic} (${generationProgress}/${totalPages})` : t.wizard.makeMagic}
            </Button>
            <Button
              variant={speechStatus === 'listening' ? 'primary' : 'secondary'}
              icon={speechStatus === 'listening' ? <MicOff size={24} /> : <Mic size={24} />}
              onClick={handleMicClick}
              disabled={isBusy}
              className={speechStatus === 'listening' ? 'animate-pulse bg-kid-pink' : ''}
            />
          </div>
      </div>
  );

  const renderPreview = () => (
      <div className="flex flex-col items-center space-y-6 w-full">
          <h2 className="text-4xl font-bold text-kid-pink">{t.wizard.storyReady}</h2>
          <p className="text-lg text-gray-500">{state.generatedPages.length} {t.reader.page}</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 w-full max-w-4xl">
              <div className="aspect-square bg-gray-100 rounded-3xl overflow-hidden border-8 border-white shadow-xl">
                  <img
                    src={state.generatedPages[0]?.imageUrl}
                    alt="Story Page"
                    className="w-full h-full object-cover"
                  />
              </div>
              <div className="flex flex-col gap-4 md:aspect-square">
                  <div className="flex-1 min-h-0 bg-white p-6 rounded-3xl border-4 border-kid-yellow shadow-lg overflow-y-auto">
                      <p className="text-2xl font-comic leading-relaxed text-gray-700">
                          {state.generatedPages[0]?.text}
                      </p>
                  </div>
                  <Button variant="secondary" icon={<Volume2 />}>{t.reader.readToMe}</Button>
              </div>
          </div>

          {/* Action Buttons */}
          <div className="w-full max-w-4xl bg-white p-6 rounded-3xl border-4 border-kid-blue mt-8">
              <h3 className="text-2xl font-bold text-kid-blue mb-4 text-center">{t.wizard.whatToDo}</h3>
              <div className="flex flex-wrap gap-4 justify-center">
                  <Button variant="outline" icon={<ArrowLeft />} onClick={handlePreviousStep}>
                      {t.previous}
                  </Button>

                  <Button variant="accent" icon={<Edit />} onClick={() => onFinish(state, 'edit')}>
                      {t.wizard.editing}
                  </Button>

                  <Button variant="primary" icon={<Save />} onClick={() => onFinish(state, 'save')}>
                      {t.save}
                  </Button>

                  {user.role === UserRole.STUDENT && (
                      <Button variant="outline" icon={<Printer />} onClick={handleDownload}>
                          {t.wizard.print}
                      </Button>
                  )}
              </div>
          </div>
      </div>
  );

  return (
    <div className="min-h-screen p-4 pb-20 max-w-5xl mx-auto flex flex-col">
      {/* Top Bar: Points & Progress */}
      <div className="flex items-center justify-between mb-4">
          <Button variant="outline" size="sm" onClick={onCancel}>{t.exit}</Button>
          <div className="flex items-center bg-white px-4 py-2 rounded-full border-4 border-kid-yellow shadow-sm">
              <Star className="text-kid-yellow fill-current mr-2" />
              <span className="font-bold text-xl text-kid-purple">{currentPoints} {t.wizard.points}</span>
          </div>
      </div>

      {state.step > WizardStep.AGE_SELECTION && (
          <ProgressBar currentStep={state.step} totalSteps={6} />
      )}

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col justify-center">
        {state.step === WizardStep.AGE_SELECTION && renderAgeSelection()}
        {state.step === WizardStep.CHARACTER && renderInputStep(t.wizard.whoInStory, state.character?.description || null, 'character', t.wizard.characterPlaceholder)}
        {state.step === WizardStep.PLACE && renderInputStep(t.wizard.whereAreThey, state.place?.description || null, 'place', t.wizard.placePlaceholder)}
        {state.step === WizardStep.TIME && renderInputStep(t.wizard.whenIsIt, state.time?.description || null, 'time', t.wizard.timePlaceholder)}
        {state.step === WizardStep.PLOT && renderPlotStep()}
        {state.step === WizardStep.PREVIEW && renderPreview()}
      </div>

      <BadgeNotification badge={newBadge} onClose={() => setNewBadge(null)} />
    </div>
  );
};
