/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_IFLYTEK_IAT_LANGUAGE_ZH_CN?: string;
  readonly VITE_IFLYTEK_IAT_DOMAIN_ZH_CN?: string;
  readonly VITE_IFLYTEK_IAT_ACCENT_ZH_CN?: string;
  readonly VITE_IFLYTEK_IAT_LANGUAGE_ZH_HK?: string;
  readonly VITE_IFLYTEK_IAT_DOMAIN_ZH_HK?: string;
  readonly VITE_IFLYTEK_IAT_ACCENT_ZH_HK?: string;
  readonly VITE_IFLYTEK_IAT_LANGUAGE_EN?: string;
  readonly VITE_IFLYTEK_IAT_DOMAIN_EN?: string;
  readonly VITE_IFLYTEK_IAT_ACCENT_EN?: string;
  readonly VITE_IFLYTEK_IAT_VAD_EOS?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}

interface SpeechRecognitionConstructor {
  new (): any;
}

interface Window {
  SpeechRecognition?: SpeechRecognitionConstructor;
  webkitSpeechRecognition?: SpeechRecognitionConstructor;
}
