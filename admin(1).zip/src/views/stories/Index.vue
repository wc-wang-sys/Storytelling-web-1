<template>
  <div class="page-card">
    <div class="toolbar">
      <div class="toolbar-left">
        <el-select v-model="filters.schoolId" clearable :placeholder="$t('common.filters.schoolShort')" @change="handleSchoolChange">
          <el-option v-for="school in schools" :key="school.id" :label="school.name" :value="school.id"></el-option>
        </el-select>
        <el-select v-model="filters.classId" clearable :placeholder="$t('common.filters.classShort')" @change="loadRows">
          <el-option v-for="item in filteredClasses" :key="item.id" :label="item.name" :value="item.id"></el-option>
        </el-select>
        <el-select v-model="filters.studentId" clearable :placeholder="$t('common.filters.studentShort')" @change="loadRows">
          <el-option v-for="item in filteredStudents" :key="item.id" :label="item.name" :value="item.id"></el-option>
        </el-select>
        <el-input v-model.trim="filters.search" :placeholder="$t('common.filters.searchStories')" style="width: 220px" @keyup.enter.native="loadRows"></el-input>
      </div>
      <div class="toolbar-right">
        <el-button @click="loadRows">{{ $t('common.buttons.refresh') }}</el-button>
      </div>
    </div>

    <data-table :loading="loading" :rows="rows" :columns="tableColumns">
      <template slot="cell-cover" slot-scope="{ row }">
        <img :src="row.coverImage" alt="" class="story-cover" />
      </template>
      <template slot="cell-classroom" slot-scope="{ row }">{{ className(row.classId) }}</template>
      <template slot="cell-school" slot-scope="{ row }">{{ schoolName(row.schoolId) }}</template>
      <template slot="cell-createdAt" slot-scope="{ row }">{{ formatDate(row.createdAt) }}</template>
      <template slot="cell-actions" slot-scope="{ row }">
        <div class="table-actions">
          <el-button size="mini" @click="openDialog(row)">{{ $t('common.buttons.viewEdit') }}</el-button>
          <el-button size="mini" type="danger" plain @click="handleDelete(row)">{{ $t('common.buttons.delete') }}</el-button>
        </div>
      </template>
    </data-table>

    <el-dialog :visible.sync="dialogVisible" :title="editingStory ? editingStory.title : $t('stories.edit')" width="900px" top="5vh">
      <div v-if="form.id">
        <el-form :model="form" label-width="100px">
          <el-form-item :label="$t('stories.fields.title')">
            <el-input v-model.trim="form.title"></el-input>
          </el-form-item>
          <el-form-item :label="$t('stories.fields.cover')">
            <div class="story-image-editor">
              <div class="story-image-preview story-image-preview-cover">
                <img v-if="form.coverImage" :src="form.coverImage" alt="" class="story-image-preview-img" />
                <div v-else class="story-image-preview-empty">{{ $t('common.messages.noCoverImage') }}</div>
              </div>
              <div class="story-image-source">
                <div class="story-image-source-summary">{{ imageSourceSummary(form.coverImage) }}</div>
                <el-button size="mini" @click="showCoverImageEditor = !showCoverImageEditor">
                  {{ showCoverImageEditor ? $t('common.buttons.collapseImageSource') : $t('common.buttons.editImageSource') }}
                </el-button>
                <el-input
                  v-if="showCoverImageEditor"
                  v-model.trim="form.coverImage"
                  type="textarea"
                  :rows="4"
                  :placeholder="$t('common.placeholders.imageSource')"
                />
              </div>
            </div>
          </el-form-item>
          <el-form-item :label="$t('stories.fields.time')">
            <el-input v-model.trim="form.time"></el-input>
          </el-form-item>
          <el-form-item :label="$t('stories.fields.status')">
            <el-select v-model="form.status">
              <el-option :label="$t('common.status.draft')" value="draft"></el-option>
              <el-option :label="$t('common.status.published')" value="published"></el-option>
              <el-option :label="$t('common.status.archived')" value="archived"></el-option>
            </el-select>
          </el-form-item>
        </el-form>

        <div style="margin-top: 24px">
          <h3>{{ $t('stories.sections.pages') }}</h3>
          <div v-for="(page, index) in form.pages" :key="index" style="margin-bottom: 18px; border: 1px solid #e2e8f0; border-radius: 14px; padding: 16px">
            <div style="display: flex; justify-content: space-between; margin-bottom: 10px">
              <strong>{{ $t('stories.pageLabel', { index: index + 1 }) }}</strong>
              <el-button type="text" style="color: #dc2626" @click="removePage(index)">{{ $t('common.buttons.deletePage') }}</el-button>
            </div>
            <div class="story-image-editor story-page-image-editor">
              <div class="story-image-preview">
                <img v-if="page.imageUrl" :src="page.imageUrl" alt="" class="story-image-preview-img" />
                <div v-else class="story-image-preview-empty">{{ $t('common.messages.noPageImage') }}</div>
              </div>
              <div class="story-image-source">
                <div class="story-image-source-summary">{{ imageSourceSummary(page.imageUrl) }}</div>
                <el-button size="mini" @click="togglePageImageEditor(index)">
                  {{ pageImageEditors[index] ? $t('common.buttons.collapseImageSource') : $t('common.buttons.editImageSource') }}
                </el-button>
                <el-input
                  v-if="pageImageEditors[index]"
                  v-model.trim="page.imageUrl"
                  type="textarea"
                  :rows="4"
                  :placeholder="$t('common.placeholders.imageSource')"
                />
              </div>
            </div>
            <el-input v-model.trim="page.imagePrompt" :placeholder="$t('common.placeholders.imagePrompt')" style="margin-bottom: 10px"></el-input>
            <el-input v-model="page.text" type="textarea" :rows="4" :placeholder="$t('common.placeholders.pageText')"></el-input>
          </div>
          <el-button plain @click="addPage">{{ $t('common.buttons.addPage') }}</el-button>
        </div>
      </div>
      <span slot="footer">
        <el-button @click="dialogVisible = false">{{ $t('common.buttons.cancel') }}</el-button>
        <el-button type="primary" :loading="submitting" @click="submitForm">{{ $t('common.buttons.save') }}</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import {
  deleteStory,
  fetchClasses,
  fetchSchools,
  fetchStories,
  fetchStudents,
  updateStory,
} from '../../api/services';
import DataTable from '../../components/DataTable.vue';
import { getCachedUser } from '../../utils/auth';

const emptyForm = () => ({
  id: '',
  title: '',
  coverImage: '',
  time: '',
  status: 'published',
  pages: [],
  character: {},
  place: {},
  styling: { titleColor: '#1d4ed8', fontFamily: 'font-comic' },
});

export default {
  name: 'StoriesIndex',
  components: { DataTable },
  data() {
    const currentUser = getCachedUser();
    const schoolId = currentUser && currentUser.backendRole === 'school_admin' ? currentUser.schoolId : '';
    return {
      currentUser,
      loading: false,
      submitting: false,
      dialogVisible: false,
      rows: [],
      schools: [],
      classes: [],
      students: [],
      showCoverImageEditor: false,
      pageImageEditors: {},
      editingStory: null,
      form: emptyForm(),
      filters: {
        schoolId,
        classId: '',
        studentId: '',
        search: '',
      },
    };
  },
  computed: {
    tableColumns() {
      return [
        { key: 'cover', label: this.$t('stories.columns.cover'), width: 110, align: 'center' },
        { key: 'title', prop: 'title', label: this.$t('stories.columns.title'), minWidth: 220 },
        { key: 'studentName', prop: 'studentName', label: this.$t('stories.columns.student'), width: 140 },
        { key: 'classroom', label: this.$t('stories.columns.class'), width: 140 },
        { key: 'school', label: this.$t('stories.columns.school'), minWidth: 180 },
        { key: 'createdAt', label: this.$t('stories.columns.createdAt'), width: 180 },
        { key: 'actions', label: this.$t('common.table.actions'), width: 200 },
      ];
    },
    filteredClasses() {
      if (!this.filters.schoolId) {
        return this.classes;
      }
      return this.classes.filter((item) => item.schoolId === this.filters.schoolId);
    },
    filteredStudents() {
      let rows = this.students;
      if (this.filters.schoolId) {
        rows = rows.filter((item) => item.schoolId === this.filters.schoolId);
      }
      if (this.filters.classId) {
        rows = rows.filter((item) => item.classId === this.filters.classId);
      }
      return rows;
    },
  },
  created() {
    this.loadFilters();
    this.loadRows();
  },
  methods: {
    schoolName(id) {
      const row = this.schools.find((item) => item.id === id);
      return row ? row.name : '-';
    },
    className(id) {
      const row = this.classes.find((item) => item.id === id);
      return row ? row.name : '-';
    },
    formatDate(timestamp) {
      return new Date(timestamp).toLocaleString(this.$lang === 'en' ? 'en-US' : this.$lang);
    },
    async loadFilters() {
      try {
        this.schools = await fetchSchools();
        this.classes = await fetchClasses(this.filters.schoolId ? { schoolId: this.filters.schoolId } : {});
        this.students = await fetchStudents(this.filters.schoolId ? { schoolId: this.filters.schoolId } : {});
      } catch (error) {
        this.$message.error(error.message);
      }
    },
    async loadRows() {
      this.loading = true;
      try {
        const params = {};
        if (this.filters.schoolId) params.schoolId = this.filters.schoolId;
        if (this.filters.classId) params.classId = this.filters.classId;
        if (this.filters.studentId) params.studentId = this.filters.studentId;
        if (this.filters.search) params.search = this.filters.search;
        this.rows = await fetchStories(params);
      } catch (error) {
        this.$message.error(error.message);
      } finally {
        this.loading = false;
      }
    },
    async handleSchoolChange() {
      this.filters.classId = '';
      this.filters.studentId = '';
      await this.loadFilters();
      this.loadRows();
    },
    openDialog(row) {
      this.editingStory = row;
      this.form = JSON.parse(JSON.stringify(row));
      this.showCoverImageEditor = false;
      this.pageImageEditors = {};
      this.dialogVisible = true;
    },
    addPage() {
      this.form.pages.push({ text: '', imageUrl: '', imagePrompt: '' });
    },
    removePage(index) {
      this.form.pages.splice(index, 1);
      this.$delete(this.pageImageEditors, index);
    },
    togglePageImageEditor(index) {
      this.$set(this.pageImageEditors, index, !this.pageImageEditors[index]);
    },
    imageSourceSummary(value) {
      if (!value) {
        return this.$t('common.messages.noImageData');
      }

      if (/^data:image\/[a-zA-Z0-9.+-]+;base64,/.test(value)) {
        const kb = Math.max(1, Math.round(value.length / 1024));
        return this.$t('common.messages.base64ImageSummary', { size: kb });
      }

      return value;
    },
    async submitForm() {
      this.submitting = true;
      try {
        await updateStory(this.form.id, this.form);
        this.dialogVisible = false;
        this.$message.success(this.$t('common.messages.saveSuccess'));
        this.loadRows();
      } catch (error) {
        this.$message.error(error.message);
      } finally {
        this.submitting = false;
      }
    },
    async handleDelete(row) {
      try {
        await this.$confirm(this.$t('stories.deleteConfirm', { title: row.title }), this.$t('common.notice'), { type: 'warning' });
        await deleteStory(row.id);
        this.$message.success(this.$t('common.messages.deleteSuccess'));
        this.loadRows();
      } catch (error) {
        if (error && error.message !== 'cancel') {
          this.$message.error(error.message);
        }
      }
    },
  },
};
</script>

<style scoped>
.story-cover {
  width: 72px;
  height: 72px;
  object-fit: cover;
  border-radius: 12px;
  background: #e2e8f0;
}

.story-image-editor {
  display: grid;
  grid-template-columns: 220px minmax(0, 1fr);
  gap: 16px;
  align-items: start;
}

.story-page-image-editor {
  margin-bottom: 10px;
}

.story-image-preview {
  width: 220px;
  height: 220px;
  border-radius: 18px;
  overflow: hidden;
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  display: flex;
  align-items: center;
  justify-content: center;
}

.story-image-preview-cover {
  height: 260px;
}

.story-image-preview-img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
}

.story-image-preview-empty {
  color: #94a3b8;
  font-size: 13px;
}

.story-image-source {
  min-width: 0;
  display: grid;
  gap: 10px;
}

.story-image-source-summary {
  padding: 12px 14px;
  border-radius: 12px;
  background: #f8fafc;
  color: #475569;
  line-height: 1.6;
  word-break: break-all;
}

.table-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

@media (max-width: 900px) {
  .story-image-editor {
    grid-template-columns: 1fr;
  }

  .story-image-preview,
  .story-image-preview-cover {
    width: 100%;
    height: 240px;
  }
}
</style>
