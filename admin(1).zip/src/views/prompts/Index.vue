<template>
  <div class="page-card">
    <div class="toolbar">
      <div>
        <h2 style="margin: 0">{{ $t('prompts.title') }}</h2>
        <p style="margin: 8px 0 0; color: #64748b">{{ $t('prompts.subtitle') }}</p>
      </div>
      <div class="toolbar-right">
        <el-button @click="loadRows">{{ $t('common.buttons.refresh') }}</el-button>
      </div>
    </div>

    <data-table :loading="loading" :rows="rows" :columns="tableColumns">
      <template slot="cell-title" slot-scope="{ row }">
        <div>
          <div class="prompt-title">{{ row.title }}</div>
          <div class="prompt-desc">{{ row.description }}</div>
        </div>
      </template>
      <template slot="cell-category" slot-scope="{ row }">
        <el-tag size="mini" effect="plain">{{ row.category }}</el-tag>
      </template>
      <template slot="cell-variables" slot-scope="{ row }">
        <div class="tag-list">
          <el-tag v-for="item in row.variables" :key="item" size="mini" type="info">
            {{ formatVariable(item) }}
          </el-tag>
          <span v-if="!row.variables || !row.variables.length">-</span>
        </div>
      </template>
      <template slot="cell-updatedAt" slot-scope="{ row }">
        {{ formatDate(row.updatedAt) }}
      </template>
      <template slot="cell-actions" slot-scope="{ row }">
        <div class="table-actions">
          <el-button size="mini" type="primary" @click="openDialog(row)">{{ $t('common.buttons.edit') }}</el-button>
        </div>
      </template>
    </data-table>

    <el-dialog :visible.sync="dialogVisible" width="980px" :title="editingRow ? editingRow.title : $t('prompts.edit')" top="5vh">
      <div v-if="editingRow" class="dialog-content">
        <el-alert
          :title="placeholderTip"
          type="info"
          :closable="false"
          style="margin-bottom: 20px"
        />

        <el-form label-width="110px">
          <el-form-item :label="$t('common.fields.promptKey')">
            <el-input :value="editingRow.key" disabled></el-input>
          </el-form-item>
          <el-form-item :label="$t('common.fields.category')">
            <el-input :value="editingRow.category" disabled></el-input>
          </el-form-item>
          <el-form-item :label="$t('common.fields.variables')">
            <div class="tag-list">
              <el-tag v-for="item in editingRow.variables" :key="item" size="mini" type="info">
                {{ formatVariable(item) }}
              </el-tag>
              <span v-if="!editingRow.variables || !editingRow.variables.length">-</span>
            </div>
          </el-form-item>
          <el-form-item :label="$t('common.fields.defaultTemplate')">
            <el-input :value="editingRow.defaultTemplate" type="textarea" :rows="7" readonly></el-input>
          </el-form-item>
          <el-form-item :label="$t('common.fields.currentTemplate')">
            <el-input v-model="form.templateText" type="textarea" :rows="10"></el-input>
          </el-form-item>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false">{{ $t('common.buttons.cancel') }}</el-button>
        <el-button v-if="editingRow" @click="restoreDefault">{{ $t('common.buttons.restoreDefault') }}</el-button>
        <el-button type="primary" :loading="submitting" @click="submitForm">{{ $t('common.buttons.save') }}</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import DataTable from '../../components/DataTable.vue';
import { fetchPromptTemplates, updatePromptTemplate } from '../../api/services';
import { getCachedUser } from '../../utils/auth';

export default {
  name: 'PromptsIndex',
  components: { DataTable },
  data() {
    return {
      loading: false,
      submitting: false,
      dialogVisible: false,
      rows: [],
      editingRow: null,
      form: {
        templateText: '',
      },
      currentUser: getCachedUser(),
    };
  },
  computed: {
    placeholderTip() {
      return this.$t('common.messages.placeholderTip');
    },
    tableColumns() {
      return [
        { key: 'title', label: this.$t('prompts.columns.title'), minWidth: 260 },
        { key: 'key', prop: 'key', label: this.$t('prompts.columns.key'), minWidth: 220 },
        { key: 'category', label: this.$t('prompts.columns.category'), width: 120, align: 'center' },
        { key: 'variables', label: this.$t('prompts.columns.variables'), minWidth: 220 },
        { key: 'updatedAt', label: this.$t('prompts.columns.updatedAt'), width: 180 },
        { key: 'actions', label: this.$t('common.table.actions'), width: 120 },
      ];
    },
  },
  created() {
    this.loadRows();
  },
  methods: {
    formatVariable(value) {
      return `{{${value}}}`;
    },
    formatDate(timestamp) {
      if (!timestamp) {
        return '-';
      }
      return new Date(timestamp).toLocaleString(this.$lang === 'en' ? 'en-US' : this.$lang);
    },
    async loadRows() {
      this.loading = true;
      try {
        this.rows = await fetchPromptTemplates();
      } catch (error) {
        this.$message.error(error.message);
      } finally {
        this.loading = false;
      }
    },
    openDialog(row) {
      this.editingRow = JSON.parse(JSON.stringify(row));
      this.form.templateText = row.templateText;
      this.dialogVisible = true;
    },
    restoreDefault() {
      if (!this.editingRow) {
        return;
      }
      this.form.templateText = this.editingRow.defaultTemplate;
    },
    async submitForm() {
      if (!this.editingRow) {
        return;
      }
      this.submitting = true;
      try {
        await updatePromptTemplate(this.editingRow.key, {
          templateText: this.form.templateText,
        });
        this.dialogVisible = false;
        this.$message.success(this.$t('common.messages.saveSuccess'));
        this.loadRows();
      } catch (error) {
        this.$message.error(error.message);
      } finally {
        this.submitting = false;
      }
    },
  },
};
</script>

<style scoped>
.prompt-title {
  font-size: 14px;
  font-weight: 700;
  color: #0f172a;
}

.prompt-desc {
  margin-top: 6px;
  color: #64748b;
  line-height: 1.5;
}

.table-actions,
.tag-list {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.dialog-content {
  max-height: 70vh;
  overflow-y: auto;
  padding-right: 8px;
}
</style>
