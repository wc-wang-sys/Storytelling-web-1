<template>
  <div class="page-card">
    <div class="toolbar">
      <div class="toolbar-left">
        <el-select v-model="filters.schoolId" clearable :placeholder="$t('common.filters.school')" @change="handleSchoolChange">
          <el-option v-for="school in schools" :key="school.id" :label="school.name" :value="school.id"></el-option>
        </el-select>
        <el-select v-model="filters.classId" clearable :placeholder="$t('common.filters.class')" @change="loadRows">
          <el-option v-for="item in filteredClasses" :key="item.id" :label="item.name" :value="item.id"></el-option>
        </el-select>
      </div>
      <div class="toolbar-right">
        <el-button type="primary" @click="openDialog()">{{ $t('students.add') }}</el-button>
      </div>
    </div>

    <data-table :loading="loading" :rows="rows" :columns="tableColumns">
      <template slot="cell-school" slot-scope="{ row }">{{ schoolName(row.schoolId) }}</template>
      <template slot="cell-classroom" slot-scope="{ row }">{{ className(row.classId) }}</template>
      <template slot="cell-teacher" slot-scope="{ row }">{{ teacherName(row.teacherId) }}</template>
      <template slot="cell-status" slot-scope="{ row }">
        <span :class="['status-tag', row.status === 'active' ? 'status-active' : 'status-disabled']">
          {{ statusLabel(row.status) }}
        </span>
      </template>
      <template slot="cell-actions" slot-scope="{ row }">
        <div class="table-actions">
          <el-button size="mini" @click="openDialog(row)">{{ $t('common.buttons.edit') }}</el-button>
          <el-button size="mini" @click="openQr(row)">{{ $t('common.buttons.qrCode') }}</el-button>
          <el-button size="mini" type="danger" plain @click="handleDelete(row)">{{ $t('common.buttons.delete') }}</el-button>
        </div>
      </template>
    </data-table>

    <el-dialog :visible.sync="dialogVisible" :title="editingId ? $t('students.edit') : $t('students.add')" width="680px">
      <el-form :model="form" label-width="110px">
        <el-form-item :label="$t('students.fields.school')">
          <el-select v-model="form.schoolId" @change="handleFormSchoolChange">
            <el-option v-for="school in schools" :key="school.id" :label="school.name" :value="school.id"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item :label="$t('students.fields.class')">
          <el-select v-model="form.classId" @change="handleFormClassChange">
            <el-option v-for="item in filteredClassesForForm" :key="item.id" :label="item.name" :value="item.id"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item :label="$t('students.fields.teacher')">
          <el-select v-model="form.teacherId" clearable>
            <el-option v-for="item in filteredTeachersForForm" :key="item.id" :label="item.name" :value="item.id"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item :label="$t('students.fields.name')">
          <el-input v-model.trim="form.name"></el-input>
        </el-form-item>
        <el-form-item :label="$t('students.fields.studentNo')">
          <el-input v-model.trim="form.studentNo"></el-input>
        </el-form-item>
        <el-form-item :label="$t('students.fields.ageGroup')">
          <el-select v-model="form.ageGroup">
            <el-option label="3-5" value="3-5"></el-option>
            <el-option label="5-7" value="5-7"></el-option>
            <el-option label="8-10" value="8-10"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item :label="$t('students.fields.username')">
          <el-input v-model.trim="form.username"></el-input>
        </el-form-item>
        <el-form-item :label="$t('students.fields.password')">
          <el-input v-model.trim="form.password" show-password :placeholder="$t('common.placeholders.passwordOptional')"></el-input>
        </el-form-item>
        <el-form-item :label="$t('common.table.status')">
          <el-select v-model="form.status">
            <el-option :label="$t('common.status.active')" value="active"></el-option>
            <el-option :label="$t('common.status.disabled')" value="disabled"></el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <span slot="footer">
        <el-button @click="dialogVisible = false">{{ $t('common.buttons.cancel') }}</el-button>
        <el-button type="primary" :loading="submitting" @click="submitForm">{{ $t('common.buttons.save') }}</el-button>
      </span>
    </el-dialog>

    <qr-code-dialog
      v-if="qrTarget"
      v-model="qrVisible"
      :title="$t('common.qr.loginTitle', { name: qrTarget.name })"
      entity-type="student"
      :entity-id="qrTarget.id"
    />
  </div>
</template>

<script>
import {
  createStudent,
  deleteStudent,
  fetchClasses,
  fetchSchools,
  fetchStudents,
  fetchTeachers,
  updateStudent,
} from '../../api/services';
import DataTable from '../../components/DataTable.vue';
import { getCachedUser } from '../../utils/auth';
import QrCodeDialog from '../../components/QrCodeDialog.vue';

const emptyForm = (schoolId = '') => ({
  schoolId,
  classId: '',
  teacherId: '',
  studentNo: '',
  name: '',
  ageGroup: '5-7',
  username: '',
  password: '',
  status: 'active',
});

export default {
  name: 'StudentsIndex',
  components: { DataTable, QrCodeDialog },
  data() {
    const currentUser = getCachedUser();
    const schoolId = currentUser && currentUser.backendRole !== 'super_admin' ? currentUser.schoolId : '';
    return {
      currentUser,
      loading: false,
      submitting: false,
      dialogVisible: false,
      qrVisible: false,
      qrTarget: null,
      editingId: '',
      rows: [],
      schools: [],
      classes: [],
      teachers: [],
      filters: {
        schoolId,
        classId: '',
      },
      form: emptyForm(schoolId),
    };
  },
  computed: {
    tableColumns() {
      return [
        { key: 'name', prop: 'name', label: this.$t('students.columns.name'), minWidth: 140 },
        { key: 'studentNo', prop: 'studentNo', label: this.$t('students.columns.studentNo'), width: 140 },
        { key: 'username', prop: 'username', label: this.$t('students.columns.username'), width: 160 },
        { key: 'school', label: this.$t('students.columns.school'), minWidth: 160 },
        { key: 'classroom', label: this.$t('students.columns.class'), minWidth: 140 },
        { key: 'teacher', label: this.$t('students.columns.teacher'), minWidth: 140 },
        { key: 'ageGroup', prop: 'ageGroup', label: this.$t('students.columns.ageGroup'), width: 120, align: 'center' },
        { key: 'status', label: this.$t('common.table.status'), width: 120, align: 'center' },
        { key: 'actions', label: this.$t('common.table.actions'), width: 260 },
      ];
    },
    filteredClasses() {
      if (!this.filters.schoolId) {
        return this.classes;
      }
      return this.classes.filter((item) => item.schoolId === this.filters.schoolId);
    },
    filteredClassesForForm() {
      if (!this.form.schoolId) {
        return this.classes;
      }
      return this.classes.filter((item) => item.schoolId === this.form.schoolId);
    },
    filteredTeachersForForm() {
      if (!this.form.schoolId) {
        return this.teachers;
      }

      const inSchool = this.teachers.filter((item) => item.schoolId === this.form.schoolId);
      if (!this.form.classId) {
        return inSchool;
      }
      return inSchool.filter((item) => (item.classIds || []).includes(this.form.classId));
    },
  },
  created() {
    this.loadFilters();
    this.loadRows();
  },
  methods: {
    statusLabel(status) {
      return this.$t(`common.status.${status}`);
    },
    schoolName(id) {
      const item = this.schools.find((row) => row.id === id);
      return item ? item.name : '-';
    },
    className(id) {
      const item = this.classes.find((row) => row.id === id);
      return item ? item.name : '-';
    },
    teacherName(id) {
      const item = this.teachers.find((row) => row.id === id);
      return item ? item.name : '-';
    },
    async loadFilters() {
      try {
        this.schools = await fetchSchools();
        this.classes = await fetchClasses(this.filters.schoolId ? { schoolId: this.filters.schoolId } : {});
        this.teachers = await fetchTeachers(this.filters.schoolId ? { schoolId: this.filters.schoolId } : {});
      } catch (error) {
        this.$message.error(error.message);
      }
    },
    async loadRows() {
      this.loading = true;
      try {
        const params = {};
        if (this.filters.schoolId) params.schoolId = this.filters.schoolId;
        if (this.filters.classId) params.classId = this.filters.classId;
        this.rows = await fetchStudents(params);
      } catch (error) {
        this.$message.error(error.message);
      } finally {
        this.loading = false;
      }
    },
    async handleSchoolChange() {
      this.filters.classId = '';
      await this.loadFilters();
      this.loadRows();
    },
    async handleFormSchoolChange() {
      this.form.classId = '';
      this.form.teacherId = '';
      await this.loadFilters();
    },
    handleFormClassChange() {
      if (!this.filteredTeachersForForm.find((item) => item.id === this.form.teacherId)) {
        this.form.teacherId = '';
      }
    },
    openDialog(row) {
      this.editingId = row ? row.id : '';
      this.form = row
        ? {
            schoolId: row.schoolId,
            classId: row.classId,
            teacherId: row.teacherId,
            studentNo: row.studentNo,
            name: row.name,
            ageGroup: row.ageGroup,
            username: row.username,
            password: '',
            status: row.status,
          }
        : emptyForm(this.filters.schoolId || (this.currentUser && this.currentUser.schoolId) || '');
      this.dialogVisible = true;
    },
    async submitForm() {
      this.submitting = true;
      try {
        if (this.editingId) {
          await updateStudent(this.editingId, this.form);
        } else {
          await createStudent(this.form);
        }
        this.dialogVisible = false;
        this.$message.success(this.$t('common.messages.saveSuccess'));
        this.loadRows();
      } catch (error) {
        this.$message.error(error.message);
      } finally {
        this.submitting = false;
      }
    },
    async handleDelete(row) {
      try {
        await this.$confirm(this.$t('students.deleteConfirm', { name: row.name }), this.$t('common.notice'), { type: 'warning' });
        await deleteStudent(row.id);
        this.$message.success(this.$t('common.messages.deleteSuccess'));
        this.loadRows();
      } catch (error) {
        if (error && error.message !== 'cancel') {
          this.$message.error(error.message);
        }
      }
    },
    openQr(row) {
      this.qrTarget = row;
      this.qrVisible = true;
    },
  },
};
</script>

<style scoped>
.table-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}
</style>
