<template>
  <el-container class="layout-shell">
    <el-aside width="220px" class="layout-aside">
      <div class="brand">
        <div class="brand-mark">S</div>
        <div>
          <div class="brand-title">{{ $t('layout.brandTitle') }}</div>
          <div class="brand-subtitle">{{ $t('layout.brandSubtitle') }}</div>
        </div>
      </div>

      <el-menu
        :default-active="$route.path"
        class="side-menu"
        background-color="transparent"
        text-color="#cbd5e1"
        active-text-color="#ffffff"
        @select="handleSelect"
      >
        <el-menu-item index="/dashboard">{{ $t('layout.menu.dashboard') }}</el-menu-item>
        <el-menu-item v-if="showMenu('schools')" index="/schools">{{ $t('layout.menu.schools') }}</el-menu-item>
        <el-menu-item v-if="showMenu('classes')" index="/classes">{{ $t('layout.menu.classes') }}</el-menu-item>
        <el-menu-item v-if="showMenu('teachers')" index="/teachers">{{ $t('layout.menu.teachers') }}</el-menu-item>
        <el-menu-item index="/students">{{ $t('layout.menu.students') }}</el-menu-item>
        <el-menu-item index="/stories">{{ $t('layout.menu.stories') }}</el-menu-item>
        <el-menu-item v-if="showMenu('prompts')" index="/prompts">{{ $t('layout.menu.prompts') }}</el-menu-item>
      </el-menu>
    </el-aside>

    <el-container>
      <el-header class="layout-header">
        <div>
          <div class="header-title">{{ pageTitle }}</div>
          <div class="header-subtitle">{{ currentUser && currentUser.schoolName ? currentUser.schoolName : $t('layout.platformSpace') }}</div>
        </div>

        <div class="header-actions">
          <language-switcher />
          <div class="user-chip">
            <div class="user-chip-name">{{ currentUser ? currentUser.name : '' }}</div>
            <div class="user-chip-role">{{ roleLabel }}</div>
          </div>
          <el-button type="danger" plain @click="handleLogout">{{ $t('common.buttons.logout') }}</el-button>
        </div>
      </el-header>

      <el-main class="layout-main">
        <router-view v-if="currentUser" :current-user="currentUser" />
      </el-main>
    </el-container>
  </el-container>
</template>

<script>
import { fetchCurrentUser } from '../api/services';
import LanguageSwitcher from '../components/LanguageSwitcher.vue';
import { clearSession, getCachedUser, setCachedUser } from '../utils/auth';

const TITLE_MAP = {
  '/dashboard': 'layout.pageTitles.dashboard',
  '/schools': 'layout.pageTitles.schools',
  '/classes': 'layout.pageTitles.classes',
  '/teachers': 'layout.pageTitles.teachers',
  '/students': 'layout.pageTitles.students',
  '/stories': 'layout.pageTitles.stories',
  '/prompts': 'layout.pageTitles.prompts',
};

export default {
  name: 'LayoutView',
  components: {
    LanguageSwitcher,
  },
  data() {
    return {
      currentUser: getCachedUser(),
    };
  },
  computed: {
    pageTitle() {
      return this.$t(TITLE_MAP[this.$route.path] || 'layout.pageTitles.fallback');
    },
    roleLabel() {
      if (!this.currentUser) {
        return '';
      }

      const label = this.$t(`layout.roles.${this.currentUser.backendRole}`);
      return label === `layout.roles.${this.currentUser.backendRole}` ? this.currentUser.backendRole : label;
    },
  },
  created() {
    this.loadCurrentUser();
  },
  methods: {
    async loadCurrentUser() {
      try {
        const user = await fetchCurrentUser();
        this.currentUser = user;
        setCachedUser(user);
      } catch (error) {
        this.$message.error(error.message);
        clearSession();
        this.$router.replace('/login');
      }
    },
    showMenu(key) {
      if (!this.currentUser) {
        return false;
      }

      if (key === 'prompts') {
        return this.currentUser.backendRole === 'super_admin';
      }

      if (this.currentUser.backendRole === 'teacher') {
        return key === 'students' || key === 'stories';
      }

      return true;
    },
    handleSelect(path) {
      this.$router.push(path);
    },
    handleLogout() {
      clearSession();
      this.$router.replace('/login');
    },
  },
};
</script>

<style scoped>
.layout-shell {
  min-height: 100vh;
}

.layout-aside {
  background: linear-gradient(180deg, #0f172a, #1e293b);
  color: #fff;
  padding: 24px 18px;
}

.brand {
  display: flex;
  align-items: center;
  gap: 14px;
  margin-bottom: 28px;
}

.brand-mark {
  width: 44px;
  height: 44px;
  border-radius: 14px;
  background: linear-gradient(135deg, #38bdf8, #818cf8);
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 700;
  font-size: 22px;
}

.brand-title {
  font-size: 18px;
  font-weight: 700;
}

.brand-subtitle {
  font-size: 12px;
  color: #94a3b8;
}

.side-menu {
  border-right: none;
}

.side-menu .el-menu-item {
  border-radius: 12px;
  margin-bottom: 8px;
}

.side-menu .el-menu-item.is-active {
  background: rgba(59, 130, 246, 0.28) !important;
}

.layout-header {
  background: #fff;
  box-shadow: 0 8px 24px rgba(15, 23, 42, 0.06);
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 28px;
}

.header-title {
  font-size: 22px;
  font-weight: 700;
}

.header-subtitle {
  margin-top: 4px;
  color: #64748b;
  font-size: 13px;
}

.header-actions {
  display: flex;
  align-items: center;
  gap: 16px;
}

.user-chip {
  padding: 10px 14px;
  border-radius: 14px;
  background: #eff6ff;
}

.user-chip-name {
  font-size: 14px;
  font-weight: 700;
}

.user-chip-role {
  font-size: 12px;
  color: #64748b;
}

.layout-main {
  padding: 24px;
}
</style>
