<template>
  <div class="login-shell">
    <div class="login-card">
      <div class="login-language">
        <language-switcher />
      </div>
      <div class="login-heading">
        <div class="login-badge">{{ $t('login.badge') }}</div>
        <h1>{{ $t('login.title') }}</h1>
        <p>{{ $t('login.subtitle') }}</p>
      </div>

      <el-tabs v-model="tab">
        <el-tab-pane :label="$t('login.tabs.password')" name="password">
          <el-form @submit.native.prevent="handlePasswordLogin">
            <el-form-item :label="$t('login.fields.username')">
              <el-input v-model.trim="form.username" :placeholder="$t('common.placeholders.username')"></el-input>
            </el-form-item>
            <el-form-item :label="$t('login.fields.password')">
              <el-input v-model.trim="form.password" show-password :placeholder="$t('common.placeholders.password')"></el-input>
            </el-form-item>
            <el-button type="primary" :loading="submitting" style="width: 100%" @click="handlePasswordLogin">
              {{ $t('login.tabs.password') }}
            </el-button>
          </el-form>
        </el-tab-pane>

        <el-tab-pane :label="$t('login.tabs.qr')" name="qr">
          <div class="qr-login-pane">
            <el-button type="primary" style="width: 100%" @click="scannerVisible = true">{{ $t('common.buttons.openScanner') }}</el-button>
            <el-input
              v-model.trim="qrToken"
              type="textarea"
              :rows="4"
              :placeholder="$t('common.placeholders.qrToken')"
            />
            <el-button style="width: 100%" @click="handleQrLogin">{{ $t('common.buttons.useTokenLogin') }}</el-button>
          </div>
        </el-tab-pane>
      </el-tabs>

      <div class="seed-tip">
        {{ $t('login.demoAccounts') }}
        <div>`superadmin / admin123`</div>
        <div>`schooladmin / school123`</div>
        <div>`teacher01 / teacher123`</div>
      </div>
    </div>

    <qr-scanner-dialog v-model="scannerVisible" @detected="onQrDetected" />
  </div>
</template>

<script>
import { loginByPassword, loginByQr } from '../../api/services';
import LanguageSwitcher from '../../components/LanguageSwitcher.vue';
import { setCachedUser, setToken } from '../../utils/auth';
import QrScannerDialog from '../../components/QrScannerDialog.vue';

export default {
  name: 'AdminLogin',
  components: {
    LanguageSwitcher,
    QrScannerDialog,
  },
  data() {
    return {
      tab: 'password',
      submitting: false,
      scannerVisible: false,
      qrToken: '',
      form: {
        username: '',
        password: '',
      },
    };
  },
  methods: {
    async finishLogin(result) {
      setToken(result.accessToken);
      setCachedUser(result.user);
      await this.$router.replace('/dashboard');
    },
    async handlePasswordLogin() {
      if (!this.form.username || !this.form.password) {
        this.$message.warning(this.$t('common.messages.enterUsernamePassword'));
        return;
      }

      this.submitting = true;
      try {
        const result = await loginByPassword(this.form);
        await this.finishLogin(result);
      } catch (error) {
        this.$message.error(error.message);
      } finally {
        this.submitting = false;
      }
    },
    async handleQrLogin() {
      if (!this.qrToken) {
        this.$message.warning(this.$t('common.messages.pasteQrToken'));
        return;
      }

      try {
        const result = await loginByQr(this.qrToken);
        await this.finishLogin(result);
      } catch (error) {
        this.$message.error(error.message);
      }
    },
    onQrDetected(token) {
      this.qrToken = token;
      this.handleQrLogin();
    },
  },
};
</script>

<style scoped>
.login-shell {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background:
    radial-gradient(circle at top left, rgba(59, 130, 246, 0.2), transparent 36%),
    radial-gradient(circle at bottom right, rgba(16, 185, 129, 0.18), transparent 32%),
    #f8fafc;
  padding: 24px;
}

.login-card {
  width: 100%;
  max-width: 460px;
  background: rgba(255, 255, 255, 0.94);
  border-radius: 26px;
  padding: 32px;
  box-shadow: 0 26px 80px rgba(15, 23, 42, 0.14);
}

.login-language {
  display: flex;
  justify-content: flex-end;
  margin-bottom: 12px;
}

.login-heading {
  margin-bottom: 18px;
}

.login-heading h1 {
  margin: 12px 0 8px;
  font-size: 32px;
}

.login-heading p {
  color: #64748b;
  margin: 0;
  line-height: 1.6;
}

.login-badge {
  display: inline-flex;
  padding: 6px 12px;
  border-radius: 999px;
  background: #dbeafe;
  color: #1d4ed8;
  font-size: 12px;
  font-weight: 700;
}

.qr-login-pane {
  display: grid;
  gap: 12px;
}

.seed-tip {
  margin-top: 18px;
  padding: 14px 16px;
  border-radius: 16px;
  background: #f8fafc;
  color: #64748b;
  line-height: 1.8;
}
</style>
