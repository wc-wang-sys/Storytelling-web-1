<template>
  <div class="page-card">
    <div class="toolbar">
      <div class="toolbar-left">
        <el-select v-model="filters.schoolId" clearable :placeholder="$t('common.filters.school')" @change="handleSchoolChange">
          <el-option v-for="school in schools" :key="school.id" :label="school.name" :value="school.id"></el-option>
        </el-select>
      </div>
      <div class="toolbar-right">
        <el-button type="primary" @click="openDialog()">{{ $t('teachers.add') }}</el-button>
      </div>
    </div>

    <data-table :loading="loading" :rows="rows" :columns="tableColumns">
      <template slot="cell-classes" slot-scope="{ row }">
        <div class="tag-list">
          <el-tag v-for="classId in row.classIds" :key="classId" size="mini">
            {{ className(classId) }}
          </el-tag>
          <span v-if="!row.classIds || !row.classIds.length">-</span>
        </div>
      </template>
      <template slot="cell-status" slot-scope="{ row }">
        <span :class="['status-tag', row.status === 'active' ? 'status-active' : 'status-disabled']">
          {{ statusLabel(row.status) }}
        </span>
      </template>
      <template slot="cell-actions" slot-scope="{ row }">
        <div class="table-actions">
          <el-button size="mini" @click="openDialog(row)">{{ $t('common.buttons.edit') }}</el-button>
          <el-button size="mini" @click="openQr(row)">{{ $t('common.buttons.qrCode') }}</el-button>
          <el-button size="mini" type="danger" plain @click="handleDelete(row)">{{ $t('common.buttons.delete') }}</el-button>
        </div>
      </template>
    </data-table>

    <el-dialog :visible.sync="dialogVisible" :title="editingId ? $t('teachers.edit') : $t('teachers.add')" width="660px">
      <el-form :model="form" label-width="110px">
        <el-form-item :label="$t('teachers.fields.school')">
          <el-select v-model="form.schoolId" @change="loadClasses">
            <el-option v-for="school in schools" :key="school.id" :label="school.name" :value="school.id"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item :label="$t('teachers.fields.name')">
          <el-input v-model.trim="form.name"></el-input>
        </el-form-item>
        <el-form-item :label="$t('teachers.fields.email')">
          <el-input v-model.trim="form.email"></el-input>
        </el-form-item>
        <el-form-item :label="$t('teachers.fields.phone')">
          <el-input v-model.trim="form.phone"></el-input>
        </el-form-item>
        <el-form-item :label="$t('teachers.fields.username')">
          <el-input v-model.trim="form.username"></el-input>
        </el-form-item>
        <el-form-item :label="$t('teachers.fields.password')">
          <el-input v-model.trim="form.password" show-password :placeholder="$t('common.placeholders.passwordOptional')"></el-input>
        </el-form-item>
        <el-form-item :label="$t('teachers.fields.classIds')">
          <el-select v-model="form.classIds" multiple collapse-tags style="width: 100%">
            <el-option v-for="item in availableClasses" :key="item.id" :label="item.name" :value="item.id"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item :label="$t('common.table.status')">
          <el-select v-model="form.status">
            <el-option :label="$t('common.status.active')" value="active"></el-option>
            <el-option :label="$t('common.status.disabled')" value="disabled"></el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <span slot="footer">
        <el-button @click="dialogVisible = false">{{ $t('common.buttons.cancel') }}</el-button>
        <el-button type="primary" :loading="submitting" @click="submitForm">{{ $t('common.buttons.save') }}</el-button>
      </span>
    </el-dialog>

    <qr-code-dialog
      v-if="qrTarget"
      v-model="qrVisible"
      :title="$t('common.qr.loginTitle', { name: qrTarget.name })"
      entity-type="teacher"
      :entity-id="qrTarget.id"
    />
  </div>
</template>

<script>
import {
  createTeacher,
  deleteTeacher,
  fetchClasses,
  fetchSchools,
  fetchTeachers,
  updateTeacher,
} from '../../api/services';
import DataTable from '../../components/DataTable.vue';
import { getCachedUser } from '../../utils/auth';
import QrCodeDialog from '../../components/QrCodeDialog.vue';

const emptyForm = (schoolId = '') => ({
  schoolId,
  name: '',
  email: '',
  phone: '',
  username: '',
  password: '',
  classIds: [],
  status: 'active',
});

export default {
  name: 'TeachersIndex',
  components: { DataTable, QrCodeDialog },
  data() {
    const currentUser = getCachedUser();
    const schoolId = currentUser && currentUser.backendRole === 'school_admin' ? currentUser.schoolId : '';
    return {
      currentUser,
      loading: false,
      submitting: false,
      dialogVisible: false,
      qrVisible: false,
      qrTarget: null,
      editingId: '',
      rows: [],
      schools: [],
      availableClasses: [],
      filters: { schoolId },
      form: emptyForm(schoolId),
    };
  },
  computed: {
    tableColumns() {
      return [
        { key: 'name', prop: 'name', label: this.$t('teachers.columns.name'), minWidth: 160 },
        { key: 'username', prop: 'username', label: this.$t('teachers.columns.username'), width: 160 },
        { key: 'email', prop: 'email', label: this.$t('teachers.columns.email'), minWidth: 180 },
        { key: 'phone', prop: 'phone', label: this.$t('teachers.columns.phone'), width: 140 },
        { key: 'classes', label: this.$t('teachers.columns.classes'), minWidth: 220 },
        { key: 'status', label: this.$t('common.table.status'), width: 120, align: 'center' },
        { key: 'actions', label: this.$t('common.table.actions'), width: 260 },
      ];
    },
  },
  created() {
    this.loadSchools();
    this.loadRows();
    if (this.filters.schoolId) {
      this.loadClasses(this.filters.schoolId);
    }
  },
  methods: {
    statusLabel(status) {
      return this.$t(`common.status.${status}`);
    },
    className(id) {
      const item = this.availableClasses.find((entry) => entry.id === id);
      return item ? item.name : id;
    },
    async loadSchools() {
      try {
        this.schools = await fetchSchools();
      } catch (error) {
        this.$message.error(error.message);
      }
    },
    async loadClasses(schoolId = this.form.schoolId || this.filters.schoolId) {
      try {
        this.availableClasses = await fetchClasses(schoolId ? { schoolId } : {});
      } catch (error) {
        this.$message.error(error.message);
      }
    },
    async loadRows() {
      this.loading = true;
      try {
        const params = this.filters.schoolId ? { schoolId: this.filters.schoolId } : {};
        this.rows = await fetchTeachers(params);
      } catch (error) {
        this.$message.error(error.message);
      } finally {
        this.loading = false;
      }
    },
    handleSchoolChange() {
      this.loadClasses(this.filters.schoolId);
      this.loadRows();
    },
    openDialog(row) {
      this.editingId = row ? row.id : '';
      this.form = row
        ? {
            schoolId: row.schoolId,
            name: row.name,
            email: row.email,
            phone: row.phone,
            username: row.username,
            password: '',
            classIds: row.classIds || [],
            status: row.status,
          }
        : emptyForm(this.filters.schoolId || (this.currentUser && this.currentUser.schoolId) || '');
      this.loadClasses(this.form.schoolId);
      this.dialogVisible = true;
    },
    async submitForm() {
      this.submitting = true;
      try {
        if (this.editingId) {
          await updateTeacher(this.editingId, this.form);
        } else {
          await createTeacher(this.form);
        }
        this.dialogVisible = false;
        this.$message.success(this.$t('common.messages.saveSuccess'));
        this.loadRows();
      } catch (error) {
        this.$message.error(error.message);
      } finally {
        this.submitting = false;
      }
    },
    async handleDelete(row) {
      try {
        await this.$confirm(this.$t('teachers.deleteConfirm', { name: row.name }), this.$t('common.notice'), { type: 'warning' });
        await deleteTeacher(row.id);
        this.$message.success(this.$t('common.messages.deleteSuccess'));
        this.loadRows();
      } catch (error) {
        if (error && error.message !== 'cancel') {
          this.$message.error(error.message);
        }
      }
    },
    openQr(row) {
      this.qrTarget = row;
      this.qrVisible = true;
    },
  },
};
</script>

<style scoped>
.table-actions,
.tag-list {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}
</style>
