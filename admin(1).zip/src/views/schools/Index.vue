<template>
  <div class="page-card">
    <div class="toolbar">
      <div>
        <h2 style="margin: 0">{{ $t('schools.title') }}</h2>
        <p style="margin: 8px 0 0; color: #64748b">{{ $t('schools.subtitle') }}</p>
      </div>
      <el-button v-if="canCreate" type="primary" @click="openDialog()">{{ $t('schools.add') }}</el-button>
    </div>

    <data-table :loading="loading" :rows="rows" :columns="tableColumns">
      <template slot="cell-status" slot-scope="{ row }">
        <span :class="['status-tag', row.status === 'active' ? 'status-active' : 'status-disabled']">
          {{ statusLabel(row.status) }}
        </span>
      </template>
      <template slot="cell-actions" slot-scope="{ row }">
        <div class="table-actions">
          <el-button size="mini" @click="openDialog(row)">{{ $t('common.buttons.edit') }}</el-button>
          <el-button size="mini" @click="openQr(row)">{{ $t('common.buttons.qrCode') }}</el-button>
          <el-button v-if="canDelete" size="mini" type="danger" plain @click="handleDelete(row)">{{ $t('common.buttons.delete') }}</el-button>
        </div>
      </template>
    </data-table>

    <el-dialog :visible.sync="dialogVisible" :title="editingId ? $t('schools.edit') : $t('schools.add')" width="680px">
      <el-form :model="form" label-width="110px">
        <el-form-item :label="$t('schools.fields.name')">
          <el-input v-model.trim="form.name"></el-input>
        </el-form-item>
        <el-form-item :label="$t('schools.fields.code')">
          <el-input v-model.trim="form.code"></el-input>
        </el-form-item>
        <el-form-item :label="$t('schools.fields.address')">
          <el-input v-model.trim="form.address"></el-input>
        </el-form-item>
        <el-form-item :label="$t('schools.fields.contactName')">
          <el-input v-model.trim="form.contactName"></el-input>
        </el-form-item>
        <el-form-item :label="$t('schools.fields.contactPhone')">
          <el-input v-model.trim="form.contactPhone"></el-input>
        </el-form-item>
        <el-form-item :label="$t('schools.fields.adminDisplayName')">
          <el-input v-model.trim="form.adminDisplayName"></el-input>
        </el-form-item>
        <el-form-item :label="$t('schools.fields.adminUsername')">
          <el-input v-model.trim="form.adminUsername"></el-input>
        </el-form-item>
        <el-form-item :label="$t('schools.fields.adminPassword')">
          <el-input v-model.trim="form.adminPassword" show-password :placeholder="$t('common.placeholders.passwordOptional')"></el-input>
        </el-form-item>
        <el-form-item :label="$t('common.table.status')">
          <el-select v-model="form.status">
            <el-option :label="$t('common.status.active')" value="active"></el-option>
            <el-option :label="$t('common.status.disabled')" value="disabled"></el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <span slot="footer">
        <el-button @click="dialogVisible = false">{{ $t('common.buttons.cancel') }}</el-button>
        <el-button type="primary" :loading="submitting" @click="submitForm">{{ $t('common.buttons.save') }}</el-button>
      </span>
    </el-dialog>

    <qr-code-dialog
      v-if="qrTarget"
      v-model="qrVisible"
      :title="$t('common.qr.loginTitle', { name: qrTarget.name })"
      entity-type="school"
      :entity-id="qrTarget.id"
    />
  </div>
</template>

<script>
import { createSchool, deleteSchool, fetchSchools, updateSchool } from '../../api/services';
import DataTable from '../../components/DataTable.vue';
import { getCachedUser } from '../../utils/auth';
import QrCodeDialog from '../../components/QrCodeDialog.vue';

const emptyForm = () => ({
  name: '',
  code: '',
  address: '',
  contactName: '',
  contactPhone: '',
  adminDisplayName: '',
  adminUsername: '',
  adminPassword: '',
  status: 'active',
});

export default {
  name: 'SchoolsIndex',
  components: { DataTable, QrCodeDialog },
  data() {
    return {
      loading: false,
      submitting: false,
      dialogVisible: false,
      qrVisible: false,
      qrTarget: null,
      editingId: '',
      rows: [],
      form: emptyForm(),
      currentUser: getCachedUser(),
    };
  },
  computed: {
    canCreate() {
      return this.currentUser && this.currentUser.backendRole === 'super_admin';
    },
    canDelete() {
      return this.canCreate;
    },
    tableColumns() {
      return [
        { key: 'name', prop: 'name', label: this.$t('schools.columns.name'), minWidth: 180 },
        { key: 'code', prop: 'code', label: this.$t('schools.columns.code'), width: 140 },
        { key: 'address', prop: 'address', label: this.$t('schools.columns.address'), minWidth: 200 },
        { key: 'adminDisplayName', prop: 'adminDisplayName', label: this.$t('schools.columns.adminDisplayName'), width: 140 },
        { key: 'adminUsername', prop: 'adminUsername', label: this.$t('schools.columns.adminUsername'), width: 160 },
        { key: 'status', label: this.$t('common.table.status'), width: 120, align: 'center' },
        { key: 'actions', label: this.$t('common.table.actions'), width: 260 },
      ];
    },
  },
  created() {
    this.loadRows();
  },
  methods: {
    statusLabel(status) {
      return this.$t(`common.status.${status}`);
    },
    async loadRows() {
      this.loading = true;
      try {
        this.rows = await fetchSchools();
      } catch (error) {
        this.$message.error(error.message);
      } finally {
        this.loading = false;
      }
    },
    openDialog(row) {
      this.editingId = row ? row.id : '';
      this.form = row
        ? {
            name: row.name,
            code: row.code,
            address: row.address,
            contactName: row.contactName,
            contactPhone: row.contactPhone,
            adminDisplayName: row.adminDisplayName,
            adminUsername: row.adminUsername,
            adminPassword: '',
            status: row.status,
          }
        : emptyForm();
      this.dialogVisible = true;
    },
    async submitForm() {
      this.submitting = true;
      try {
        if (this.editingId) {
          await updateSchool(this.editingId, this.form);
        } else {
          await createSchool(this.form);
        }
        this.dialogVisible = false;
        this.$message.success(this.$t('common.messages.saveSuccess'));
        this.loadRows();
      } catch (error) {
        this.$message.error(error.message);
      } finally {
        this.submitting = false;
      }
    },
    async handleDelete(row) {
      try {
        await this.$confirm(this.$t('schools.deleteConfirm', { name: row.name }), this.$t('common.notice'), { type: 'warning' });
        await deleteSchool(row.id);
        this.$message.success(this.$t('common.messages.deleteSuccess'));
        this.loadRows();
      } catch (error) {
        if (error && error.message !== 'cancel') {
          this.$message.error(error.message);
        }
      }
    },
    openQr(row) {
      this.qrTarget = row;
      this.qrVisible = true;
    },
  },
};
</script>

<style scoped>
.table-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}
</style>
