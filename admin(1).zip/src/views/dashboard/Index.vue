<template>
  <div class="page-card">
    <div class="toolbar">
      <div>
        <h2 style="margin: 0">{{ $t('dashboard.title') }}</h2>
        <p style="margin: 8px 0 0; color: #64748b">{{ $t('dashboard.subtitle') }}</p>
      </div>
      <el-button type="primary" @click="loadStats">{{ $t('common.buttons.refresh') }}</el-button>
    </div>

    <div class="metric-grid" v-loading="loading">
      <div class="metric-card metric-purple">
        <h3>{{ $t('dashboard.metrics.schools') }}</h3>
        <div class="metric-value">{{ stats.schoolCount || 0 }}</div>
      </div>
      <div class="metric-card metric-green">
        <h3>{{ $t('dashboard.metrics.classes') }}</h3>
        <div class="metric-value">{{ stats.classCount || 0 }}</div>
      </div>
      <div class="metric-card metric-orange">
        <h3>{{ $t('dashboard.metrics.teachers') }}</h3>
        <div class="metric-value">{{ stats.teacherCount || 0 }}</div>
      </div>
      <div class="metric-card metric-pink">
        <h3>{{ $t('dashboard.metrics.stories') }}</h3>
        <div class="metric-value">{{ stats.storyCount || 0 }}</div>
      </div>
    </div>
  </div>
</template>

<script>
import { fetchDashboardStats } from '../../api/services';

export default {
  name: 'DashboardIndex',
  data() {
    return {
      loading: false,
      stats: {},
    };
  },
  created() {
    this.loadStats();
  },
  methods: {
    async loadStats() {
      this.loading = true;
      try {
        this.stats = await fetchDashboardStats();
      } catch (error) {
        this.$message.error(error.message);
      } finally {
        this.loading = false;
      }
    },
  },
};
</script>
