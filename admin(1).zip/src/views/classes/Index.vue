<template>
  <div class="page-card">
    <div class="toolbar">
      <div class="toolbar-left">
        <el-select v-model="filters.schoolId" clearable :placeholder="$t('common.filters.school')" @change="loadRows">
          <el-option v-for="school in schools" :key="school.id" :label="school.name" :value="school.id"></el-option>
        </el-select>
      </div>
      <div class="toolbar-right">
        <el-button type="primary" @click="openDialog()">{{ $t('classes.add') }}</el-button>
      </div>
    </div>

    <data-table :loading="loading" :rows="rows" :columns="tableColumns">
      <template slot="cell-school" slot-scope="{ row }">{{ schoolName(row.schoolId) }}</template>
      <template slot="cell-status" slot-scope="{ row }">
        <span :class="['status-tag', row.status === 'active' ? 'status-active' : 'status-disabled']">
          {{ statusLabel(row.status) }}
        </span>
      </template>
      <template slot="cell-actions" slot-scope="{ row }">
        <div class="table-actions">
          <el-button size="mini" @click="openDialog(row)">{{ $t('common.buttons.edit') }}</el-button>
          <el-button size="mini" type="danger" plain @click="handleDelete(row)">{{ $t('common.buttons.delete') }}</el-button>
        </div>
      </template>
    </data-table>

    <el-dialog :visible.sync="dialogVisible" :title="editingId ? $t('classes.edit') : $t('classes.add')" width="560px">
      <el-form :model="form" label-width="100px">
        <el-form-item :label="$t('classes.fields.school')">
          <el-select v-model="form.schoolId" :placeholder="$t('common.placeholders.selectSchool')">
            <el-option v-for="school in schools" :key="school.id" :label="school.name" :value="school.id"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item :label="$t('classes.fields.name')">
          <el-input v-model.trim="form.name"></el-input>
        </el-form-item>
        <el-form-item :label="$t('classes.fields.grade')">
          <el-select v-model="form.grade">
            <el-option label="K1" value="K1"></el-option>
            <el-option label="K2" value="K2"></el-option>
            <el-option label="K3" value="K3"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item :label="$t('classes.fields.description')">
          <el-input v-model.trim="form.description"></el-input>
        </el-form-item>
        <el-form-item :label="$t('common.table.status')">
          <el-select v-model="form.status">
            <el-option :label="$t('common.status.active')" value="active"></el-option>
            <el-option :label="$t('common.status.disabled')" value="disabled"></el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <span slot="footer">
        <el-button @click="dialogVisible = false">{{ $t('common.buttons.cancel') }}</el-button>
        <el-button type="primary" :loading="submitting" @click="submitForm">{{ $t('common.buttons.save') }}</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import { createClass, deleteClass, fetchClasses, fetchSchools, updateClass } from '../../api/services';
import DataTable from '../../components/DataTable.vue';
import { getCachedUser } from '../../utils/auth';

const emptyForm = (schoolId = '') => ({
  schoolId,
  name: '',
  grade: 'K1',
  description: '',
  status: 'active',
});

export default {
  name: 'ClassesIndex',
  components: { DataTable },
  data() {
    const currentUser = getCachedUser();
    return {
      currentUser,
      loading: false,
      submitting: false,
      dialogVisible: false,
      editingId: '',
      schools: [],
      rows: [],
      filters: {
        schoolId: currentUser && currentUser.backendRole === 'school_admin' ? currentUser.schoolId : '',
      },
      form: emptyForm(currentUser && currentUser.backendRole === 'school_admin' ? currentUser.schoolId : ''),
    };
  },
  computed: {
    tableColumns() {
      return [
        { key: 'name', prop: 'name', label: this.$t('classes.columns.name'), minWidth: 160 },
        { key: 'grade', prop: 'grade', label: this.$t('classes.columns.grade'), width: 120, align: 'center' },
        { key: 'school', label: this.$t('classes.columns.school'), minWidth: 180 },
        { key: 'description', prop: 'description', label: this.$t('classes.columns.description'), minWidth: 220 },
        { key: 'status', label: this.$t('common.table.status'), width: 120, align: 'center' },
        { key: 'actions', label: this.$t('common.table.actions'), width: 180 },
      ];
    },
  },
  created() {
    this.loadSchools();
    this.loadRows();
  },
  methods: {
    statusLabel(status) {
      return this.$t(`common.status.${status}`);
    },
    schoolName(id) {
      const school = this.schools.find((item) => item.id === id);
      return school ? school.name : '-';
    },
    async loadSchools() {
      try {
        this.schools = await fetchSchools();
      } catch (error) {
        this.$message.error(error.message);
      }
    },
    async loadRows() {
      this.loading = true;
      try {
        this.rows = await fetchClasses(this.filters.schoolId ? { schoolId: this.filters.schoolId } : {});
      } catch (error) {
        this.$message.error(error.message);
      } finally {
        this.loading = false;
      }
    },
    openDialog(row) {
      this.editingId = row ? row.id : '';
      this.form = row
        ? { schoolId: row.schoolId, name: row.name, grade: row.grade, description: row.description, status: row.status }
        : emptyForm(this.filters.schoolId || (this.currentUser && this.currentUser.schoolId) || '');
      this.dialogVisible = true;
    },
    async submitForm() {
      this.submitting = true;
      try {
        if (this.editingId) {
          await updateClass(this.editingId, this.form);
        } else {
          await createClass(this.form);
        }
        this.dialogVisible = false;
        this.$message.success(this.$t('common.messages.saveSuccess'));
        this.loadRows();
      } catch (error) {
        this.$message.error(error.message);
      } finally {
        this.submitting = false;
      }
    },
    async handleDelete(row) {
      try {
        await this.$confirm(this.$t('classes.deleteConfirm', { name: row.name }), this.$t('common.notice'), { type: 'warning' });
        await deleteClass(row.id);
        this.$message.success(this.$t('common.messages.deleteSuccess'));
        this.loadRows();
      } catch (error) {
        if (error && error.message !== 'cancel') {
          this.$message.error(error.message);
        }
      }
    },
  },
};
</script>

<style scoped>
.table-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}
</style>
