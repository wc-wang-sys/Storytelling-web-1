import Vue from 'vue';
import elementLocale from 'element-ui/lib/locale';
import elementEn from 'element-ui/lib/locale/lang/en';
import elementZhCn from 'element-ui/lib/locale/lang/zh-CN';
import elementZhTw from 'element-ui/lib/locale/lang/zh-TW';

export const STORAGE_KEY = 'storybuddy_language';
export const languages = ['zh-CN', 'zh-HK', 'en'];

export const languageNames = {
  'zh-CN': '简体中文',
  'zh-HK': '繁體中文',
  en: 'English',
};

const messages = {
  'zh-CN': {
    common: {
      notice: '提示',
      languages: {
        'zh-CN': '简体中文',
        'zh-HK': '繁體中文',
        en: 'English',
      },
      buttons: {
        refresh: '刷新',
        add: '新增',
        save: '保存',
        cancel: '取消',
        edit: '编辑',
        delete: '删除',
        logout: '退出',
        qrCode: '二维码',
        viewEdit: '查看/编辑',
        openScanner: '打开扫码器',
        useTokenLogin: '使用 Token 登录',
        manualPaste: '手动粘贴 Token',
        restoreDefault: '恢复默认',
        editImageSource: '编辑图片源',
        collapseImageSource: '收起图片源',
        addPage: '新增页面',
        deletePage: '删除本页',
      },
      table: {
        empty: '暂无数据',
        status: '状态',
        actions: '操作',
      },
      status: {
        active: '启用',
        disabled: '停用',
        draft: '草稿',
        published: '发布',
        archived: '归档',
      },
      fields: {
        school: '学校',
        class: '班级',
        teacher: '教师',
        student: '学生',
        title: '标题',
        cover: '封面',
        createdAt: '创建时间',
        name: '名称',
        code: '编码',
        address: '地址',
        description: '说明',
        email: '邮箱',
        phone: '电话',
        username: '登录账号',
        password: '登录密码',
        studentNo: '学号',
        ageGroup: '年龄段',
        storyTime: '故事时间',
        category: '分类',
        variables: '变量',
        promptKey: 'Prompt Key',
        defaultTemplate: '默认模板',
        currentTemplate: '当前模板',
        type: '类型',
        entityId: '实体 ID',
        expiresAt: '失效时间',
      },
      filters: {
        school: '筛选学校',
        class: '筛选班级',
        student: '筛选学生',
        schoolShort: '学校',
        classShort: '班级',
        studentShort: '学生',
        searchStories: '搜索标题/作者',
      },
      placeholders: {
        username: '请输入用户名',
        password: '请输入密码',
        qrToken: '如果浏览器无法直接识别，也可以粘贴二维码 token',
        passwordOptional: '编辑时留空表示不修改',
        selectSchool: '请选择学校',
        imageSource: '请输入图片 URL 或 data:image/... base64 内容',
        imagePrompt: '图片提示词',
        pageText: '页面文本',
      },
      qr: {
        title: '二维码',
        loginTitle: '{{name}} 登录二维码',
        school: '学校',
        teacher: '教师',
        student: '学生',
      },
      messages: {
        saveSuccess: '保存成功',
        deleteSuccess: '删除成功',
        enterUsernamePassword: '请输入用户名和密码',
        pasteQrToken: '请先粘贴二维码 token',
        cameraError: '无法访问摄像头，请检查浏览器权限。',
        qrHint: '将二维码放入框内，浏览器支持 BarcodeDetector 时会自动识别。',
        placeholderTip: '变量占位符请保持双大括号格式，例如 {{ageGroup}}。',
        noCoverImage: '暂无封面图',
        noPageImage: '暂无页面图片',
        noImageData: '当前没有图片数据',
        base64ImageSummary: '当前为 Base64 图片数据，已正常预览，约 {{size}} KB',
      },
    },
    layout: {
      brandTitle: 'Storytelling',
      brandSubtitle: 'Admin Console',
      language: '语言',
      platformSpace: '平台管理空间',
      menu: {
        dashboard: '仪表盘',
        schools: '学校',
        classes: '班级',
        teachers: '教师',
        students: '学生',
        stories: '故事作品',
        prompts: 'Prompt 配置',
      },
      pageTitles: {
        dashboard: '仪表盘',
        schools: '学校管理',
        classes: '班级管理',
        teachers: '教师管理',
        students: '学生管理',
        stories: '故事管理',
        prompts: 'Prompt 配置',
        fallback: '管理后台',
      },
      roles: {
        super_admin: '平台管理员',
        school_admin: '学校管理员',
        teacher: '教师',
        student: '学生',
      },
    },
    login: {
      badge: 'Storytelling',
      title: '管理后台登录',
      subtitle: '学校管理员、教师和平台管理员都可以使用密码或二维码登录。',
      tabs: {
        password: '密码登录',
        qr: '二维码登录',
      },
      fields: {
        username: '用户名',
        password: '密码',
      },
      demoAccounts: '演示账号：',
    },
    dashboard: {
      title: '系统概览',
      subtitle: '按当前登录身份展示可见范围内的学校、教师、学生和作品数量。',
      metrics: {
        schools: '学校',
        classes: '班级',
        teachers: '教师',
        stories: '故事作品',
      },
    },
    schools: {
      title: '学校管理',
      subtitle: '创建学校和学校管理员账号，并生成学校级二维码。',
      add: '新增学校',
      edit: '编辑学校',
      deleteConfirm: '确认删除学校“{{name}}”吗？',
      columns: {
        name: '学校名称',
        code: '编码',
        address: '地址',
        adminDisplayName: '学校管理员',
        adminUsername: '管理员账号',
      },
      fields: {
        name: '学校名称',
        code: '学校编码',
        address: '地址',
        contactName: '联系人',
        contactPhone: '联系电话',
        adminDisplayName: '管理员姓名',
        adminUsername: '管理员账号',
        adminPassword: '管理员密码',
      },
    },
    classes: {
      add: '新增班级',
      edit: '编辑班级',
      deleteConfirm: '确认删除班级“{{name}}”吗？',
      columns: {
        name: '班级名称',
        grade: '年级',
        school: '学校',
        description: '说明',
      },
      fields: {
        school: '学校',
        name: '班级名称',
        grade: '年级',
        description: '说明',
      },
    },
    teachers: {
      add: '新增教师',
      edit: '编辑教师',
      deleteConfirm: '确认删除教师“{{name}}”吗？',
      columns: {
        name: '教师姓名',
        username: '登录账号',
        email: '邮箱',
        phone: '电话',
        classes: '班级',
      },
      fields: {
        school: '所属学校',
        name: '教师姓名',
        email: '邮箱',
        phone: '电话',
        username: '登录账号',
        password: '登录密码',
        classIds: '负责班级',
      },
    },
    students: {
      add: '新增学生',
      edit: '编辑学生',
      deleteConfirm: '确认删除学生“{{name}}”吗？',
      columns: {
        name: '学生姓名',
        studentNo: '学号',
        username: '登录账号',
        school: '学校',
        class: '班级',
        teacher: '教师',
        ageGroup: '年龄段',
      },
      fields: {
        school: '所属学校',
        class: '所属班级',
        teacher: '班级教师',
        name: '学生姓名',
        studentNo: '学号',
        ageGroup: '年龄段',
        username: '登录账号',
        password: '登录密码',
      },
    },
    stories: {
      edit: '编辑故事',
      deleteConfirm: '确认删除故事“{{title}}”吗？',
      columns: {
        cover: '封面',
        title: '标题',
        student: '学生',
        class: '班级',
        school: '学校',
        createdAt: '创建时间',
      },
      sections: {
        pages: '故事页面',
      },
      fields: {
        title: '标题',
        cover: '封面图',
        time: '故事时间',
        status: '状态',
      },
      pageLabel: '第 {{index}} 页',
    },
    prompts: {
      title: 'Prompt 配置',
      subtitle: '这里集中管理学生端/教师端实际使用的 AI Prompt、语音输入模板和生成失败兜底模板。修改后，新的生成请求会读取最新配置。',
      edit: '编辑 Prompt',
      columns: {
        title: 'Prompt 名称',
        key: 'Key',
        category: '分类',
        variables: '变量',
        updatedAt: '更新时间',
      },
    },
    qrScanner: {
      title: '二维码登录',
      manualPastePrompt: '粘贴二维码 token',
    },
  },
  'zh-HK': {
    common: {
      notice: '提示',
      languages: {
        'zh-CN': '简体中文',
        'zh-HK': '繁體中文',
        en: 'English',
      },
      buttons: {
        refresh: '重新整理',
        add: '新增',
        save: '儲存',
        cancel: '取消',
        edit: '編輯',
        delete: '刪除',
        logout: '登出',
        qrCode: '二維碼',
        viewEdit: '查看/編輯',
        openScanner: '開啟掃碼器',
        useTokenLogin: '使用 Token 登入',
        manualPaste: '手動貼上 Token',
        restoreDefault: '還原預設',
        editImageSource: '編輯圖片來源',
        collapseImageSource: '收起圖片來源',
        addPage: '新增頁面',
        deletePage: '刪除此頁',
      },
      table: {
        empty: '暫無資料',
        status: '狀態',
        actions: '操作',
      },
      status: {
        active: '啟用',
        disabled: '停用',
        draft: '草稿',
        published: '發佈',
        archived: '封存',
      },
      fields: {
        school: '學校',
        class: '班級',
        teacher: '教師',
        student: '學生',
        title: '標題',
        cover: '封面',
        createdAt: '建立時間',
        name: '名稱',
        code: '編碼',
        address: '地址',
        description: '說明',
        email: '電郵',
        phone: '電話',
        username: '登入帳號',
        password: '登入密碼',
        studentNo: '學號',
        ageGroup: '年齡組別',
        storyTime: '故事時間',
        category: '分類',
        variables: '變量',
        promptKey: 'Prompt Key',
        defaultTemplate: '預設模板',
        currentTemplate: '目前模板',
        type: '類型',
        entityId: '實體 ID',
        expiresAt: '失效時間',
      },
      filters: {
        school: '篩選學校',
        class: '篩選班級',
        student: '篩選學生',
        schoolShort: '學校',
        classShort: '班級',
        studentShort: '學生',
        searchStories: '搜尋標題/作者',
      },
      placeholders: {
        username: '請輸入用戶名',
        password: '請輸入密碼',
        qrToken: '如果瀏覽器無法直接識別，也可以貼上二維碼 token',
        passwordOptional: '編輯時留空表示不修改',
        selectSchool: '請選擇學校',
        imageSource: '請輸入圖片 URL 或 data:image/... base64 內容',
        imagePrompt: '圖片提示詞',
        pageText: '頁面文字',
      },
      qr: {
        title: '二維碼',
        loginTitle: '{{name}} 登入二維碼',
        school: '學校',
        teacher: '教師',
        student: '學生',
      },
      messages: {
        saveSuccess: '儲存成功',
        deleteSuccess: '刪除成功',
        enterUsernamePassword: '請輸入用戶名和密碼',
        pasteQrToken: '請先貼上二維碼 token',
        cameraError: '無法存取鏡頭，請檢查瀏覽器權限。',
        qrHint: '將二維碼放入框內，瀏覽器支援 BarcodeDetector 時會自動識別。',
        placeholderTip: '變量佔位符請保持雙大括號格式，例如 {{ageGroup}}。',
        noCoverImage: '暫無封面圖',
        noPageImage: '暫無頁面圖片',
        noImageData: '目前沒有圖片資料',
        base64ImageSummary: '目前為 Base64 圖片資料，已正常預覽，約 {{size}} KB',
      },
    },
    layout: {
      brandTitle: 'Storytelling',
      brandSubtitle: 'Admin Console',
      language: '語言',
      platformSpace: '平台管理空間',
      menu: {
        dashboard: '儀表板',
        schools: '學校',
        classes: '班級',
        teachers: '教師',
        students: '學生',
        stories: '故事作品',
        prompts: 'Prompt 設定',
      },
      pageTitles: {
        dashboard: '儀表板',
        schools: '學校管理',
        classes: '班級管理',
        teachers: '教師管理',
        students: '學生管理',
        stories: '故事管理',
        prompts: 'Prompt 設定',
        fallback: '管理後台',
      },
      roles: {
        super_admin: '平台管理員',
        school_admin: '學校管理員',
        teacher: '教師',
        student: '學生',
      },
    },
    login: {
      badge: 'Storytelling',
      title: '管理後台登入',
      subtitle: '學校管理員、教師和平台管理員都可以使用密碼或二維碼登入。',
      tabs: {
        password: '密碼登入',
        qr: '二維碼登入',
      },
      fields: {
        username: '用戶名',
        password: '密碼',
      },
      demoAccounts: '示範帳號：',
    },
    dashboard: {
      title: '系統概覽',
      subtitle: '按目前登入身份顯示可見範圍內的學校、教師、學生和作品數量。',
      metrics: {
        schools: '學校',
        classes: '班級',
        teachers: '教師',
        stories: '故事作品',
      },
    },
    schools: {
      title: '學校管理',
      subtitle: '建立學校和學校管理員帳號，並生成學校級二維碼。',
      add: '新增學校',
      edit: '編輯學校',
      deleteConfirm: '確認刪除學校「{{name}}」嗎？',
      columns: {
        name: '學校名稱',
        code: '編碼',
        address: '地址',
        adminDisplayName: '學校管理員',
        adminUsername: '管理員帳號',
      },
      fields: {
        name: '學校名稱',
        code: '學校編碼',
        address: '地址',
        contactName: '聯絡人',
        contactPhone: '聯絡電話',
        adminDisplayName: '管理員姓名',
        adminUsername: '管理員帳號',
        adminPassword: '管理員密碼',
      },
    },
    classes: {
      add: '新增班級',
      edit: '編輯班級',
      deleteConfirm: '確認刪除班級「{{name}}」嗎？',
      columns: {
        name: '班級名稱',
        grade: '年級',
        school: '學校',
        description: '說明',
      },
      fields: {
        school: '學校',
        name: '班級名稱',
        grade: '年級',
        description: '說明',
      },
    },
    teachers: {
      add: '新增教師',
      edit: '編輯教師',
      deleteConfirm: '確認刪除教師「{{name}}」嗎？',
      columns: {
        name: '教師姓名',
        username: '登入帳號',
        email: '電郵',
        phone: '電話',
        classes: '班級',
      },
      fields: {
        school: '所屬學校',
        name: '教師姓名',
        email: '電郵',
        phone: '電話',
        username: '登入帳號',
        password: '登入密碼',
        classIds: '負責班級',
      },
    },
    students: {
      add: '新增學生',
      edit: '編輯學生',
      deleteConfirm: '確認刪除學生「{{name}}」嗎？',
      columns: {
        name: '學生姓名',
        studentNo: '學號',
        username: '登入帳號',
        school: '學校',
        class: '班級',
        teacher: '教師',
        ageGroup: '年齡組別',
      },
      fields: {
        school: '所屬學校',
        class: '所屬班級',
        teacher: '班級教師',
        name: '學生姓名',
        studentNo: '學號',
        ageGroup: '年齡組別',
        username: '登入帳號',
        password: '登入密碼',
      },
    },
    stories: {
      edit: '編輯故事',
      deleteConfirm: '確認刪除故事「{{title}}」嗎？',
      columns: {
        cover: '封面',
        title: '標題',
        student: '學生',
        class: '班級',
        school: '學校',
        createdAt: '建立時間',
      },
      sections: {
        pages: '故事頁面',
      },
      fields: {
        title: '標題',
        cover: '封面圖',
        time: '故事時間',
        status: '狀態',
      },
      pageLabel: '第 {{index}} 頁',
    },
    prompts: {
      title: 'Prompt 設定',
      subtitle: '這裡集中管理學生端/教師端實際使用的 AI Prompt、語音輸入模板和生成失敗兜底模板。修改後，新的生成請求會讀取最新設定。',
      edit: '編輯 Prompt',
      columns: {
        title: 'Prompt 名稱',
        key: 'Key',
        category: '分類',
        variables: '變量',
        updatedAt: '更新時間',
      },
    },
    qrScanner: {
      title: '二維碼登入',
      manualPastePrompt: '貼上二維碼 token',
    },
  },
  en: {
    common: {
      notice: 'Notice',
      languages: {
        'zh-CN': 'Simplified Chinese',
        'zh-HK': 'Traditional Chinese',
        en: 'English',
      },
      buttons: {
        refresh: 'Refresh',
        add: 'Add',
        save: 'Save',
        cancel: 'Cancel',
        edit: 'Edit',
        delete: 'Delete',
        logout: 'Log out',
        qrCode: 'QR Code',
        viewEdit: 'View/Edit',
        openScanner: 'Open Scanner',
        useTokenLogin: 'Log In with Token',
        manualPaste: 'Paste Token',
        restoreDefault: 'Restore Default',
        editImageSource: 'Edit Image Source',
        collapseImageSource: 'Hide Image Source',
        addPage: 'Add Page',
        deletePage: 'Delete Page',
      },
      table: {
        empty: 'No data',
        status: 'Status',
        actions: 'Actions',
      },
      status: {
        active: 'Active',
        disabled: 'Disabled',
        draft: 'Draft',
        published: 'Published',
        archived: 'Archived',
      },
      fields: {
        school: 'School',
        class: 'Class',
        teacher: 'Teacher',
        student: 'Student',
        title: 'Title',
        cover: 'Cover',
        createdAt: 'Created At',
        name: 'Name',
        code: 'Code',
        address: 'Address',
        description: 'Description',
        email: 'Email',
        phone: 'Phone',
        username: 'Username',
        password: 'Password',
        studentNo: 'Student ID',
        ageGroup: 'Age Group',
        storyTime: 'Story Time',
        category: 'Category',
        variables: 'Variables',
        promptKey: 'Prompt Key',
        defaultTemplate: 'Default Template',
        currentTemplate: 'Current Template',
        type: 'Type',
        entityId: 'Entity ID',
        expiresAt: 'Expires At',
      },
      filters: {
        school: 'Filter School',
        class: 'Filter Class',
        student: 'Filter Student',
        schoolShort: 'School',
        classShort: 'Class',
        studentShort: 'Student',
        searchStories: 'Search title/author',
      },
      placeholders: {
        username: 'Enter username',
        password: 'Enter password',
        qrToken: 'If the browser cannot scan directly, paste the QR token here',
        passwordOptional: 'Leave blank to keep the current password when editing',
        selectSchool: 'Please select a school',
        imageSource: 'Enter an image URL or data:image/... base64 content',
        imagePrompt: 'Image prompt',
        pageText: 'Page text',
      },
      qr: {
        title: 'QR Code',
        loginTitle: '{{name}} Login QR Code',
        school: 'School',
        teacher: 'Teacher',
        student: 'Student',
      },
      messages: {
        saveSuccess: 'Saved successfully',
        deleteSuccess: 'Deleted successfully',
        enterUsernamePassword: 'Please enter a username and password',
        pasteQrToken: 'Please paste a QR token first',
        cameraError: 'Unable to access the camera. Please check browser permissions.',
        qrHint: 'Place the QR code inside the frame. If BarcodeDetector is supported, it will be detected automatically.',
        placeholderTip: 'Keep variable placeholders in double braces, for example {{ageGroup}}.',
        noCoverImage: 'No cover image yet',
        noPageImage: 'No page image yet',
        noImageData: 'There is currently no image data',
        base64ImageSummary: 'The current image is Base64 data and is rendering correctly, about {{size}} KB',
      },
    },
    layout: {
      brandTitle: 'Storytelling',
      brandSubtitle: 'Admin Console',
      language: 'Language',
      platformSpace: 'Platform workspace',
      menu: {
        dashboard: 'Dashboard',
        schools: 'Schools',
        classes: 'Classes',
        teachers: 'Teachers',
        students: 'Students',
        stories: 'Stories',
        prompts: 'Prompt Config',
      },
      pageTitles: {
        dashboard: 'Dashboard',
        schools: 'School Management',
        classes: 'Class Management',
        teachers: 'Teacher Management',
        students: 'Student Management',
        stories: 'Story Management',
        prompts: 'Prompt Config',
        fallback: 'Admin Console',
      },
      roles: {
        super_admin: 'Platform Admin',
        school_admin: 'School Admin',
        teacher: 'Teacher',
        student: 'Student',
      },
    },
    login: {
      badge: 'Storytelling',
      title: 'Admin Login',
      subtitle: 'School admins, teachers, and platform admins can log in with a password or QR code.',
      tabs: {
        password: 'Password Login',
        qr: 'QR Login',
      },
      fields: {
        username: 'Username',
        password: 'Password',
      },
      demoAccounts: 'Demo accounts:',
    },
    dashboard: {
      title: 'System Overview',
      subtitle: 'Shows the number of schools, teachers, students, and stories visible to the current signed-in role.',
      metrics: {
        schools: 'Schools',
        classes: 'Classes',
        teachers: 'Teachers',
        stories: 'Stories',
      },
    },
    schools: {
      title: 'School Management',
      subtitle: 'Create schools and school admin accounts, then generate school-level QR codes.',
      add: 'Add School',
      edit: 'Edit School',
      deleteConfirm: 'Delete school "{{name}}"?',
      columns: {
        name: 'School Name',
        code: 'Code',
        address: 'Address',
        adminDisplayName: 'School Admin',
        adminUsername: 'Admin Username',
      },
      fields: {
        name: 'School Name',
        code: 'School Code',
        address: 'Address',
        contactName: 'Contact Name',
        contactPhone: 'Contact Phone',
        adminDisplayName: 'Admin Name',
        adminUsername: 'Admin Username',
        adminPassword: 'Admin Password',
      },
    },
    classes: {
      add: 'Add Class',
      edit: 'Edit Class',
      deleteConfirm: 'Delete class "{{name}}"?',
      columns: {
        name: 'Class Name',
        grade: 'Grade',
        school: 'School',
        description: 'Description',
      },
      fields: {
        school: 'School',
        name: 'Class Name',
        grade: 'Grade',
        description: 'Description',
      },
    },
    teachers: {
      add: 'Add Teacher',
      edit: 'Edit Teacher',
      deleteConfirm: 'Delete teacher "{{name}}"?',
      columns: {
        name: 'Teacher Name',
        username: 'Username',
        email: 'Email',
        phone: 'Phone',
        classes: 'Classes',
      },
      fields: {
        school: 'School',
        name: 'Teacher Name',
        email: 'Email',
        phone: 'Phone',
        username: 'Username',
        password: 'Password',
        classIds: 'Assigned Classes',
      },
    },
    students: {
      add: 'Add Student',
      edit: 'Edit Student',
      deleteConfirm: 'Delete student "{{name}}"?',
      columns: {
        name: 'Student Name',
        studentNo: 'Student ID',
        username: 'Username',
        school: 'School',
        class: 'Class',
        teacher: 'Teacher',
        ageGroup: 'Age Group',
      },
      fields: {
        school: 'School',
        class: 'Class',
        teacher: 'Class Teacher',
        name: 'Student Name',
        studentNo: 'Student ID',
        ageGroup: 'Age Group',
        username: 'Username',
        password: 'Password',
      },
    },
    stories: {
      edit: 'Edit Story',
      deleteConfirm: 'Delete story "{{title}}"?',
      columns: {
        cover: 'Cover',
        title: 'Title',
        student: 'Student',
        class: 'Class',
        school: 'School',
        createdAt: 'Created At',
      },
      sections: {
        pages: 'Story Pages',
      },
      fields: {
        title: 'Title',
        cover: 'Cover Image',
        time: 'Story Time',
        status: 'Status',
      },
      pageLabel: 'Page {{index}}',
    },
    prompts: {
      title: 'Prompt Config',
      subtitle: 'Manage the AI prompts, speech templates, and fallback templates used by the student and teacher apps. New generation requests will read the latest config after you save.',
      edit: 'Edit Prompt',
      columns: {
        title: 'Prompt Name',
        key: 'Key',
        category: 'Category',
        variables: 'Variables',
        updatedAt: 'Updated At',
      },
    },
    qrScanner: {
      title: 'QR Login',
      manualPastePrompt: 'Paste QR token',
    },
  },
};

const getStoredLanguage = () => {
  if (typeof window === 'undefined') {
    return 'zh-CN';
  }

  const saved = window.localStorage.getItem(STORAGE_KEY);
  return languages.includes(saved) ? saved : 'zh-CN';
};

const state = Vue.observable({
  language: getStoredLanguage(),
});

const resolveValue = (source, path) => {
  return path.split('.').reduce((current, segment) => {
    if (current && Object.prototype.hasOwnProperty.call(current, segment)) {
      return current[segment];
    }
    return undefined;
  }, source);
};

const interpolate = (value, vars = {}) => {
  return String(value).replace(/\{\{\s*([\w.]+)\s*\}\}/g, (match, key) => {
    return Object.prototype.hasOwnProperty.call(vars, key) ? vars[key] : match;
  });
};

const elementLocales = {
  'zh-CN': elementZhCn,
  'zh-HK': elementZhTw,
  en: elementEn,
};

const syncElementLocale = (language) => {
  elementLocale.use(elementLocales[language] || elementZhCn);
  if (typeof document !== 'undefined') {
    document.documentElement.lang = language;
  }
};

syncElementLocale(state.language);

export const setLanguage = (language) => {
  if (!languages.includes(language)) {
    return;
  }

  state.language = language;
  syncElementLocale(language);

  if (typeof window !== 'undefined') {
    window.localStorage.setItem(STORAGE_KEY, language);
  }
};

export const translate = (key, vars = {}) => {
  const value = resolveValue(messages[state.language], key);
  if (typeof value === 'string') {
    return interpolate(value, vars);
  }
  return value === undefined ? key : value;
};

export const i18nPlugin = {
  install(VueInstance) {
    VueInstance.mixin({
      computed: {
        $lang() {
          return state.language;
        },
        $languages() {
          return languages;
        },
        $messages() {
          return messages[state.language];
        },
      },
      methods: {
        $t(key, vars) {
          const value = resolveValue(this.$messages, key);
          if (typeof value === 'string') {
            return interpolate(value, vars);
          }
          return value === undefined ? key : value;
        },
        $setLanguage(language) {
          setLanguage(language);
        },
        $languageName(language) {
          const value = resolveValue(this.$messages, `common.languages.${language}`);
          return typeof value === 'string' ? value : languageNames[language] || language;
        },
      },
    });
  },
};

export default {
  messages,
  state,
  setLanguage,
  translate,
  i18nPlugin,
};
