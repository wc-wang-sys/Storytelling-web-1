<template>
  <el-dialog :visible.sync="dialogVisible" width="520px" :title="resolvedTitle" @open="loadCode">
    <div v-loading="loading" class="qr-dialog">
      <canvas ref="canvas" width="260" height="260"></canvas>
      <div class="qr-meta">
        <div><strong>{{ $t('common.fields.type') }}:</strong> {{ entityTypeLabel }}</div>
        <div><strong>{{ $t('common.fields.entityId') }}:</strong> {{ entityId }}</div>
        <div v-if="expiresAt"><strong>{{ $t('common.fields.expiresAt') }}:</strong> {{ formattedExpiresAt }}</div>
      </div>
      <el-input v-model="token" type="textarea" :rows="4" readonly></el-input>
    </div>
  </el-dialog>
</template>

<script>
import QRCode from 'qrcode';
import { generateQr } from '../api/services';

export default {
  name: 'QrCodeDialog',
  props: {
    value: {
      type: Boolean,
      default: false,
    },
    title: {
      type: String,
      default: '',
    },
    entityType: {
      type: String,
      required: true,
    },
    entityId: {
      type: String,
      required: true,
    },
  },
  data() {
    return {
      dialogVisible: this.value,
      loading: false,
      token: '',
      expiresAt: '',
    };
  },
  computed: {
    resolvedTitle() {
      return this.title || this.$t('common.qr.title');
    },
    entityTypeLabel() {
      const label = this.$t(`common.qr.${this.entityType}`);
      return label === `common.qr.${this.entityType}` ? this.entityType : label;
    },
    formattedExpiresAt() {
      if (!this.expiresAt) {
        return '';
      }
      return new Date(this.expiresAt).toLocaleString(this.$lang === 'en' ? 'en-US' : this.$lang);
    },
  },
  watch: {
    value(value) {
      this.dialogVisible = value;
    },
    dialogVisible(value) {
      this.$emit('input', value);
    },
  },
  methods: {
    async loadCode() {
      if (!this.entityId) {
        return;
      }

      this.loading = true;
      try {
        const result = await generateQr(this.entityType, this.entityId);
        this.token = result.token;
        this.expiresAt = result.expiresAt;
        await this.$nextTick();
        await QRCode.toCanvas(this.$refs.canvas, result.token, {
          width: 260,
          margin: 2,
        });
      } catch (error) {
        this.$message.error(error.message);
      } finally {
        this.loading = false;
      }
    },
  },
};
</script>

<style scoped>
.qr-dialog {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 18px;
}

.qr-meta {
  align-self: stretch;
  display: grid;
  gap: 8px;
  color: #475569;
}
</style>
