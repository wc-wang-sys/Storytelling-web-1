<template>
  <el-dialog :visible.sync="dialogVisible" width="720px" :title="$t('qrScanner.title')" @close="handleClose">
    <div class="scanner-shell">
      <video ref="video" class="scanner-video" autoplay playsinline muted></video>
      <canvas ref="canvas" class="scanner-canvas"></canvas>
      <div class="scanner-frame"></div>
    </div>

    <div class="scanner-hint">{{ error || $t('common.messages.qrHint') }}</div>

    <span slot="footer">
      <el-button @click="handleManualPaste">{{ $t('common.buttons.manualPaste') }}</el-button>
      <el-button @click="handleClose">{{ $t('common.buttons.cancel') }}</el-button>
    </span>
  </el-dialog>
</template>

<script>
export default {
  name: 'QrScannerDialog',
  props: {
    value: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {
      dialogVisible: this.value,
      stream: null,
      detector: null,
      scanning: false,
      frameBusy: false,
      error: '',
    };
  },
  watch: {
    value(value) {
      this.dialogVisible = value;
      if (value) {
        this.startCamera();
      } else {
        this.stopCamera();
      }
    },
    dialogVisible(value) {
      this.$emit('input', value);
      if (!value) {
        this.stopCamera();
      }
    },
  },
  mounted() {
    if (this.dialogVisible) {
      this.startCamera();
    }
  },
  methods: {
    async startCamera() {
      try {
        this.stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'environment' },
        });
        const video = this.$refs.video;
        video.srcObject = this.stream;
        await video.play();
        this.detector = window.BarcodeDetector ? new window.BarcodeDetector({ formats: ['qr_code'] }) : null;
        this.scanning = true;
        this.error = '';
        requestAnimationFrame(this.scanFrame);
      } catch (error) {
        this.error = this.$t('common.messages.cameraError');
      }
    },
    stopCamera() {
      this.scanning = false;
      if (this.stream) {
        this.stream.getTracks().forEach((track) => track.stop());
        this.stream = null;
      }
    },
    scanFrame() {
      if (!this.scanning || !this.$refs.video || !this.$refs.canvas) {
        return;
      }

      const video = this.$refs.video;
      const canvas = this.$refs.canvas;
      const ctx = canvas.getContext('2d');

      if (!ctx || video.readyState !== video.HAVE_ENOUGH_DATA) {
        requestAnimationFrame(this.scanFrame);
        return;
      }

      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

      if (this.detector && !this.frameBusy) {
        this.frameBusy = true;
        this.detector
          .detect(canvas)
          .then((codes) => {
            const matched = codes.find((item) => item.rawValue);
            if (matched && matched.rawValue) {
              this.handleDetected(matched.rawValue);
              return;
            }
            requestAnimationFrame(this.scanFrame);
          })
          .catch(() => requestAnimationFrame(this.scanFrame))
          .finally(() => {
            this.frameBusy = false;
          });
        return;
      }

      requestAnimationFrame(this.scanFrame);
    },
    handleDetected(token) {
      this.stopCamera();
      this.$emit('detected', token);
      this.dialogVisible = false;
    },
    handleManualPaste() {
      const token = window.prompt(this.$t('qrScanner.manualPastePrompt'));
      if (token && token.trim()) {
        this.handleDetected(token.trim());
      }
    },
    handleClose() {
      this.dialogVisible = false;
      this.stopCamera();
    },
  },
};
</script>

<style scoped>
.scanner-shell {
  position: relative;
  border-radius: 18px;
  overflow: hidden;
  background: #111827;
  min-height: 360px;
}

.scanner-video {
  width: 100%;
  height: 360px;
  object-fit: cover;
}

.scanner-canvas {
  display: none;
}

.scanner-frame {
  position: absolute;
  width: 220px;
  height: 220px;
  border: 4px solid rgba(255, 255, 255, 0.92);
  border-radius: 24px;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  box-shadow: 0 0 0 9999px rgba(0, 0, 0, 0.28);
}

.scanner-hint {
  margin-top: 12px;
  color: #64748b;
}
</style>
