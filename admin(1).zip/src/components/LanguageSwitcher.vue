<template>
  <div class="language-switcher">
    <span v-if="showLabel" class="language-switcher-label">{{ $t('layout.language') }}</span>
    <el-select :value="$lang" size="mini" class="language-switcher-select" @change="handleChange">
      <el-option
        v-for="language in $languages"
        :key="language"
        :label="$languageName(language)"
        :value="language"
      />
    </el-select>
  </div>
</template>

<script>
export default {
  name: 'LanguageSwitcher',
  props: {
    showLabel: {
      type: Boolean,
      default: false,
    },
  },
  methods: {
    handleChange(language) {
      this.$setLanguage(language);
    },
  },
};
</script>

<style scoped>
.language-switcher {
  display: inline-flex;
  align-items: center;
  gap: 8px;
}

.language-switcher-label {
  color: #64748b;
  font-size: 13px;
  font-weight: 600;
}

.language-switcher-select {
  width: 140px;
}
</style>
