<template>
  <div v-loading="loading" class="data-table-shell">
    <div v-if="normalizedRows.length" class="data-table-scroll">
      <table class="data-table">
        <thead>
          <tr>
            <th
              v-for="column in columns"
              :key="columnKey(column)"
              :class="headerClass(column)"
              :style="columnStyle(column)"
            >
              {{ column.label }}
            </th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(row, rowIndex) in normalizedRows" :key="resolveRowKey(row, rowIndex)">
            <td
              v-for="column in columns"
              :key="columnKey(column)"
              :class="cellClass(column)"
              :style="columnStyle(column)"
            >
              <slot
                :name="slotName(column)"
                :row="row"
                :value="cellValue(row, column)"
                :column="column"
                :row-index="rowIndex"
              >
                {{ formatCell(row, column) }}
              </slot>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <el-empty v-else-if="!loading" :description="resolvedEmptyText" class="data-table-empty" />
  </div>
</template>

<script>
export default {
  name: 'DataTable',
  props: {
    columns: {
      type: Array,
      default: () => [],
    },
    rows: {
      type: Array,
      default: () => [],
    },
    loading: {
      type: Boolean,
      default: false,
    },
    rowKey: {
      type: String,
      default: 'id',
    },
    emptyText: {
      type: String,
      default: '',
    },
  },
  computed: {
    normalizedRows() {
      return Array.isArray(this.rows) ? this.rows : [];
    },
    resolvedEmptyText() {
      return this.emptyText || this.$t('common.table.empty');
    },
  },
  methods: {
    columnKey(column) {
      return column.key || column.prop || column.label;
    },
    slotName(column) {
      return `cell-${this.columnKey(column)}`;
    },
    resolveRowKey(row, index) {
      return row && row[this.rowKey] ? row[this.rowKey] : `${index}`;
    },
    cellValue(row, column) {
      if (!column || !row) {
        return '';
      }
      if (typeof column.value === 'function') {
        return column.value(row);
      }
      const prop = column.prop || column.key;
      return prop ? row[prop] : '';
    },
    formatCell(row, column) {
      const value = this.cellValue(row, column);
      if (typeof column.formatter === 'function') {
        return column.formatter(row, value);
      }
      if (Array.isArray(value)) {
        return value.join(this.$lang === 'en' ? ', ' : '、');
      }
      if (value === null || value === undefined || value === '') {
        return '-';
      }
      return value;
    },
    headerClass(column) {
      return {
        'is-center': (column.headerAlign || column.align) === 'center',
        'is-right': (column.headerAlign || column.align) === 'right',
      };
    },
    cellClass(column) {
      return {
        'is-center': column.align === 'center',
        'is-right': column.align === 'right',
      };
    },
    columnStyle(column) {
      const style = {};
      const width = this.normalizeSize(column.width);
      const minWidth = this.normalizeSize(column.minWidth);

      if (width) {
        style.width = width;
      }
      if (minWidth) {
        style.minWidth = minWidth;
      }
      return style;
    },
    normalizeSize(value) {
      if (value === undefined || value === null || value === '') {
        return '';
      }
      return typeof value === 'number' ? `${value}px` : value;
    },
  },
};
</script>

<style scoped>
.data-table-shell {
  position: relative;
  min-height: 180px;
}

.data-table-scroll {
  width: 100%;
  overflow-x: auto;
  border: 1px solid #e2e8f0;
  border-radius: 16px;
  background: #ffffff;
}

.data-table {
  width: 100%;
  min-width: 100%;
  border-collapse: separate;
  border-spacing: 0;
}

.data-table th,
.data-table td {
  padding: 14px 16px;
  border-bottom: 1px solid #e2e8f0;
  font-size: 14px;
  line-height: 1.5;
  text-align: left;
  vertical-align: top;
}

.data-table th {
  position: sticky;
  top: 0;
  z-index: 1;
  background: #f8fafc;
  color: #475569;
  font-weight: 700;
  white-space: nowrap;
}

.data-table td {
  color: #0f172a;
}

.data-table tbody tr:last-child td {
  border-bottom: none;
}

.data-table tbody tr:hover td {
  background: #f8fbff;
}

.data-table .is-center {
  text-align: center;
}

.data-table .is-right {
  text-align: right;
}

.data-table-empty {
  padding: 28px 0 12px;
}
</style>
