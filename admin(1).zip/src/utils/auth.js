const TOKEN_KEY = 'storybuddy_access_token';
const USER_KEY = 'storybuddy_admin_user';

export const getToken = () => localStorage.getItem(TOKEN_KEY);
export const setToken = (token) => localStorage.setItem(TOKEN_KEY, token);
export const clearToken = () => localStorage.removeItem(TOKEN_KEY);

export const getCachedUser = () => {
  const raw = localStorage.getItem(USER_KEY);
  if (!raw) {
    return null;
  }

  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
};

export const setCachedUser = (user) => {
  localStorage.setItem(USER_KEY, JSON.stringify(user));
};

export const clearCachedUser = () => {
  localStorage.removeItem(USER_KEY);
};

export const clearSession = () => {
  clearToken();
  clearCachedUser();
};
