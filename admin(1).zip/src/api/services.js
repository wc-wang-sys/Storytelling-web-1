import request from './request';

export const loginByPassword = (payload) => {
  return request.post('/auth/login/password', payload);
};

export const loginByQr = (token) => {
  return request.post('/auth/login/qr', { token });
};

export const fetchCurrentUser = () => {
  return request.get('/auth/me');
};

export const fetchDashboardStats = () => {
  return request.get('/dashboard/stats');
};

export const fetchSchools = () => {
  return request.get('/schools');
};

export const createSchool = (payload) => {
  return request.post('/schools', payload);
};

export const updateSchool = (id, payload) => {
  return request.patch(`/schools/${id}`, payload);
};

export const deleteSchool = (id) => {
  return request.delete(`/schools/${id}`);
};

export const fetchClasses = (params = {}) => {
  return request.get('/classes', { params });
};

export const createClass = (payload) => {
  return request.post('/classes', payload);
};

export const updateClass = (id, payload) => {
  return request.patch(`/classes/${id}`, payload);
};

export const deleteClass = (id) => {
  return request.delete(`/classes/${id}`);
};

export const fetchTeachers = (params = {}) => {
  return request.get('/teachers', { params });
};

export const createTeacher = (payload) => {
  return request.post('/teachers', payload);
};

export const updateTeacher = (id, payload) => {
  return request.patch(`/teachers/${id}`, payload);
};

export const deleteTeacher = (id) => {
  return request.delete(`/teachers/${id}`);
};

export const fetchStudents = (params = {}) => {
  return request.get('/students', { params });
};

export const createStudent = (payload) => {
  return request.post('/students', payload);
};

export const updateStudent = (id, payload) => {
  return request.patch(`/students/${id}`, payload);
};

export const deleteStudent = (id) => {
  return request.delete(`/students/${id}`);
};

export const fetchStories = (params = {}) => {
  return request.get('/stories', {
    params: { includeContent: true, ...params },
    timeout: 60000,
  });
};

export const updateStory = (id, payload) => {
  return request.patch(`/stories/${id}`, payload);
};

export const deleteStory = (id) => {
  return request.delete(`/stories/${id}`);
};

export const generateQr = (type, id) => {
  return request.get('/qr/generate', { params: { type, id } });
};

export const fetchPromptTemplates = () => {
  return request.get('/prompts');
};

export const updatePromptTemplate = (key, payload) => {
  return request.patch(`/prompts/${key}`, payload);
};
