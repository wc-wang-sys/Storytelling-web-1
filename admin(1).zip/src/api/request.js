import axios from 'axios';
import { clearSession, getToken } from '../utils/auth';

const request = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:3030/api',
  timeout: 15000,
});

request.interceptors.request.use((config) => {
  const token = getToken();
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

request.interceptors.response.use(
  (response) => response.data.data,
  (error) => {
    if (error?.response?.status === 401) {
      clearSession();
      if (window.location.hash !== '#/login') {
        window.location.replace(`${import.meta.env.BASE_URL}#/login`);
      }
    }

    const message = error?.response?.data?.error || error.message || 'Request failed';
    return Promise.reject(new Error(message));
  },
);

export default request;
