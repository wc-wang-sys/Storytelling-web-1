import Vue from 'vue';
import Router from 'vue-router';
import { getToken } from '../utils/auth';

Vue.use(Router);

const router = new Router({
  mode: 'hash',
  routes: [
    {
      path: '/login',
      component: () => import('../views/login/Login.vue'),
      meta: { public: true },
    },
    {
      path: '/',
      component: () => import('../views/Layout.vue'),
      redirect: '/dashboard',
      children: [
        {
          path: 'dashboard',
          component: () => import('../views/dashboard/Index.vue'),
        },
        {
          path: 'schools',
          component: () => import('../views/schools/Index.vue'),
        },
        {
          path: 'classes',
          component: () => import('../views/classes/Index.vue'),
        },
        {
          path: 'teachers',
          component: () => import('../views/teachers/Index.vue'),
        },
        {
          path: 'students',
          component: () => import('../views/students/Index.vue'),
        },
        {
          path: 'stories',
          component: () => import('../views/stories/Index.vue'),
        },
        {
          path: 'prompts',
          component: () => import('../views/prompts/Index.vue'),
        },
      ],
    },
  ],
});

router.beforeEach((to, _from, next) => {
  if (to.meta.public) {
    next();
    return;
  }

  if (!getToken()) {
    next('/login');
    return;
  }

  next();
});

export default router;
