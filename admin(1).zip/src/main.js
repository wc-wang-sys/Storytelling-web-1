import Vue from 'vue';
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
import App from './App.vue';
import router from './router';
import { i18nPlugin } from './i18n';
import './styles/global.css';

Vue.config.productionTip = false;
Vue.use(ElementUI);
Vue.use(i18nPlugin);

new Vue({
  router,
  render: (h) => h(App),
}).$mount('#app');
