import { defineConfig } from 'vite';
import { createVuePlugin } from 'vite-plugin-vue2';

export default defineConfig(({ mode }) => ({
  base: mode === 'production' ? '/admin/' : '/',
  plugins: [createVuePlugin()],
  server: {
    host: '0.0.0.0',
    port: 5174,
    strictPort: true,
  },
}));
