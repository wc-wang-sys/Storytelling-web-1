import mysql from 'mysql2/promise';
import { env } from '../config/env.js';

export const pool = mysql.createPool({
  host: env.dbHost,
  port: env.dbPort,
  database: env.dbName,
  user: env.dbUser,
  password: env.dbPassword,
  waitForConnections: true,
  connectionLimit: 10,
  namedPlaceholders: false,
  charset: 'utf8mb4',
});

export const queryRows = async (sql, params = []) => {
  const [rows] = await pool.query(sql, params);
  return rows;
};

export const queryOne = async (sql, params = []) => {
  const rows = await queryRows(sql, params);
  return rows[0] || null;
};

export const execute = async (sql, params = []) => {
  const [result] = await pool.execute(sql, params);
  return result;
};

export const withTransaction = async (handler) => {
  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();
    const value = await handler(connection);
    await connection.commit();
    return value;
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
};

