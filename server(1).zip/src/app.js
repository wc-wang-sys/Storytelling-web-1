import cors from 'cors';
import express from 'express';
import { env } from './config/env.js';
import { HttpError } from './lib/httpError.js';
import { authRoutes } from './routes/authRoutes.js';
import { publicRoutes } from './routes/publicRoutes.js';
import { dashboardRoutes } from './routes/dashboardRoutes.js';
import { schoolRoutes } from './routes/schoolRoutes.js';
import { classRoutes } from './routes/classRoutes.js';
import { teacherRoutes } from './routes/teacherRoutes.js';
import { studentRoutes } from './routes/studentRoutes.js';
import { storyRoutes } from './routes/storyRoutes.js';
import { qrRoutes } from './routes/qrRoutes.js';
import { promptRoutes } from './routes/promptRoutes.js';

export const app = express();

const isPrivateIp = (hostname) => {
  return (
    /^10\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(hostname) ||
    /^192\.168\.\d{1,3}\.\d{1,3}$/.test(hostname) ||
    /^172\.(1[6-9]|2\d|3[0-1])\.\d{1,3}\.\d{1,3}$/.test(hostname)
  );
};

const isAllowedOrigin = (origin) => {
  if (!origin) {
    return true;
  }

  if (env.allowedOrigins.includes(origin)) {
    return true;
  }

  try {
    const { protocol, hostname, port } = new URL(origin);
    const resolvedPort = Number(port || (protocol === 'https:' ? 443 : 80));
    const isLocalHost =
      hostname === 'localhost' ||
      hostname === '127.0.0.1' ||
      hostname === '::1' ||
      isPrivateIp(hostname);

    return isLocalHost && env.allowedDevPorts.includes(resolvedPort);
  } catch {
    return false;
  }
};

app.use(
  cors({
    origin(origin, callback) {
      callback(null, isAllowedOrigin(origin) ? origin || true : false);
    },
    credentials: true,
  }),
);

app.use(express.json({ limit: env.jsonBodyLimit }));

app.get('/api/health', (_req, res) => {
  res.json({
    success: true,
    data: {
      status: 'ok',
      timestamp: Date.now(),
    },
  });
});

app.use('/api/public', publicRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/schools', schoolRoutes);
app.use('/api/classes', classRoutes);
app.use('/api/teachers', teacherRoutes);
app.use('/api/students', studentRoutes);
app.use('/api/stories', storyRoutes);
app.use('/api/qr', qrRoutes);
app.use('/api/prompts', promptRoutes);

app.use((error, _req, res, _next) => {
  if (error?.type === 'entity.too.large') {
    res.status(413).json({
      success: false,
      error: 'Request body is too large. Please reduce embedded image/audio data or increase JSON_BODY_LIMIT.',
    });
    return;
  }

  if (error instanceof HttpError) {
    res.status(error.statusCode).json({
      success: false,
      error: error.message,
      details: error.details,
    });
    return;
  }

  console.error(error);
  res.status(500).json({
    success: false,
    error: 'Internal server error',
  });
});
