import crypto from 'crypto';
import { queryOne, queryRows, execute, withTransaction } from '../db/pool.js';
import { badRequest, forbidden, notFound } from '../lib/httpError.js';
import { hashPassword } from '../lib/security.js';

const SCHOOL_SELECT = `
  SELECT
    s.id,
    s.name,
    s.code,
    s.address,
    s.contact_name AS contactName,
    s.contact_phone AS contactPhone,
    s.status,
    UNIX_TIMESTAMP(s.created_at) * 1000 AS createdAt,
    UNIX_TIMESTAMP(s.updated_at) * 1000 AS updatedAt,
    a.id AS adminAccountId,
    a.display_name AS adminDisplayName,
    a.username AS adminUsername
  FROM schools s
  LEFT JOIN accounts a
    ON a.school_id = s.id
    AND a.role = 'school_admin'
`;

const CLASS_SELECT = `
  SELECT
    c.id,
    c.school_id AS schoolId,
    c.name,
    c.grade,
    c.description,
    c.status,
    UNIX_TIMESTAMP(c.created_at) * 1000 AS createdAt,
    UNIX_TIMESTAMP(c.updated_at) * 1000 AS updatedAt
  FROM classes c
`;

const TEACHER_SELECT = `
  SELECT
    t.id,
    t.school_id AS schoolId,
    t.name,
    t.email,
    t.phone,
    t.status,
    UNIX_TIMESTAMP(t.created_at) * 1000 AS createdAt,
    UNIX_TIMESTAMP(t.updated_at) * 1000 AS updatedAt,
    a.id AS accountId,
    a.username
  FROM teachers t
  LEFT JOIN accounts a
    ON a.teacher_id = t.id
    AND a.role = 'teacher'
`;

const STUDENT_SELECT = `
  SELECT
    s.id,
    s.school_id AS schoolId,
    s.class_id AS classId,
    s.teacher_id AS teacherId,
    s.student_no AS studentNo,
    s.name,
    s.age_group AS ageGroup,
    s.status,
    UNIX_TIMESTAMP(s.created_at) * 1000 AS createdAt,
    UNIX_TIMESTAMP(s.updated_at) * 1000 AS updatedAt,
    a.id AS accountId,
    a.username
  FROM students s
  LEFT JOIN accounts a
    ON a.student_id = s.id
    AND a.role = 'student'
`;

const assertRole = (actor, roles) => {
  if (!roles.includes(actor.role)) {
    throw forbidden('Permission denied');
  }
};

const assertSchoolScope = (actor, schoolId) => {
  if (actor.role === 'super_admin') {
    return;
  }

  if (actor.schoolId !== schoolId) {
    throw forbidden('You cannot access this school');
  }
};

const getClassIdsForTeacher = async (teacherId) => {
  if (!teacherId) {
    return [];
  }

  const rows = await queryRows(
    'SELECT class_id AS classId FROM teacher_classes WHERE teacher_id = ? ORDER BY created_at ASC',
    [teacherId],
  );

  return rows.map((row) => row.classId);
};

const getClassById = async (classId) => {
  return queryOne(`${CLASS_SELECT} WHERE c.id = ?`, [classId]);
};

const getTeacherEntityById = async (teacherId) => {
  return queryOne(`${TEACHER_SELECT} WHERE t.id = ?`, [teacherId]);
};

const ensureClassBelongsToSchool = async (classId, schoolId) => {
  const schoolClass = await getClassById(classId);
  if (!schoolClass || schoolClass.schoolId !== schoolId) {
    throw badRequest('Class does not belong to the selected school');
  }
  return schoolClass;
};

const ensureTeacherBelongsToSchool = async (teacherId, schoolId) => {
  if (!teacherId) {
    return null;
  }

  const teacher = await getTeacherEntityById(teacherId);
  if (!teacher || teacher.schoolId !== schoolId) {
    throw badRequest('Teacher does not belong to the selected school');
  }

  return teacher;
};

const mapTeacherWithClasses = async (teacherRows) => {
  if (teacherRows.length === 0) {
    return [];
  }

  const teacherIds = teacherRows.map((teacher) => teacher.id);
  const placeholders = teacherIds.map(() => '?').join(', ');
  const teacherClassRows = await queryRows(
    `SELECT teacher_id AS teacherId, class_id AS classId
     FROM teacher_classes
     WHERE teacher_id IN (${placeholders})`,
    teacherIds,
  );

  const classMap = teacherClassRows.reduce((accumulator, item) => {
    accumulator[item.teacherId] = accumulator[item.teacherId] || [];
    accumulator[item.teacherId].push(item.classId);
    return accumulator;
  }, {});

  return teacherRows.map((teacher) => ({
    ...teacher,
    classIds: classMap[teacher.id] || [],
  }));
};

export const listPublicSchools = async () => {
  return queryRows(
    `SELECT id, name, code, address
     FROM schools
     WHERE status = 'active'
     ORDER BY name ASC`,
  );
};

export const listPublicClasses = async (schoolId) => {
  if (!schoolId) {
    throw badRequest('schoolId is required');
  }

  return queryRows(
    `SELECT id, school_id AS schoolId, name, grade
     FROM classes
     WHERE school_id = ? AND status = 'active'
     ORDER BY grade ASC, name ASC`,
    [schoolId],
  );
};

export const listSchools = async (actor) => {
  assertRole(actor, ['super_admin', 'school_admin', 'teacher']);

  if (actor.role === 'school_admin' || actor.role === 'teacher') {
    const ownSchool = await queryRows(`${SCHOOL_SELECT} WHERE s.id = ?`, [actor.schoolId]);
    return ownSchool;
  }

  return queryRows(`${SCHOOL_SELECT} ORDER BY s.created_at DESC`);
};

const ensureSchoolCode = (name, code) => {
  if (code) {
    return code.trim().toUpperCase();
  }

  const prefix = (name || 'SCH')
    .replace(/[^a-zA-Z0-9]/g, '')
    .toUpperCase()
    .slice(0, 8) || 'SCH';

  return `${prefix}-${Date.now().toString().slice(-6)}`;
};

export const createSchool = async (actor, payload) => {
  assertRole(actor, ['super_admin']);

  const {
    name,
    code,
    address,
    contactName,
    contactPhone,
    adminDisplayName,
    adminUsername,
    adminPassword,
  } = payload;

  if (!name || !adminDisplayName || !adminUsername || !adminPassword) {
    throw badRequest('School name and school admin account are required');
  }

  const duplicatedAccount = await queryOne('SELECT id FROM accounts WHERE username = ?', [adminUsername]);
  if (duplicatedAccount) {
    throw badRequest('Admin username already exists');
  }

  const schoolId = crypto.randomUUID();
  const accountId = crypto.randomUUID();
  const schoolCode = ensureSchoolCode(name, code);

  await withTransaction(async (connection) => {
    await connection.execute(
      `INSERT INTO schools (
        id, name, code, address, contact_name, contact_phone, status, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, 'active', NOW(), NOW())`,
      [schoolId, name, schoolCode, address || null, contactName || null, contactPhone || null],
    );

    await connection.execute(
      `INSERT INTO accounts (
        id, username, password_hash, display_name, role, school_id, status, created_at, updated_at
      ) VALUES (?, ?, ?, ?, 'school_admin', ?, 'active', NOW(), NOW())`,
      [accountId, adminUsername, hashPassword(adminPassword), adminDisplayName, schoolId],
    );
  });

  return queryOne(`${SCHOOL_SELECT} WHERE s.id = ?`, [schoolId]);
};

export const updateSchool = async (actor, schoolId, payload) => {
  assertRole(actor, ['super_admin', 'school_admin']);
  assertSchoolScope(actor, schoolId);

  const school = await queryOne(`${SCHOOL_SELECT} WHERE s.id = ?`, [schoolId]);
  if (!school) {
    throw notFound('School not found');
  }

  const {
    name,
    code,
    address,
    contactName,
    contactPhone,
    status,
    adminDisplayName,
    adminUsername,
    adminPassword,
  } = payload;

  if (adminUsername && adminUsername !== school.adminUsername) {
    const duplicatedAccount = await queryOne(
      'SELECT id FROM accounts WHERE username = ? AND id <> ?',
      [adminUsername, school.adminAccountId],
    );
    if (duplicatedAccount) {
      throw badRequest('Admin username already exists');
    }
  }

  await withTransaction(async (connection) => {
    await connection.execute(
      `UPDATE schools
       SET name = ?, code = ?, address = ?, contact_name = ?, contact_phone = ?, status = ?, updated_at = NOW()
       WHERE id = ?`,
      [
        name || school.name,
        ensureSchoolCode(name || school.name, code || school.code),
        address ?? school.address,
        contactName ?? school.contactName,
        contactPhone ?? school.contactPhone,
        status || school.status,
        schoolId,
      ],
    );

    if (school.adminAccountId) {
      await connection.execute(
        `UPDATE accounts
         SET display_name = ?, username = ?, password_hash = COALESCE(?, password_hash), status = ?, updated_at = NOW()
         WHERE id = ?`,
        [
          adminDisplayName || school.adminDisplayName,
          adminUsername || school.adminUsername,
          adminPassword ? hashPassword(adminPassword) : null,
          status || school.status,
          school.adminAccountId,
        ],
      );
    }
  });

  return queryOne(`${SCHOOL_SELECT} WHERE s.id = ?`, [schoolId]);
};

export const deleteSchool = async (actor, schoolId) => {
  assertRole(actor, ['super_admin']);

  const school = await queryOne('SELECT id FROM schools WHERE id = ?', [schoolId]);
  if (!school) {
    throw notFound('School not found');
  }

  const dependencyRows = await queryOne(
    `SELECT
       (SELECT COUNT(*) FROM classes WHERE school_id = ?) AS classCount,
       (SELECT COUNT(*) FROM teachers WHERE school_id = ?) AS teacherCount,
       (SELECT COUNT(*) FROM students WHERE school_id = ?) AS studentCount,
       (SELECT COUNT(*) FROM stories WHERE school_id = ?) AS storyCount`,
    [schoolId, schoolId, schoolId, schoolId],
  );

  if (dependencyRows.classCount || dependencyRows.teacherCount || dependencyRows.studentCount || dependencyRows.storyCount) {
    throw badRequest('Please clear related classes, teachers, students and stories before deleting this school');
  }

  await execute('DELETE FROM accounts WHERE school_id = ? AND role = ?', [schoolId, 'school_admin']);
  const result = await execute('DELETE FROM schools WHERE id = ?', [schoolId]);
  return result.affectedRows > 0;
};

export const getSchoolStats = async (actor, schoolId) => {
  assertRole(actor, ['super_admin', 'school_admin']);
  assertSchoolScope(actor, schoolId);

  const school = await queryOne('SELECT id FROM schools WHERE id = ?', [schoolId]);
  if (!school) {
    throw notFound('School not found');
  }

  return queryOne(
    `SELECT
      (SELECT COUNT(*) FROM teachers WHERE school_id = ?) AS teacherCount,
      (SELECT COUNT(*) FROM students WHERE school_id = ?) AS studentCount,
      (SELECT COUNT(*) FROM stories WHERE school_id = ?) AS storyCount`,
    [schoolId, schoolId, schoolId],
  );
};

export const listClasses = async (actor, filters = {}) => {
  const where = [];
  const params = [];

  if (actor.role === 'school_admin') {
    where.push('c.school_id = ?');
    params.push(actor.schoolId);
  }

  if (actor.role === 'teacher') {
    const classIds = await getClassIdsForTeacher(actor.teacherId);
    if (classIds.length === 0) {
      return [];
    }
    where.push(`c.id IN (${classIds.map(() => '?').join(', ')})`);
    params.push(...classIds);
  }

  if (filters.schoolId) {
    if (actor.role !== 'super_admin' && actor.schoolId !== filters.schoolId) {
      throw forbidden('You cannot access another school');
    }
    where.push('c.school_id = ?');
    params.push(filters.schoolId);
  }

  const sql = `${CLASS_SELECT} ${where.length ? `WHERE ${where.join(' AND ')}` : ''} ORDER BY c.created_at DESC`;
  return queryRows(sql, params);
};

export const createClass = async (actor, payload) => {
  assertRole(actor, ['super_admin', 'school_admin']);

  const { schoolId, name, grade, description, status } = payload;
  if (!schoolId || !name || !grade) {
    throw badRequest('schoolId, name and grade are required');
  }

  assertSchoolScope(actor, schoolId);

  const duplicatedClass = await queryOne(
    'SELECT id FROM classes WHERE school_id = ? AND name = ?',
    [schoolId, name],
  );
  if (duplicatedClass) {
    throw badRequest('Class name already exists in this school');
  }

  const classId = crypto.randomUUID();
  await execute(
    `INSERT INTO classes (
      id, school_id, name, grade, description, status, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, NOW(), NOW())`,
    [classId, schoolId, name, grade, description || null, status || 'active'],
  );

  return queryOne(`${CLASS_SELECT} WHERE c.id = ?`, [classId]);
};

export const updateClass = async (actor, classId, payload) => {
  assertRole(actor, ['super_admin', 'school_admin']);

  const existing = await queryOne(`${CLASS_SELECT} WHERE c.id = ?`, [classId]);
  if (!existing) {
    throw notFound('Class not found');
  }

  assertSchoolScope(actor, existing.schoolId);

  await execute(
    `UPDATE classes
     SET name = ?, grade = ?, description = ?, status = ?, updated_at = NOW()
     WHERE id = ?`,
    [
      payload.name || existing.name,
      payload.grade || existing.grade,
      payload.description ?? existing.description,
      payload.status || existing.status,
      classId,
    ],
  );

  return queryOne(`${CLASS_SELECT} WHERE c.id = ?`, [classId]);
};

export const deleteClass = async (actor, classId) => {
  assertRole(actor, ['super_admin', 'school_admin']);

  const existing = await queryOne(`${CLASS_SELECT} WHERE c.id = ?`, [classId]);
  if (!existing) {
    throw notFound('Class not found');
  }

  assertSchoolScope(actor, existing.schoolId);

  const dependencyRows = await queryOne(
    `SELECT
      (SELECT COUNT(*) FROM students WHERE class_id = ?) AS studentCount,
      (SELECT COUNT(*) FROM stories WHERE class_id = ?) AS storyCount`,
    [classId, classId],
  );

  if (dependencyRows.studentCount || dependencyRows.storyCount) {
    throw badRequest('Please clear students and stories before deleting this class');
  }

  await execute('DELETE FROM teacher_classes WHERE class_id = ?', [classId]);
  const result = await execute('DELETE FROM classes WHERE id = ?', [classId]);
  return result.affectedRows > 0;
};

export const listTeachers = async (actor, filters = {}) => {
  assertRole(actor, ['super_admin', 'school_admin', 'teacher']);

  const where = [];
  const params = [];

  if (actor.role === 'school_admin') {
    where.push('t.school_id = ?');
    params.push(actor.schoolId);
  }

  if (actor.role === 'teacher') {
    where.push('t.id = ?');
    params.push(actor.teacherId);
  }

  if (filters.schoolId) {
    if (actor.role !== 'super_admin' && actor.schoolId !== filters.schoolId) {
      throw forbidden('You cannot access another school');
    }
    where.push('t.school_id = ?');
    params.push(filters.schoolId);
  }

  const rows = await queryRows(
    `${TEACHER_SELECT} ${where.length ? `WHERE ${where.join(' AND ')}` : ''} ORDER BY t.created_at DESC`,
    params,
  );

  return mapTeacherWithClasses(rows);
};

export const createTeacher = async (actor, payload) => {
  assertRole(actor, ['super_admin', 'school_admin']);

  const { schoolId, name, email, phone, username, password, classIds = [], status } = payload;
  if (!schoolId || !name || !username || !password) {
    throw badRequest('schoolId, name, username and password are required');
  }

  assertSchoolScope(actor, schoolId);

  for (const classId of classIds) {
    await ensureClassBelongsToSchool(classId, schoolId);
  }

  const duplicatedAccount = await queryOne('SELECT id FROM accounts WHERE username = ?', [username]);
  if (duplicatedAccount) {
    throw badRequest('Username already exists');
  }

  const teacherId = crypto.randomUUID();
  const accountId = crypto.randomUUID();

  await withTransaction(async (connection) => {
    await connection.execute(
      `INSERT INTO teachers (
        id, school_id, name, email, phone, status, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, NOW(), NOW())`,
      [teacherId, schoolId, name, email || null, phone || null, status || 'active'],
    );

    await connection.execute(
      `INSERT INTO accounts (
        id, username, password_hash, display_name, role, school_id, teacher_id, status, created_at, updated_at
      ) VALUES (?, ?, ?, ?, 'teacher', ?, ?, ?, NOW(), NOW())`,
      [accountId, username, hashPassword(password), name, null, teacherId, status || 'active'],
    );

    for (const classId of classIds) {
      await connection.execute(
        `INSERT INTO teacher_classes (id, teacher_id, class_id, created_at)
         VALUES (?, ?, ?, NOW())`,
        [crypto.randomUUID(), teacherId, classId],
      );
    }
  });

  const rows = await listTeachers(actor, { schoolId });
  return rows.find((item) => item.id === teacherId);
};

export const updateTeacher = async (actor, teacherId, payload) => {
  assertRole(actor, ['super_admin', 'school_admin', 'teacher']);

  const existing = await queryOne(`${TEACHER_SELECT} WHERE t.id = ?`, [teacherId]);
  if (!existing) {
    throw notFound('Teacher not found');
  }

  if (actor.role === 'teacher' && actor.teacherId !== teacherId) {
    throw forbidden('You can only update your own teacher profile');
  }

  assertSchoolScope(actor, existing.schoolId);

  if (payload.username && payload.username !== existing.username) {
    const duplicatedAccount = await queryOne(
      'SELECT id FROM accounts WHERE username = ? AND teacher_id <> ?',
      [payload.username, teacherId],
    );
    if (duplicatedAccount) {
      throw badRequest('Username already exists');
    }
  }

  if (Array.isArray(payload.classIds)) {
    for (const classId of payload.classIds) {
      await ensureClassBelongsToSchool(classId, existing.schoolId);
    }
  }

  await withTransaction(async (connection) => {
    await connection.execute(
      `UPDATE teachers
       SET name = ?, email = ?, phone = ?, status = ?, updated_at = NOW()
       WHERE id = ?`,
      [
        payload.name || existing.name,
        payload.email ?? existing.email,
        payload.phone ?? existing.phone,
        payload.status || existing.status,
        teacherId,
      ],
    );

    await connection.execute(
      `UPDATE accounts
       SET username = ?, display_name = ?, password_hash = COALESCE(?, password_hash), status = ?, updated_at = NOW()
       WHERE teacher_id = ?`,
      [
        payload.username || existing.username,
        payload.name || existing.name,
        payload.password ? hashPassword(payload.password) : null,
        payload.status || existing.status,
        teacherId,
      ],
    );

    if (Array.isArray(payload.classIds)) {
      await connection.execute('DELETE FROM teacher_classes WHERE teacher_id = ?', [teacherId]);
      for (const classId of payload.classIds) {
        await connection.execute(
          `INSERT INTO teacher_classes (id, teacher_id, class_id, created_at)
           VALUES (?, ?, ?, NOW())`,
          [crypto.randomUUID(), teacherId, classId],
        );
      }
    }
  });

  const updated = await listTeachers(actor, { schoolId: existing.schoolId });
  return updated.find((item) => item.id === teacherId);
};

export const deleteTeacher = async (actor, teacherId) => {
  assertRole(actor, ['super_admin', 'school_admin']);

  const existing = await queryOne(`${TEACHER_SELECT} WHERE t.id = ?`, [teacherId]);
  if (!existing) {
    throw notFound('Teacher not found');
  }

  assertSchoolScope(actor, existing.schoolId);

  const dependencyRows = await queryOne(
    `SELECT
      (SELECT COUNT(*) FROM students WHERE teacher_id = ?) AS studentCount,
      (SELECT COUNT(*) FROM stories WHERE teacher_id = ?) AS storyCount`,
    [teacherId, teacherId],
  );

  if (dependencyRows.studentCount || dependencyRows.storyCount) {
    throw badRequest('Please clear related students and stories before deleting this teacher');
  }

  await withTransaction(async (connection) => {
    await connection.execute('DELETE FROM teacher_classes WHERE teacher_id = ?', [teacherId]);
    await connection.execute('DELETE FROM accounts WHERE teacher_id = ?', [teacherId]);
    await connection.execute('DELETE FROM teachers WHERE id = ?', [teacherId]);
  });

  return true;
};

export const listStudents = async (actor, filters = {}) => {
  assertRole(actor, ['super_admin', 'school_admin', 'teacher', 'student']);

  const where = [];
  const params = [];

  if (actor.role === 'school_admin') {
    where.push('s.school_id = ?');
    params.push(actor.schoolId);
  }

  if (actor.role === 'teacher') {
    const classIds = await getClassIdsForTeacher(actor.teacherId);
    if (classIds.length === 0) {
      return [];
    }
    where.push(`s.class_id IN (${classIds.map(() => '?').join(', ')})`);
    params.push(...classIds);
  }

  if (actor.role === 'student') {
    where.push('s.id = ?');
    params.push(actor.studentId);
  }

  if (filters.schoolId) {
    if (actor.role !== 'super_admin' && actor.schoolId !== filters.schoolId) {
      throw forbidden('You cannot access another school');
    }
    where.push('s.school_id = ?');
    params.push(filters.schoolId);
  }

  if (filters.classId) {
    where.push('s.class_id = ?');
    params.push(filters.classId);
  }

  if (filters.teacherId) {
    if (actor.role === 'teacher' && actor.teacherId !== filters.teacherId) {
      throw forbidden('You cannot access another teacher');
    }
    where.push('s.teacher_id = ?');
    params.push(filters.teacherId);
  }

  if (filters.studentId) {
    if (actor.role === 'student' && actor.studentId !== filters.studentId) {
      throw forbidden('You cannot access another student');
    }
    where.push('s.id = ?');
    params.push(filters.studentId);
  }

  const rows = await queryRows(
    `${STUDENT_SELECT} ${where.length ? `WHERE ${where.join(' AND ')}` : ''} ORDER BY s.created_at DESC`,
    params,
  );

  return rows;
};

export const createStudent = async (actor, payload) => {
  assertRole(actor, ['super_admin', 'school_admin', 'teacher']);

  const { schoolId, classId, teacherId, studentNo, name, ageGroup, username, password, status } = payload;
  if (!schoolId || !classId || !name || !username || !password) {
    throw badRequest('schoolId, classId, name, username and password are required');
  }

  assertSchoolScope(actor, schoolId);
  await ensureClassBelongsToSchool(classId, schoolId);
  await ensureTeacherBelongsToSchool(teacherId, schoolId);

  if (actor.role === 'teacher') {
    const classIds = await getClassIdsForTeacher(actor.teacherId);
    if (!classIds.includes(classId)) {
      throw forbidden('You cannot create students outside your classes');
    }
  }

  const duplicatedAccount = await queryOne('SELECT id FROM accounts WHERE username = ?', [username]);
  if (duplicatedAccount) {
    throw badRequest('Username already exists');
  }

  const studentId = crypto.randomUUID();
  const accountId = crypto.randomUUID();

  await withTransaction(async (connection) => {
    await connection.execute(
      `INSERT INTO students (
        id, school_id, class_id, teacher_id, student_no, name, age_group, status, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())`,
      [
        studentId,
        schoolId,
        classId,
        teacherId || null,
        studentNo || `STU-${Date.now()}`,
        name,
        ageGroup || '5-7',
        status || 'active',
      ],
    );

    await connection.execute(
      `INSERT INTO accounts (
        id, username, password_hash, display_name, role, school_id, student_id, status, created_at, updated_at
      ) VALUES (?, ?, ?, ?, 'student', ?, ?, ?, NOW(), NOW())`,
      [accountId, username, hashPassword(password), name, null, studentId, status || 'active'],
    );
  });

  const rows = await listStudents(actor.role === 'teacher' ? actor : actor, { schoolId, classId });
  return rows.find((item) => item.id === studentId);
};

export const updateStudent = async (actor, studentId, payload) => {
  assertRole(actor, ['super_admin', 'school_admin', 'teacher', 'student']);

  const existing = await queryOne(`${STUDENT_SELECT} WHERE s.id = ?`, [studentId]);
  if (!existing) {
    throw notFound('Student not found');
  }

  if (actor.role === 'student' && actor.studentId !== studentId) {
    throw forbidden('You can only update your own student profile');
  }

  assertSchoolScope(actor, existing.schoolId);

  if (payload.username && payload.username !== existing.username) {
    const duplicatedAccount = await queryOne(
      'SELECT id FROM accounts WHERE username = ? AND student_id <> ?',
      [payload.username, studentId],
    );
    if (duplicatedAccount) {
      throw badRequest('Username already exists');
    }
  }

  if (actor.role === 'teacher') {
    const classIds = await getClassIdsForTeacher(actor.teacherId);
    if (!classIds.includes(existing.classId)) {
      throw forbidden('You cannot update students outside your classes');
    }
  }

  const nextClassId = payload.classId || existing.classId;
  const nextTeacherId = payload.teacherId ?? existing.teacherId;
  await ensureClassBelongsToSchool(nextClassId, existing.schoolId);
  await ensureTeacherBelongsToSchool(nextTeacherId, existing.schoolId);

  await withTransaction(async (connection) => {
    await connection.execute(
      `UPDATE students
       SET class_id = ?, teacher_id = ?, student_no = ?, name = ?, age_group = ?, status = ?, updated_at = NOW()
       WHERE id = ?`,
      [
        payload.classId || existing.classId,
        payload.teacherId ?? existing.teacherId,
        payload.studentNo || existing.studentNo,
        payload.name || existing.name,
        payload.ageGroup || existing.ageGroup,
        payload.status || existing.status,
        studentId,
      ],
    );

    await connection.execute(
      `UPDATE accounts
       SET username = ?, display_name = ?, password_hash = COALESCE(?, password_hash), status = ?, updated_at = NOW()
       WHERE student_id = ?`,
      [
        payload.username || existing.username,
        payload.name || existing.name,
        payload.password ? hashPassword(payload.password) : null,
        payload.status || existing.status,
        studentId,
      ],
    );
  });

  return queryOne(`${STUDENT_SELECT} WHERE s.id = ?`, [studentId]);
};

export const deleteStudent = async (actor, studentId) => {
  assertRole(actor, ['super_admin', 'school_admin', 'teacher']);

  const existing = await queryOne(`${STUDENT_SELECT} WHERE s.id = ?`, [studentId]);
  if (!existing) {
    throw notFound('Student not found');
  }

  assertSchoolScope(actor, existing.schoolId);

  if (actor.role === 'teacher') {
    const classIds = await getClassIdsForTeacher(actor.teacherId);
    if (!classIds.includes(existing.classId)) {
      throw forbidden('You cannot delete students outside your classes');
    }
  }

  const storyRow = await queryOne('SELECT id FROM stories WHERE student_id = ? LIMIT 1', [studentId]);
  if (storyRow) {
    throw badRequest('Please delete or archive the student stories first');
  }

  await withTransaction(async (connection) => {
    await connection.execute('DELETE FROM accounts WHERE student_id = ?', [studentId]);
    await connection.execute('DELETE FROM students WHERE id = ?', [studentId]);
  });

  return true;
};

export const getStudentById = async (studentId) => {
  return queryOne(`${STUDENT_SELECT} WHERE s.id = ?`, [studentId]);
};

export const getTeacherById = async (teacherId) => {
  return queryOne(`${TEACHER_SELECT} WHERE t.id = ?`, [teacherId]);
};

export const getClassesForSchool = async (schoolId) => {
  return queryRows(`${CLASS_SELECT} WHERE c.school_id = ? ORDER BY c.grade ASC, c.name ASC`, [schoolId]);
};

export const getDashboardStats = async (actor) => {
  if (actor.role === 'super_admin') {
    return queryOne(
      `SELECT
        (SELECT COUNT(*) FROM schools WHERE status = 'active') AS schoolCount,
        (SELECT COUNT(*) FROM classes WHERE status = 'active') AS classCount,
        (SELECT COUNT(*) FROM teachers WHERE status = 'active') AS teacherCount,
        (SELECT COUNT(*) FROM students WHERE status = 'active') AS studentCount,
        (SELECT COUNT(*) FROM stories) AS storyCount`,
    );
  }

  if (actor.role === 'school_admin') {
    return queryOne(
      `SELECT
        1 AS schoolCount,
        (SELECT COUNT(*) FROM classes WHERE school_id = ? AND status = 'active') AS classCount,
        (SELECT COUNT(*) FROM teachers WHERE school_id = ? AND status = 'active') AS teacherCount,
        (SELECT COUNT(*) FROM students WHERE school_id = ? AND status = 'active') AS studentCount,
        (SELECT COUNT(*) FROM stories WHERE school_id = ?) AS storyCount`,
      [actor.schoolId, actor.schoolId, actor.schoolId, actor.schoolId],
    );
  }

  if (actor.role === 'teacher') {
    const classIds = await getClassIdsForTeacher(actor.teacherId);
    if (classIds.length === 0) {
      return {
        schoolCount: 0,
        classCount: 0,
        teacherCount: 1,
        studentCount: 0,
        storyCount: 0,
      };
    }

    const placeholders = classIds.map(() => '?').join(', ');
    return queryOne(
      `SELECT
        1 AS schoolCount,
        ? AS classCount,
        1 AS teacherCount,
        (SELECT COUNT(*) FROM students WHERE class_id IN (${placeholders}) AND status = 'active') AS studentCount,
        (SELECT COUNT(*) FROM stories WHERE class_id IN (${placeholders})) AS storyCount`,
      [classIds.length, ...classIds, ...classIds],
    );
  }

  return {
    schoolCount: 0,
    classCount: 1,
    teacherCount: 1,
    studentCount: 1,
    storyCount: 0,
  };
};
