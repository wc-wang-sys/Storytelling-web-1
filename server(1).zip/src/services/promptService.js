import { execute, queryOne, queryRows } from '../db/pool.js';
import { parseJsonColumn } from '../lib/serializers.js';
import { badRequest, forbidden, notFound } from '../lib/httpError.js';

export const DEFAULT_PROMPT_TEMPLATES = [
  {
    key: 'image_generation_default_style',
    title: '默认图片风格',
    category: 'image',
    description: '未单独传入 style 时，图片生成默认使用的风格描述。',
    variables: [],
    templateText: '儿童绘本风格，明亮温暖，可爱治愈，柔和色彩，Q版卡通',
    sortOrder: 5,
  },
  {
    key: 'image_generation_suffix',
    title: '通用图片生成提示词',
    category: 'image',
    description: '所有 AI 图片生成请求都会拼接这一段。变量: prompt, style',
    variables: ['prompt', 'style'],
    templateText:
      '{{prompt}}，{{style}}。儿童绘本风格，明亮温暖，可爱治愈，柔和色彩，Q版卡通，无恐怖、无黑暗、无暴力、无危险画面，积极阳光，适合小朋友阅读，高清，干净，温馨。',
    sortOrder: 10,
  },
  {
    key: 'text_generation_task',
    title: '通用文本生成提示词',
    category: 'text',
    description: '普通文本生成或改写的系统提示词。变量: ageGroup, task',
    variables: ['ageGroup', 'task'],
    templateText:
      `你是专为3-6岁儿童设计的故事创作助手，只输出温暖、阳光、安全的故事。
必须严格遵守以下规则：
1. 绝对不出现暴力、血腥、死亡、恐怖、惊悚、吵架、威胁等内容。
2. 价值观必须正向：友善、勇敢、诚实、分享、合作、爱护家人、热爱自然、乐于助人。
3. 语言简单易懂、可爱、充满想象力。
4. 结局一定是快乐、温暖、积极向上的。
5. 如果用户输入恐怖、暴力、负面内容，自动引导为正向故事，不采纳危险内容。
任务：{{task}}`,
    sortOrder: 20,
  },
  {
    key: 'input_moderation_prompt',
    title: '学生输入审核提示词',
    category: 'moderation',
    description: '审核学生自由输入是否包含暴力、恐怖等不适宜儿童的内容。变量: input',
    variables: ['input'],
    templateText:
      `你是儿童内容安全审核助手，负责判断学生输入的文本是否适合 3-6 岁儿童故事创作。
请重点识别并拦截这些内容：暴力、血腥、死亡、自残、恐怖、惊悚、鬼怪、武器、爆炸、威胁、绑架、霸凌、仇恨、成人化内容，以及其他明显不适合儿童的危险内容。
如果文本只是普通冒险、友善幻想、轻微紧张但整体安全、温暖、没有伤害和恐吓，可以判定为 safe。
输入文本可能是中文或英文。

只返回 JSON，不要输出任何额外说明，格式如下：
{
  "safe": true,
  "categories": [],
  "reason": "safe"
}

如果不安全，则返回：
{
  "safe": false,
  "categories": ["violence", "horror"],
  "reason": "brief reason"
}

categories 只能从以下枚举中选择：violence, terror, horror, weapon, bullying, self_harm, hate, adult, dangerous

待审核文本：
{{input}}`,
    sortOrder: 25,
  },
  {
    key: 'suggestions_generation',
    title: '灵感建议生成提示词',
    category: 'suggestion',
    description: '为角色、地点、时间生成 3 个建议。变量: context, ageGroup',
    variables: ['context', 'ageGroup'],
    templateText:
      `你是为3-6岁儿童提供灵感的小帮手。
请为{{ageGroup}}岁儿童提供 3 个关于{{context}}的温暖、明亮、安全、充满想象力的选项。
不要出现恐怖、黑暗、暴力、危险或不友好的内容。
仅返回 JSON 字符串数组，例如 ["一只爱帮助人的小兔子", "会唱歌的小机器人", "喜欢跳舞的小猫咪"]。`,
    sortOrder: 30,
  },
  {
    key: 'story_segment_generation',
    title: '单页故事生成提示词',
    category: 'story',
    description: '生成单页故事文本和配图描述。变量: ageGroup, character, place, time, plot',
    variables: ['ageGroup', 'character', 'place', 'time', 'plot'],
    templateText:
      `你是专为3-6岁儿童设计的故事创作助手，只输出温暖、阳光、安全的故事。
必须严格遵守以下规则：
1. 绝对不出现暴力、血腥、死亡、恐怖、惊悚、吵架、威胁等内容。
2. 价值观必须正向：友善、勇敢、诚实、分享、合作、爱护家人、热爱自然、乐于助人。
3. 语言简单易懂、可爱、充满想象力。
4. 结局一定是快乐、温暖、积极向上的。
5. 如果用户输入恐怖、暴力、负面内容，自动引导为正向故事，不采纳危险内容。

请为{{ageGroup}}岁儿童创作故事的一页，正文 2-3 句。
角色：{{character}}
地点：{{place}}
时间：{{time}}
剧情方向：{{plot}}

只返回 JSON：{ "storyText": "...", "imageDescription": "..." }
其中 imageDescription 必须是适合儿童绘本插图的明亮温暖画面描述。`,
    sortOrder: 40,
  },
  {
    key: 'story_outline_generation',
    title: '故事大纲生成提示词',
    category: 'story',
    description: '先生成整本故事的大纲，再逐页扩写。变量: pageCount, character, place, time, plot, ageGroup',
    variables: ['pageCount', 'character', 'place', 'time', 'plot', 'ageGroup'],
    templateText:
      `你是专为3-6岁儿童设计的故事创作助手，只输出温暖、阳光、安全的故事。
必须严格遵守以下规则：
1. 绝对不出现暴力、血腥、死亡、恐怖、惊悚、吵架、威胁等内容。
2. 价值观必须正向：友善、勇敢、诚实、分享、合作、爱护家人、热爱自然、乐于助人。
3. 语言简单易懂、可爱、充满想象力。
4. 结局一定是快乐、温暖、积极向上的。
5. 如果用户输入恐怖、暴力、负面内容，自动引导为正向故事，不采纳危险内容。

请生成一个 {{pageCount}} 页的儿童故事大纲。
角色：{{character}}
地点：{{place}}
时间：{{time}}
剧情方向：{{plot}}
年龄段：{{ageGroup}}岁

仅返回包含 {{pageCount}} 个字符串的 JSON 数组，每个字符串代表一页的简短大纲。
每页描述保持简洁、温暖、安全，适合继续扩写成儿童绘本故事。`,
    sortOrder: 50,
  },
  {
    key: 'speech_generation_prompt',
    title: '语音朗读输入模板',
    category: 'speech',
    description: '发送给 TTS 模型的文本。默认只朗读正文。变量: text',
    variables: ['text'],
    templateText: '{{text}}',
    sortOrder: 55,
  },
  {
    key: 'cover_regeneration_prompt',
    title: '封面重绘提示词',
    category: 'editor',
    description: '故事编辑页重新生成封面时使用。变量: characterDescription, placeDescription, title',
    variables: ['characterDescription', 'placeDescription', 'title'],
    templateText:
      `Children's book cover for a story about {{characterDescription}} in {{placeDescription}}. Title: {{title}}. Colorful, inviting.`,
    sortOrder: 60,
  },
  {
    key: 'page_image_regeneration_prompt',
    title: '单页图片重绘提示词',
    category: 'editor',
    description: '当页面没有 imagePrompt 时，使用正文生成图片提示词。变量: pageText',
    variables: ['pageText'],
    templateText: 'Illustration for: {{pageText}}',
    sortOrder: 70,
  },
  {
    key: 'page_text_regeneration_prompt',
    title: '单页文本改写提示词',
    category: 'editor',
    description: '编辑页对当前页面文本做轻度改写。变量: ageGroup, pageText',
    variables: ['ageGroup', 'pageText'],
    templateText: 'Rewrite this slightly for a {{ageGroup}} year old: "{{pageText}}"',
    sortOrder: 80,
  },
  {
    key: 'wizard_character_image_prompt',
    title: '角色图片提示词',
    category: 'wizard',
    description: '向导中角色选项和角色确认时生成图片。变量: choice',
    variables: ['choice'],
    templateText: 'A cute {{choice}} character',
    sortOrder: 90,
  },
  {
    key: 'wizard_place_image_prompt',
    title: '地点图片提示词',
    category: 'wizard',
    description: '向导中地点选项和地点确认时生成图片。变量: choice',
    variables: ['choice'],
    templateText: 'A cartoon background of {{choice}}',
    sortOrder: 100,
  },
  {
    key: 'wizard_time_image_prompt',
    title: '时间图片提示词',
    category: 'wizard',
    description: '向导中时间选项和时间确认时生成图片。变量: choice',
    variables: ['choice'],
    templateText: "A cartoon scene of {{choice}}, children's book style",
    sortOrder: 110,
  },
  {
    key: 'text_generation_no_ai_fallback',
    title: '文本生成无 AI 兜底',
    category: 'fallback',
    description: 'AI 不可用时，普通文本生成返回的默认文案。',
    variables: [],
    templateText: 'Once upon a time, in a magical land far away...',
    sortOrder: 200,
  },
  {
    key: 'text_generation_error_fallback',
    title: '文本生成失败兜底',
    category: 'fallback',
    description: 'AI 请求失败时，普通文本生成返回的默认文案。',
    variables: [],
    templateText: 'Something magical happened...',
    sortOrder: 210,
  },
  {
    key: 'suggestions_fallback_character',
    title: '角色建议无 AI 兜底',
    category: 'fallback',
    description: 'AI 不可用时，角色建议使用的 JSON 数组字符串。',
    variables: [],
    templateText: '["A brave bunny", "A silly robot", "A dancing cat"]',
    sortOrder: 220,
  },
  {
    key: 'suggestions_fallback_place',
    title: '地点建议无 AI 兜底',
    category: 'fallback',
    description: 'AI 不可用时，地点建议使用的 JSON 数组字符串。',
    variables: [],
    templateText: '["A magical forest", "A cozy treehouse", "An underwater castle"]',
    sortOrder: 230,
  },
  {
    key: 'suggestions_fallback_time',
    title: '时间建议无 AI 兜底',
    category: 'fallback',
    description: 'AI 不可用时，时间建议使用的 JSON 数组字符串。',
    variables: [],
    templateText: '["A sunny morning", "A starry night", "A rainy afternoon"]',
    sortOrder: 240,
  },
  {
    key: 'suggestions_empty_fallback',
    title: '建议空结果兜底',
    category: 'fallback',
    description: 'AI 返回空内容时，建议列表使用的 JSON 数组字符串。',
    variables: [],
    templateText: '["Option 1", "Option 2", "Option 3"]',
    sortOrder: 250,
  },
  {
    key: 'suggestions_error_fallback',
    title: '建议生成失败兜底',
    category: 'fallback',
    description: 'AI 请求异常时，建议列表使用的 JSON 数组字符串。',
    variables: [],
    templateText: '["A funny cat", "A big bear", "A flying fish"]',
    sortOrder: 260,
  },
  {
    key: 'story_segment_no_ai_fallback_text',
    title: '单页故事无 AI 文本兜底',
    category: 'fallback',
    description: 'AI 不可用时，单页故事正文使用的模板。变量: character, place, time, plot',
    variables: ['character', 'place', 'time', 'plot'],
    templateText: '{{character}} was in {{place}} during {{time}}. {{plot}}',
    sortOrder: 270,
  },
  {
    key: 'story_segment_no_ai_fallback_image_prompt',
    title: '单页故事无 AI 配图兜底',
    category: 'fallback',
    description: 'AI 不可用时，单页故事配图提示词使用的模板。变量: character, place',
    variables: ['character', 'place'],
    templateText: '{{character}} in {{place}}',
    sortOrder: 280,
  },
  {
    key: 'story_segment_error_fallback_text',
    title: '单页故事失败文本兜底',
    category: 'fallback',
    description: 'AI 返回异常或 JSON 不合法时，单页故事正文使用的模板。变量: plot',
    variables: ['plot'],
    templateText: '{{plot}}',
    sortOrder: 290,
  },
  {
    key: 'story_segment_error_fallback_image_prompt',
    title: '单页故事失败配图兜底',
    category: 'fallback',
    description: 'AI 返回异常或 JSON 不合法时，单页故事配图提示词使用的模板。变量: plot',
    variables: ['plot'],
    templateText: '{{plot}}',
    sortOrder: 300,
  },
  {
    key: 'story_outline_fallback_intro',
    title: '故事大纲开头兜底',
    category: 'fallback',
    description: '无法生成故事大纲时，第 1 页描述使用的模板。变量: character',
    variables: ['character'],
    templateText: 'Introduction: Meet {{character}}',
    sortOrder: 310,
  },
  {
    key: 'story_outline_fallback_middle',
    title: '故事大纲中间页兜底',
    category: 'fallback',
    description: '无法生成故事大纲时，中间页描述使用的模板。变量: pageNumber',
    variables: ['pageNumber'],
    templateText: 'Page {{pageNumber}}: The adventure continues',
    sortOrder: 320,
  },
  {
    key: 'story_outline_fallback_ending',
    title: '故事大纲结尾兜底',
    category: 'fallback',
    description: '无法生成故事大纲时，最后一页描述使用的模板。变量: character',
    variables: ['character'],
    templateText: 'Ending: {{character}} lives happily',
    sortOrder: 330,
  },
  {
    key: 'story_outline_missing_page_fallback',
    title: '故事大纲缺页兜底',
    category: 'fallback',
    description: '故事大纲数组某一页缺失时，当前页上下文使用的模板。变量: pageNumber',
    variables: ['pageNumber'],
    templateText: 'Page {{pageNumber}} of the story',
    sortOrder: 340,
  },
];

const PROMPT_SELECT = `
  SELECT
    prompt_key AS \`key\`,
    title,
    category,
    description,
    variables_json AS variablesJson,
    template_text AS templateText,
    default_template AS defaultTemplate,
    sort_order AS sortOrder,
    UNIX_TIMESTAMP(created_at) * 1000 AS createdAt,
    UNIX_TIMESTAMP(updated_at) * 1000 AS updatedAt
  FROM prompt_templates
`;

const isMissingTableError = (error) => error && error.code === 'ER_NO_SUCH_TABLE';

const assertCanManagePrompts = (actor) => {
  if (!actor || actor.role !== 'super_admin') {
    throw forbidden('Only platform admins can manage prompt templates');
  }
};

const normalizePromptRow = (row) => ({
  key: row.key,
  title: row.title,
  category: row.category,
  description: row.description || '',
  variables: parseJsonColumn(row.variablesJson, []),
  templateText: row.templateText,
  defaultTemplate: row.defaultTemplate,
  sortOrder: row.sortOrder || 0,
  createdAt: row.createdAt || null,
  updatedAt: row.updatedAt || null,
});

const buildDefaultRows = () => {
  return DEFAULT_PROMPT_TEMPLATES.map((item) => ({
    ...item,
    defaultTemplate: item.templateText,
    createdAt: null,
    updatedAt: null,
  }));
};

const syncDefaultPromptTemplates = async () => {
  for (const item of DEFAULT_PROMPT_TEMPLATES) {
    await execute(
      `INSERT INTO prompt_templates (
        prompt_key,
        title,
        category,
        description,
        variables_json,
        template_text,
        default_template,
        sort_order,
        created_at,
        updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
      ON DUPLICATE KEY UPDATE
        title = VALUES(title),
        category = VALUES(category),
        description = VALUES(description),
        variables_json = VALUES(variables_json),
        default_template = VALUES(default_template),
        sort_order = VALUES(sort_order)`,
      [
        item.key,
        item.title,
        item.category,
        item.description,
        JSON.stringify(item.variables),
        item.templateText,
        item.templateText,
        item.sortOrder,
      ],
    );
  }
};

const findDefaultPrompt = (key) => {
  return DEFAULT_PROMPT_TEMPLATES.find((item) => item.key === key) || null;
};

export const listPromptTemplates = async (actor) => {
  assertCanManagePrompts(actor);

  try {
    await syncDefaultPromptTemplates();
    const rows = await queryRows(`${PROMPT_SELECT} ORDER BY sort_order ASC, prompt_key ASC`);
    return rows.map(normalizePromptRow);
  } catch (error) {
    if (isMissingTableError(error)) {
      return buildDefaultRows();
    }
    throw error;
  }
};

export const getPublicPromptTemplateMap = async () => {
  try {
    await syncDefaultPromptTemplates();
    const rows = await queryRows(`${PROMPT_SELECT} ORDER BY sort_order ASC, prompt_key ASC`);
    return rows.reduce((result, row) => {
      result[row.key] = row.templateText;
      return result;
    }, {});
  } catch (error) {
    if (isMissingTableError(error)) {
      return buildDefaultRows().reduce((result, row) => {
        result[row.key] = row.templateText;
        return result;
      }, {});
    }
    throw error;
  }
};

export const updatePromptTemplate = async (actor, key, payload) => {
  assertCanManagePrompts(actor);

  const templateText = payload?.templateText?.trim();
  if (!templateText) {
    throw badRequest('templateText is required');
  }

  const defaultPrompt = findDefaultPrompt(key);
  if (!defaultPrompt) {
    throw notFound('Prompt template not found');
  }

  try {
    await syncDefaultPromptTemplates();

    const existing = await queryOne(`${PROMPT_SELECT} WHERE prompt_key = ?`, [key]);
    if (!existing) {
      await execute(
        `INSERT INTO prompt_templates (
          prompt_key,
          title,
          category,
          description,
          variables_json,
          template_text,
          default_template,
          sort_order,
          created_at,
          updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())`,
        [
          defaultPrompt.key,
          defaultPrompt.title,
          defaultPrompt.category,
          defaultPrompt.description,
          JSON.stringify(defaultPrompt.variables),
          templateText,
          defaultPrompt.templateText,
          defaultPrompt.sortOrder,
        ],
      );
    } else {
      await execute(
        `UPDATE prompt_templates
         SET template_text = ?, updated_at = NOW()
         WHERE prompt_key = ?`,
        [templateText, key],
      );
    }

    const saved = await queryOne(`${PROMPT_SELECT} WHERE prompt_key = ?`, [key]);
    return normalizePromptRow(saved);
  } catch (error) {
    if (isMissingTableError(error)) {
      throw badRequest('prompt_templates table is missing. Please execute server/sql/schema.mysql.sql first.');
    }
    throw error;
  }
};
