import { createHmac } from 'crypto';
import { env } from '../config/env.js';
import { HttpError } from '../lib/httpError.js';

const hasIflytekSpeechConfig = () => {
  return Boolean(env.iflytekAppId && env.iflytekApiKey && env.iflytekApiSecret);
};

export const getIflytekSpeechAuth = () => {
  if (!hasIflytekSpeechConfig()) {
    throw new HttpError(503, 'iFlytek speech input is not configured on the server.');
  }

  const date = new Date().toUTCString();
  const signatureOrigin = `host: ${env.iflytekIatHost}\ndate: ${date}\nGET ${env.iflytekIatPath} HTTP/1.1`;
  const signature = createHmac('sha256', env.iflytekApiSecret)
    .update(signatureOrigin)
    .digest('base64');

  const authorizationOrigin =
    `api_key="${env.iflytekApiKey}", algorithm="hmac-sha256", headers="host date request-line", signature="${signature}"`;
  const authorization = Buffer.from(authorizationOrigin).toString('base64');
  const query = new URLSearchParams({
    authorization,
    date,
    host: env.iflytekIatHost,
  });

  return {
    appId: env.iflytekAppId,
    url: `wss://${env.iflytekIatHost}${env.iflytekIatPath}?${query.toString()}`,
  };
};
