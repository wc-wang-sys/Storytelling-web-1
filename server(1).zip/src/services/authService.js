import crypto from 'crypto';
import { env } from '../config/env.js';
import { queryOne, queryRows, execute, withTransaction } from '../db/pool.js';
import { badRequest, forbidden, notFound, unauthorized } from '../lib/httpError.js';
import { hashPassword, verifyPassword, signToken, verifyToken } from '../lib/security.js';

const FRONTEND_ROLE_MAP = {
  student: 'Student',
  teacher: 'Teacher',
  school_admin: 'Tester',
  super_admin: 'Tester',
};

const ACCOUNT_SELECT = `
  SELECT
    a.id,
    a.username,
    a.display_name AS displayName,
    a.role,
    COALESCE(a.school_id, t.school_id, st.school_id) AS schoolId,
    a.teacher_id AS teacherId,
    a.student_id AS studentId,
    a.status,
    s.name AS schoolName,
    t.name AS teacherName,
    st.name AS studentName,
    st.class_id AS classId,
    st.age_group AS ageGroup
  FROM accounts a
  LEFT JOIN teachers t ON t.id = a.teacher_id
  LEFT JOIN students st ON st.id = a.student_id
  LEFT JOIN schools s ON s.id = COALESCE(a.school_id, t.school_id, st.school_id)
`;

const ACCOUNT_SELECT_WITH_PASSWORD = `
  SELECT
    a.id,
    a.username,
    a.password_hash AS passwordHash,
    a.display_name AS displayName,
    a.role,
    COALESCE(a.school_id, t.school_id, st.school_id) AS schoolId,
    a.teacher_id AS teacherId,
    a.student_id AS studentId,
    a.status,
    s.name AS schoolName,
    t.name AS teacherName,
    st.name AS studentName,
    st.class_id AS classId,
    st.age_group AS ageGroup
  FROM accounts a
  LEFT JOIN teachers t ON t.id = a.teacher_id
  LEFT JOIN students st ON st.id = a.student_id
  LEFT JOIN schools s ON s.id = COALESCE(a.school_id, t.school_id, st.school_id)
`;

const mapAccountSession = async (accountRow) => {
  if (!accountRow) {
    return null;
  }

  let classIds = [];

  if (accountRow.role === 'teacher' && accountRow.teacherId) {
    const teacherClassRows = await queryRows(
      'SELECT class_id AS classId FROM teacher_classes WHERE teacher_id = ? ORDER BY created_at ASC',
      [accountRow.teacherId],
    );
    classIds = teacherClassRows.map((row) => row.classId);
  }

  return {
    id: accountRow.id,
    name: accountRow.displayName,
    username: accountRow.username,
    role: FRONTEND_ROLE_MAP[accountRow.role] || 'Student',
    backendRole: accountRow.role,
    schoolId: accountRow.schoolId,
    schoolName: accountRow.schoolName,
    teacherId: accountRow.teacherId,
    studentId: accountRow.studentId,
    classId: accountRow.classId || null,
    classIds,
    ageGroup: accountRow.ageGroup || null,
    points: 0,
    badges: [],
  };
};

export const getAccountById = async (accountId) => {
  return queryOne(`${ACCOUNT_SELECT} WHERE a.id = ?`, [accountId]);
};

export const getAccountByUsername = async (username) => {
  return queryOne(`${ACCOUNT_SELECT} WHERE a.username = ?`, [username]);
};

export const getTeacherClassIds = async (teacherId) => {
  if (!teacherId) {
    return [];
  }

  const rows = await queryRows(
    'SELECT class_id AS classId FROM teacher_classes WHERE teacher_id = ? ORDER BY created_at ASC',
    [teacherId],
  );

  return rows.map((row) => row.classId);
};

export const issueAccessToken = (accountRow) => {
  return signToken(
    {
      type: 'access',
      accountId: accountRow.id,
      role: accountRow.role,
    },
    env.accessTokenTtlSeconds,
  );
};

export const buildAuthResponse = async (accountRow) => {
  const user = await mapAccountSession(accountRow);
  return {
    accessToken: issueAccessToken(accountRow),
    user,
  };
};

export const loginWithPassword = async ({ username, password }) => {
  if (!username || !password) {
    throw badRequest('Username and password are required');
  }

  const account = await queryOne(
    `${ACCOUNT_SELECT_WITH_PASSWORD} WHERE a.username = ?`,
    [username],
  );

  if (!account || !verifyPassword(password, account.passwordHash)) {
    throw unauthorized('Incorrect username or password');
  }

  if (account.status !== 'active') {
    throw forbidden('Account is disabled');
  }

  await execute('UPDATE accounts SET last_login_at = NOW() WHERE id = ?', [account.id]);

  return buildAuthResponse(account);
};

const resolveTeacherForClass = async (classId) => {
  const teacherClass = await queryOne(
    'SELECT teacher_id AS teacherId FROM teacher_classes WHERE class_id = ? ORDER BY created_at ASC LIMIT 1',
    [classId],
  );
  return teacherClass?.teacherId || null;
};

export const registerStudent = async ({ fullName, username, password, schoolId, classId, teacherId, ageGroup }) => {
  if (!fullName || !username || !password || !schoolId || !classId) {
    throw badRequest('fullName, username, password, schoolId and classId are required');
  }

  const school = await queryOne('SELECT id, status FROM schools WHERE id = ?', [schoolId]);
  if (!school || school.status !== 'active') {
    throw notFound('School not found');
  }

  const schoolClass = await queryOne(
    'SELECT id, school_id AS schoolId, status FROM classes WHERE id = ?',
    [classId],
  );
  if (!schoolClass || schoolClass.schoolId !== schoolId || schoolClass.status !== 'active') {
    throw badRequest('Class does not belong to the selected school');
  }

  const duplicatedAccount = await getAccountByUsername(username);
  if (duplicatedAccount) {
    throw badRequest('Username already exists');
  }

  const finalTeacherId = teacherId || (await resolveTeacherForClass(classId));
  const studentId = crypto.randomUUID();
  const accountId = crypto.randomUUID();

  await withTransaction(async (connection) => {
    await connection.execute(
      `INSERT INTO students (
        id, school_id, class_id, teacher_id, student_no, name, age_group, status, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, 'active', NOW(), NOW())`,
      [
        studentId,
        schoolId,
        classId,
        finalTeacherId,
        `STU-${Date.now()}`,
        fullName,
        ageGroup || '5-7',
      ],
    );

    await connection.execute(
      `INSERT INTO accounts (
        id, username, password_hash, display_name, role, school_id, student_id, status, created_at, updated_at
      ) VALUES (?, ?, ?, ?, 'student', ?, ?, 'active', NOW(), NOW())`,
      [
        accountId,
        username,
        hashPassword(password),
        fullName,
        null,
        studentId,
      ],
    );
  });

  const createdAccount = await getAccountById(accountId);
  return buildAuthResponse(createdAccount);
};

export const meFromToken = async (token) => {
  const payload = verifyToken(token, 'access');
  const account = await getAccountById(payload.accountId);
  if (!account || account.status !== 'active') {
    throw unauthorized('Account is unavailable');
  }
  return mapAccountSession(account);
};

const QR_ROLE_MAP = {
  school: 'school_admin',
  teacher: 'teacher',
  student: 'student',
};

const getAccountForQrEntity = async ({ type, id }) => {
  if (type === 'school') {
    return queryOne(`${ACCOUNT_SELECT} WHERE a.role = 'school_admin' AND a.school_id = ?`, [id]);
  }

  if (type === 'teacher') {
    return queryOne(`${ACCOUNT_SELECT} WHERE a.role = 'teacher' AND a.teacher_id = ?`, [id]);
  }

  if (type === 'student') {
    return queryOne(`${ACCOUNT_SELECT} WHERE a.role = 'student' AND a.student_id = ?`, [id]);
  }

  return null;
};

const canGenerateQr = async (actor, type, targetAccount) => {
  if (!targetAccount) {
    throw notFound('Target account not found');
  }

  if (actor.role === 'super_admin') {
    return true;
  }

  if (actor.role === 'school_admin') {
    return targetAccount.schoolId === actor.schoolId;
  }

  if (actor.role === 'teacher') {
    return type === 'teacher' && targetAccount.teacherId === actor.teacherId;
  }

  if (actor.role === 'student') {
    return type === 'student' && targetAccount.studentId === actor.studentId;
  }

  return false;
};

export const generateQrLoginToken = async (actor, { type, id }) => {
  if (!type || !id || !QR_ROLE_MAP[type]) {
    throw badRequest('QR type must be school, teacher or student');
  }

  const targetAccount = await getAccountForQrEntity({ type, id });
  if (!(await canGenerateQr(actor, type, targetAccount))) {
    throw forbidden('You are not allowed to generate this QR code');
  }

  const qrRowId = crypto.randomUUID();
  const expiresAt = new Date(Date.now() + env.qrTokenTtlDays * 24 * 60 * 60 * 1000);
  const token = signToken(
    {
      type: 'qr_login',
      qrRowId,
      accountId: targetAccount.id,
      role: targetAccount.role,
    },
    env.qrTokenTtlDays * 24 * 60 * 60,
  );

  await withTransaction(async (connection) => {
    await connection.execute(
      "UPDATE qr_login_tokens SET status = 'revoked' WHERE account_id = ? AND status = 'active'",
      [targetAccount.id],
    );

    await connection.execute(
      `INSERT INTO qr_login_tokens (
        id, account_id, entity_type, entity_id, token, status, expires_at, created_at
      ) VALUES (?, ?, ?, ?, ?, 'active', ?, NOW())`,
      [qrRowId, targetAccount.id, targetAccount.role, id, token, expiresAt],
    );
  });

  return {
    token,
    expiresAt: expiresAt.toISOString(),
    entity: {
      type,
      id,
      accountId: targetAccount.id,
      displayName: targetAccount.displayName,
      role: targetAccount.role,
    },
  };
};

export const loginWithQrToken = async (qrToken) => {
  if (!qrToken) {
    throw badRequest('QR token is required');
  }

  const payload = verifyToken(qrToken, 'qr_login');
  const qrRecord = await queryOne(
    `SELECT id, account_id AS accountId, status, expires_at AS expiresAt
     FROM qr_login_tokens
     WHERE id = ? AND token = ?`,
    [payload.qrRowId, qrToken],
  );

  if (!qrRecord || qrRecord.status !== 'active') {
    throw unauthorized('QR code is invalid');
  }

  if (new Date(qrRecord.expiresAt).getTime() < Date.now()) {
    await execute("UPDATE qr_login_tokens SET status = 'expired' WHERE id = ?", [qrRecord.id]);
    throw unauthorized('QR code expired');
  }

  const account = await getAccountById(qrRecord.accountId);
  if (!account || account.status !== 'active') {
    throw unauthorized('Account is unavailable');
  }

  await execute('UPDATE accounts SET last_login_at = NOW() WHERE id = ?', [account.id]);

  return buildAuthResponse(account);
};
