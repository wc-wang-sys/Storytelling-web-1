import crypto from 'crypto';
import { queryOne, queryRows, execute } from '../db/pool.js';
import { badRequest, forbidden, notFound } from '../lib/httpError.js';
import { parseJsonColumn } from '../lib/serializers.js';
import { getStudentById } from './orgService.js';
import { getTeacherClassIds } from './authService.js';

const STORY_LIST_SELECT = `
  SELECT
    st.id,
    st.school_id AS schoolId,
    st.class_id AS classId,
    st.teacher_id AS teacherId,
    st.student_id AS studentId,
    st.title,
    st.cover_image AS coverImage,
    st.author_id AS authorId,
    st.author_name AS authorName,
    st.age_group AS ageGroup,
    st.status,
    UNIX_TIMESTAMP(st.created_at) * 1000 AS createdAt,
    UNIX_TIMESTAMP(st.updated_at) * 1000 AS updatedAt,
    stu.name AS studentName,
    c.name AS className,
    s.name AS schoolName
  FROM stories st
  LEFT JOIN students stu ON stu.id = st.student_id
  LEFT JOIN classes c ON c.id = st.class_id
  LEFT JOIN schools s ON s.id = st.school_id
`;

const STORY_DETAIL_SELECT = `
  SELECT
    st.id,
    st.school_id AS schoolId,
    st.class_id AS classId,
    st.teacher_id AS teacherId,
    st.student_id AS studentId,
    st.title,
    st.cover_image AS coverImage,
    st.author_id AS authorId,
    st.author_name AS authorName,
    st.age_group AS ageGroup,
    st.character_payload AS characterPayload,
    st.place_payload AS placePayload,
    st.time_label AS time,
    st.pages_payload AS pagesPayload,
    st.styling_payload AS stylingPayload,
    st.status,
    UNIX_TIMESTAMP(st.created_at) * 1000 AS createdAt,
    UNIX_TIMESTAMP(st.updated_at) * 1000 AS updatedAt,
    stu.name AS studentName,
    c.name AS className,
    s.name AS schoolName
  FROM stories st
  LEFT JOIN students stu ON stu.id = st.student_id
  LEFT JOIN classes c ON c.id = st.class_id
  LEFT JOIN schools s ON s.id = st.school_id
`;

const STORY_ORDER_SELECT = `
  SELECT
    st.id
  FROM stories st
  LEFT JOIN students stu ON stu.id = st.student_id
`;

const MAX_COVER_IMAGE_LENGTH = 60000;

const sanitizePages = (pages) => {
  if (!Array.isArray(pages)) {
    return [];
  }

  return pages.map((page) => {
    if (!page || typeof page !== 'object') {
      return {
        text: '',
        imageUrl: '',
      };
    }

    return {
      text: page.text || '',
      imageUrl: page.imageUrl || '',
      imagePrompt: page.imagePrompt || '',
    };
  });
};

const resolveCoverImage = (coverImage, pages) => {
  if (coverImage) {
    return coverImage;
  }

  return pages[0]?.imageUrl || '';
};

const toStoredCoverImage = (coverImage) => {
  if (!coverImage || coverImage.length <= MAX_COVER_IMAGE_LENGTH) {
    return coverImage || '';
  }

  // Large data URLs are already stored in pages_payload; avoid duplicating them in the TEXT cover_image column.
  return '';
};

const mapStory = (row, includeContent = true) => {
  if (!row) {
    return null;
  }

  const pages = row.pagesPayload === undefined ? [] : parseJsonColumn(row.pagesPayload, []);
  const resolvedCoverImage = resolveCoverImage(row.coverImage, pages);

  const base = {
    id: row.id,
    storyId: row.id,
    schoolId: row.schoolId,
    schoolName: row.schoolName,
    classId: row.classId,
    className: row.className,
    teacherId: row.teacherId,
    studentId: row.studentId,
    studentName: row.studentName,
    title: row.title,
    coverImage: resolvedCoverImage,
    authorId: row.authorId,
    authorName: row.authorName,
    ageGroup: row.ageGroup,
    status: row.status,
    createdAt: row.createdAt,
    updatedAt: row.updatedAt,
  };

  if (!includeContent) {
    return base;
  }

  return {
    ...base,
    character: parseJsonColumn(row.characterPayload, {}),
    place: parseJsonColumn(row.placePayload, {}),
    time: row.time,
    pages,
    styling: parseJsonColumn(row.stylingPayload, {}),
  };
};

const buildScopedFilters = async (actor, filters = {}) => {
  const where = [];
  const params = [];

  if (actor.role === 'student') {
    where.push('st.student_id = ?');
    params.push(actor.studentId);
  }

  if (actor.role === 'school_admin') {
    where.push('st.school_id = ?');
    params.push(actor.schoolId);
  }

  if (actor.role === 'teacher') {
    const classIds = await getTeacherClassIds(actor.teacherId);
    if (classIds.length === 0) {
      return { where: ['1 = 0'], params: [] };
    }
    where.push(`st.class_id IN (${classIds.map(() => '?').join(', ')})`);
    params.push(...classIds);
  }

  if (filters.schoolId) {
    if (actor.role !== 'super_admin' && actor.schoolId !== filters.schoolId) {
      throw forbidden('You cannot access another school');
    }
    where.push('st.school_id = ?');
    params.push(filters.schoolId);
  }

  if (filters.classId) {
    where.push('st.class_id = ?');
    params.push(filters.classId);
  }

  if (filters.studentId) {
    if (actor.role === 'student' && actor.studentId !== filters.studentId) {
      throw forbidden('You cannot access another student');
    }
    where.push('st.student_id = ?');
    params.push(filters.studentId);
  }

  if (filters.search) {
    where.push('(st.title LIKE ? OR st.author_name LIKE ? OR stu.name LIKE ?)');
    const pattern = `%${filters.search}%`;
    params.push(pattern, pattern, pattern);
  }

  return { where, params };
};

const ensureStoryAccess = async (actor, storyId) => {
  const scoped = await buildScopedFilters(actor, {});
  const story = await queryOne(
    `${STORY_DETAIL_SELECT}
     WHERE st.id = ?
     ${scoped.where.length ? `AND ${scoped.where.join(' AND ')}` : ''}`,
    [storyId, ...scoped.params],
  );

  if (!story) {
    throw notFound('Story not found');
  }

  return story;
};

const fetchOrderedStoryIds = async (actor, filters = {}) => {
  const scoped = await buildScopedFilters(actor, filters);

  const rows = await queryRows(
    `${STORY_ORDER_SELECT}
     ${scoped.where.length ? `WHERE ${scoped.where.join(' AND ')}` : ''}
     ORDER BY st.updated_at DESC`,
    scoped.params,
  );

  return rows.map((row) => row.id);
};

const fetchStoriesByIds = async (storyIds, includeContent) => {
  if (storyIds.length === 0) {
    return [];
  }

  const placeholders = storyIds.map(() => '?').join(', ');
  const rows = await queryRows(
    `${includeContent ? STORY_DETAIL_SELECT : STORY_LIST_SELECT}
     WHERE st.id IN (${placeholders})`,
    storyIds,
  );

  const byId = new Map(rows.map((row) => [row.id, row]));

  return storyIds
    .map((storyId) => mapStory(byId.get(storyId), includeContent))
    .filter(Boolean);
};

export const listStories = async (actor, filters = {}) => {
  const includeContent = filters.includeContent === true || filters.includeContent === 'true';
  const storyIds = await fetchOrderedStoryIds(actor, filters);
  return fetchStoriesByIds(storyIds, includeContent);
};

export const getStoryById = async (actor, storyId) => {
  const story = await ensureStoryAccess(actor, storyId);
  return mapStory(story, true);
};

const getStoryTargetContext = async (actor, payload) => {
  if (actor.role === 'student') {
    const student = await getStudentById(actor.studentId);
    if (!student) {
      throw notFound('Student profile not found');
    }

    return {
      schoolId: student.schoolId,
      classId: student.classId,
      teacherId: student.teacherId,
      studentId: student.id,
      authorId: payload.authorId || student.id,
      authorName: payload.authorName || student.name,
      ageGroup: payload.ageGroup || student.ageGroup,
    };
  }

  if (!payload.studentId) {
    throw badRequest('studentId is required');
  }

  const student = await getStudentById(payload.studentId);
  if (!student) {
    throw notFound('Student not found');
  }

  if (actor.role === 'school_admin' && actor.schoolId !== student.schoolId) {
    throw forbidden('You cannot create stories for another school');
  }

  if (actor.role === 'teacher') {
    const classIds = await getTeacherClassIds(actor.teacherId);
    if (!classIds.includes(student.classId)) {
      throw forbidden('You cannot create stories outside your classes');
    }
  }

  return {
    schoolId: student.schoolId,
    classId: student.classId,
    teacherId: student.teacherId,
    studentId: student.id,
    authorId: payload.authorId || student.id,
    authorName: payload.authorName || student.name,
    ageGroup: payload.ageGroup || student.ageGroup,
  };
};

export const createStory = async (actor, payload) => {
  if (!payload.title || !Array.isArray(payload.pages) || payload.pages.length === 0) {
    throw badRequest('title and pages are required');
  }

  const context = await getStoryTargetContext(actor, payload);
  const storyId = crypto.randomUUID();
  const pages = sanitizePages(payload.pages);
  const coverImage = resolveCoverImage(payload.coverImage || '', pages);

  await execute(
    `INSERT INTO stories (
      id, school_id, class_id, teacher_id, student_id, title, cover_image, author_id, author_name,
      age_group, character_payload, place_payload, time_label, pages_payload, styling_payload, status, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())`,
    [
      storyId,
      context.schoolId,
      context.classId,
      context.teacherId,
      context.studentId,
      payload.title,
      toStoredCoverImage(coverImage),
      context.authorId,
      context.authorName,
      context.ageGroup || '5-7',
      JSON.stringify(payload.character || {}),
      JSON.stringify(payload.place || {}),
      payload.time || '',
      JSON.stringify(pages),
      JSON.stringify(payload.styling || {}),
      payload.status || 'published',
    ],
  );

  return getStoryById(actor, storyId);
};

export const updateStory = async (actor, storyId, payload) => {
  const existing = await ensureStoryAccess(actor, storyId);
  const nextPages = sanitizePages(payload.pages || parseJsonColumn(existing.pagesPayload, []));
  const nextCoverImage = resolveCoverImage(
    payload.coverImage || existing.coverImage || '',
    nextPages,
  );

  await execute(
    `UPDATE stories
     SET title = ?, cover_image = ?, character_payload = ?, place_payload = ?, time_label = ?,
         pages_payload = ?, styling_payload = ?, status = ?, updated_at = NOW()
     WHERE id = ?`,
    [
      payload.title || existing.title,
      toStoredCoverImage(nextCoverImage),
      JSON.stringify(payload.character || parseJsonColumn(existing.characterPayload, {})),
      JSON.stringify(payload.place || parseJsonColumn(existing.placePayload, {})),
      payload.time || existing.time,
      JSON.stringify(nextPages),
      JSON.stringify(payload.styling || parseJsonColumn(existing.stylingPayload, {})),
      payload.status || existing.status,
      storyId,
    ],
  );

  return getStoryById(actor, storyId);
};

export const deleteStory = async (actor, storyId) => {
  await ensureStoryAccess(actor, storyId);
  const result = await execute('DELETE FROM stories WHERE id = ?', [storyId]);
  return result.affectedRows > 0;
};
