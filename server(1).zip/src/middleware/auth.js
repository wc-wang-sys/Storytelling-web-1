import { asyncHandler } from '../lib/asyncHandler.js';
import { unauthorized, forbidden } from '../lib/httpError.js';
import { verifyToken } from '../lib/security.js';
import { getAccountById, getTeacherClassIds } from '../services/authService.js';

const readBearerToken = (req) => {
  const header = req.headers.authorization || '';
  if (!header.startsWith('Bearer ')) {
    return null;
  }
  return header.slice('Bearer '.length).trim();
};

export const requireAuth = asyncHandler(async (req, _res, next) => {
  const token = readBearerToken(req);
  if (!token) {
    throw unauthorized('Authorization token is required');
  }

  const payload = verifyToken(token, 'access');
  const account = await getAccountById(payload.accountId);

  if (!account || account.status !== 'active') {
    throw unauthorized('Account is unavailable');
  }

  req.user = {
    ...account,
    role: account.backendRole || payload.role,
    classIds: account.teacherId ? await getTeacherClassIds(account.teacherId) : [],
  };

  next();
});

export const authorize = (...roles) => (req, _res, next) => {
  if (!req.user) {
    throw unauthorized();
  }

  if (!roles.includes(req.user.role)) {
    throw forbidden('Permission denied');
  }

  next();
};

