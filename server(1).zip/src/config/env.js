import dotenv from 'dotenv';

dotenv.config();

const normalizeOrigin = (value) => {
  if (!value) {
    return null;
  }

  return value.trim().replace(/\/+$/, '') || null;
};

const parseOrigins = (...values) => {
  return [...new Set(
    values
      .flatMap((value) => String(value || '').split(','))
      .map(normalizeOrigin)
      .filter(Boolean),
  )];
};

const toNumber = (value, fallback) => {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
};

const clientOrigins = parseOrigins(
  process.env.CLIENT_ORIGIN,
  'http://localhost:5173',
  'http://127.0.0.1:5173',
  'http://localhost:3000',
  'http://127.0.0.1:3000',
);

const adminOrigins = parseOrigins(
  process.env.ADMIN_ORIGIN,
  'http://localhost:5174',
  'http://127.0.0.1:5174',
);

export const env = {
  port: toNumber(process.env.PORT, 3030),
  dbHost: process.env.DB_HOST || '127.0.0.1',
  dbPort: toNumber(process.env.DB_PORT, 3306),
  dbName: process.env.DB_NAME || 'storytelling',
  dbUser: process.env.DB_USER || 'root',
  dbPassword: process.env.DB_PASSWORD || '',
  tokenSecret: process.env.TOKEN_SECRET || 'storytelling-dev-secret',
  accessTokenTtlSeconds: toNumber(process.env.ACCESS_TOKEN_TTL_SECONDS, 24 * 60 * 60),
  qrTokenTtlDays: toNumber(process.env.QR_TOKEN_TTL_DAYS, 30),
  clientOrigin: clientOrigins[0] || 'http://localhost:5173',
  adminOrigin: adminOrigins[0] || 'http://localhost:5174',
  allowedOrigins: [...new Set([...clientOrigins, ...adminOrigins])],
  allowedDevPorts: [3000, 3030, 5173, 5174],
  jsonBodyLimit: process.env.JSON_BODY_LIMIT || '25mb',
  iflytekAppId: process.env.IFLYTEK_APP_ID || '',
  iflytekApiKey: process.env.IFLYTEK_API_KEY || '',
  iflytekApiSecret: process.env.IFLYTEK_API_SECRET || '',
  iflytekIatHost: process.env.IFLYTEK_IAT_HOST || 'iat-api.xfyun.cn',
  iflytekIatPath: process.env.IFLYTEK_IAT_PATH || '/v2/iat',
};
