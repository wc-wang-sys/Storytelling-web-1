import { Router } from 'express';
import { asyncHandler } from '../lib/asyncHandler.js';
import { sendSuccess } from '../lib/response.js';
import {
  loginWithPassword,
  registerStudent,
  loginWithQrToken,
  meFromToken,
} from '../services/authService.js';
import { requireAuth } from '../middleware/auth.js';

export const authRoutes = Router();

authRoutes.post(
  '/register/student',
  asyncHandler(async (req, res) => {
    sendSuccess(res, await registerStudent(req.body), 201);
  }),
);

authRoutes.post(
  '/login/password',
  asyncHandler(async (req, res) => {
    sendSuccess(res, await loginWithPassword(req.body));
  }),
);

authRoutes.post(
  '/login/qr',
  asyncHandler(async (req, res) => {
    sendSuccess(res, await loginWithQrToken(req.body.token));
  }),
);

authRoutes.get(
  '/me',
  requireAuth,
  asyncHandler(async (req, res) => {
    const token = req.headers.authorization.slice('Bearer '.length).trim();
    sendSuccess(res, await meFromToken(token));
  }),
);

