import { Router } from 'express';
import { asyncHandler } from '../lib/asyncHandler.js';
import { sendSuccess } from '../lib/response.js';
import { requireAuth } from '../middleware/auth.js';
import { generateQrLoginToken } from '../services/authService.js';

export const qrRoutes = Router();

qrRoutes.use(requireAuth);

qrRoutes.get(
  '/generate',
  asyncHandler(async (req, res) => {
    sendSuccess(
      res,
      await generateQrLoginToken(req.user, {
        type: req.query.type,
        id: req.query.id,
      }),
    );
  }),
);

