import { Router } from 'express';
import { asyncHandler } from '../lib/asyncHandler.js';
import { sendSuccess } from '../lib/response.js';
import { requireAuth } from '../middleware/auth.js';
import {
  listTeachers,
  createTeacher,
  updateTeacher,
  deleteTeacher,
} from '../services/orgService.js';

export const teacherRoutes = Router();

teacherRoutes.use(requireAuth);

teacherRoutes.get(
  '/',
  asyncHandler(async (req, res) => {
    sendSuccess(res, await listTeachers(req.user, req.query));
  }),
);

teacherRoutes.post(
  '/',
  asyncHandler(async (req, res) => {
    sendSuccess(res, await createTeacher(req.user, req.body), 201);
  }),
);

teacherRoutes.patch(
  '/:id',
  asyncHandler(async (req, res) => {
    sendSuccess(res, await updateTeacher(req.user, req.params.id, req.body));
  }),
);

teacherRoutes.delete(
  '/:id',
  asyncHandler(async (req, res) => {
    sendSuccess(res, await deleteTeacher(req.user, req.params.id));
  }),
);

