import { Router } from 'express';
import { asyncHandler } from '../lib/asyncHandler.js';
import { sendSuccess } from '../lib/response.js';
import { listPublicSchools, listPublicClasses } from '../services/orgService.js';
import { getPublicPromptTemplateMap } from '../services/promptService.js';
import { getIflytekSpeechAuth } from '../services/speechService.js';

export const publicRoutes = Router();

publicRoutes.get(
  '/schools',
  asyncHandler(async (_req, res) => {
    sendSuccess(res, await listPublicSchools());
  }),
);

publicRoutes.get(
  '/classes',
  asyncHandler(async (req, res) => {
    sendSuccess(res, await listPublicClasses(req.query.schoolId));
  }),
);

publicRoutes.get(
  '/prompts',
  asyncHandler(async (_req, res) => {
    sendSuccess(res, await getPublicPromptTemplateMap());
  }),
);

publicRoutes.get(
  '/speech/iflytek-auth',
  asyncHandler(async (_req, res) => {
    sendSuccess(res, getIflytekSpeechAuth());
  }),
);
