import { Router } from 'express';
import { asyncHandler } from '../lib/asyncHandler.js';
import { sendSuccess } from '../lib/response.js';
import { requireAuth } from '../middleware/auth.js';
import {
  listClasses,
  createClass,
  updateClass,
  deleteClass,
} from '../services/orgService.js';

export const classRoutes = Router();

classRoutes.use(requireAuth);

classRoutes.get(
  '/',
  asyncHandler(async (req, res) => {
    sendSuccess(res, await listClasses(req.user, req.query));
  }),
);

classRoutes.post(
  '/',
  asyncHandler(async (req, res) => {
    sendSuccess(res, await createClass(req.user, req.body), 201);
  }),
);

classRoutes.patch(
  '/:id',
  asyncHandler(async (req, res) => {
    sendSuccess(res, await updateClass(req.user, req.params.id, req.body));
  }),
);

classRoutes.delete(
  '/:id',
  asyncHandler(async (req, res) => {
    sendSuccess(res, await deleteClass(req.user, req.params.id));
  }),
);

