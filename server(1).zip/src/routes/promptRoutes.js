import { Router } from 'express';
import { asyncHandler } from '../lib/asyncHandler.js';
import { sendSuccess } from '../lib/response.js';
import { requireAuth } from '../middleware/auth.js';
import { listPromptTemplates, updatePromptTemplate } from '../services/promptService.js';

export const promptRoutes = Router();

promptRoutes.use(requireAuth);

promptRoutes.get(
  '/',
  asyncHandler(async (req, res) => {
    sendSuccess(res, await listPromptTemplates(req.user));
  }),
);

promptRoutes.patch(
  '/:key',
  asyncHandler(async (req, res) => {
    sendSuccess(res, await updatePromptTemplate(req.user, req.params.key, req.body));
  }),
);
