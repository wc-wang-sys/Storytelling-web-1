import { Router } from 'express';
import { asyncHandler } from '../lib/asyncHandler.js';
import { sendSuccess } from '../lib/response.js';
import { requireAuth } from '../middleware/auth.js';
import {
  listStories,
  getStoryById,
  createStory,
  updateStory,
  deleteStory,
} from '../services/storyService.js';

export const storyRoutes = Router();

storyRoutes.use(requireAuth);

storyRoutes.get(
  '/',
  asyncHandler(async (req, res) => {
    sendSuccess(res, await listStories(req.user, req.query));
  }),
);

storyRoutes.get(
  '/:id',
  asyncHandler(async (req, res) => {
    sendSuccess(res, await getStoryById(req.user, req.params.id));
  }),
);

storyRoutes.post(
  '/',
  asyncHandler(async (req, res) => {
    sendSuccess(res, await createStory(req.user, req.body), 201);
  }),
);

storyRoutes.patch(
  '/:id',
  asyncHandler(async (req, res) => {
    sendSuccess(res, await updateStory(req.user, req.params.id, req.body));
  }),
);

storyRoutes.delete(
  '/:id',
  asyncHandler(async (req, res) => {
    sendSuccess(res, await deleteStory(req.user, req.params.id));
  }),
);

