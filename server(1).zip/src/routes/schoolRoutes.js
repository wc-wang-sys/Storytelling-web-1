import { Router } from 'express';
import { asyncHandler } from '../lib/asyncHandler.js';
import { sendSuccess } from '../lib/response.js';
import { requireAuth } from '../middleware/auth.js';
import {
  listSchools,
  createSchool,
  updateSchool,
  deleteSchool,
  getSchoolStats,
} from '../services/orgService.js';

export const schoolRoutes = Router();

schoolRoutes.use(requireAuth);

schoolRoutes.get(
  '/',
  asyncHandler(async (req, res) => {
    sendSuccess(res, await listSchools(req.user));
  }),
);

schoolRoutes.post(
  '/',
  asyncHandler(async (req, res) => {
    sendSuccess(res, await createSchool(req.user, req.body), 201);
  }),
);

schoolRoutes.patch(
  '/:id',
  asyncHandler(async (req, res) => {
    sendSuccess(res, await updateSchool(req.user, req.params.id, req.body));
  }),
);

schoolRoutes.delete(
  '/:id',
  asyncHandler(async (req, res) => {
    sendSuccess(res, await deleteSchool(req.user, req.params.id));
  }),
);

schoolRoutes.get(
  '/:id/stats',
  asyncHandler(async (req, res) => {
    sendSuccess(res, await getSchoolStats(req.user, req.params.id));
  }),
);

