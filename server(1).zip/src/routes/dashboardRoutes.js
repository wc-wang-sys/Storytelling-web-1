import { Router } from 'express';
import { asyncHandler } from '../lib/asyncHandler.js';
import { sendSuccess } from '../lib/response.js';
import { requireAuth } from '../middleware/auth.js';
import { getDashboardStats } from '../services/orgService.js';

export const dashboardRoutes = Router();

dashboardRoutes.get(
  '/stats',
  requireAuth,
  asyncHandler(async (req, res) => {
    sendSuccess(res, await getDashboardStats(req.user));
  }),
);

