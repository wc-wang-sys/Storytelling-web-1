import { Router } from 'express';
import { asyncHandler } from '../lib/asyncHandler.js';
import { sendSuccess } from '../lib/response.js';
import { requireAuth } from '../middleware/auth.js';
import {
  listStudents,
  createStudent,
  updateStudent,
  deleteStudent,
} from '../services/orgService.js';

export const studentRoutes = Router();

studentRoutes.use(requireAuth);

studentRoutes.get(
  '/',
  asyncHandler(async (req, res) => {
    sendSuccess(res, await listStudents(req.user, req.query));
  }),
);

studentRoutes.post(
  '/',
  asyncHandler(async (req, res) => {
    sendSuccess(res, await createStudent(req.user, req.body), 201);
  }),
);

studentRoutes.patch(
  '/:id',
  asyncHandler(async (req, res) => {
    sendSuccess(res, await updateStudent(req.user, req.params.id, req.body));
  }),
);

studentRoutes.delete(
  '/:id',
  asyncHandler(async (req, res) => {
    sendSuccess(res, await deleteStudent(req.user, req.params.id));
  }),
);

